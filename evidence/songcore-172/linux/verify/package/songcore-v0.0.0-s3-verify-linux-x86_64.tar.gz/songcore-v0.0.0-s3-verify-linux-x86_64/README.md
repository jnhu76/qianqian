# SongCore 0.0.0-s3-verify — linux-x86_64

SongCore is the local media → PCM decode component of Qianqian: one local
media file in, one coherent song snapshot out (identity, metadata, artwork,
stream information, source-rate/source-layout Float32 interleaved PCM, seek,
EOF). This archive is verification-grade campaign evidence (#172), not a
release; the version is a placeholder (contract §14 Q1).

## Contents

    include/songcore.h                  the ONLY ABI description (ABI v1, frozen)
    lib/libsongcore.a                   static artifact (FFmpeg closure merged in)
    lib/shared/libsongcore.so           shared artifact (closure internalized)
    LICENSES/                           FFmpeg COPYING set (pinned source), notices,
                                        MIT + Apache-2.0 texts
    metadata/manifest.json              provenance, schema_version 2
    metadata/symbols.txt                the 15 ABI v1 exports
    metadata/checksums.txt              sha256 of every packaged file except itself
    metadata/external-consumer-example.c  consumer smoke (open→probe→decode→seek→EOF→close)

## Verify the package

    sha256sum -c metadata/checksums.txt   # from inside the package root

## Link against it

Static (recommended; contract §9):
    cc -O2 -Iinclude your.c -Llib -lsongcore -lm -lpthread -o your

Shared:
    cc -O2 -Iinclude your.c -Llib/shared -lsongcore -lm -lpthread \
       -Wl,-rpath,<abs path to lib/shared> -o your

Runtime dependencies: glibc (libc, libm; link -lpthread per the contract;
glibc >= 2.34 has merged pthread symbols into libc). The shared form's
measured glibc symbol-version floor is recorded in
metadata/manifest.json (runtime_dependencies.shared); the supported-distro
policy is owner-reserved. No FFmpeg runtime library is needed: the closure
ships in object form inside the archive.

## Consumer smoke

    cc -O2 -Iinclude metadata/external-consumer-example.c \
       -Llib -lsongcore -lm -lpthread -o songcore-consumer-example
    ./songcore-consumer-example /path/to/media.mp3

## Relink obligations (LGPL, contract §10 O3)

The archive contains the FFmpeg members in object form. The machine-verifiable
rebuild inputs — ffmpeg/pin.json (tag→commit + zip sha256), the codec-base
capability profile, the linux-x86_64 target recipe, the imported closure
manifest (schema 2, units + flags), and the Xmake replay configuration — are
part of the source repository at the manifest's recorded commit; a licensee
can recombine them to relink a modified FFmpeg closure without any
undocumented step.
