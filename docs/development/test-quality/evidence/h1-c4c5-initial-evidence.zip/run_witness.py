import pathlib,subprocess,json,hashlib,datetime,os,sys
root=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,prefix,expected=0):
 with open(out/(prefix+'.log'),'w') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 if r.returncode!=expected:raise RuntimeError((prefix,r.returncode,expected))
 return r
source=root/'apps/headless/src/machine_input.rs'; original=source.read_text()
for lane in ['green','M-S','M-F','restored']:
 s=original
 if lane=='M-S':
  a=s.index('        while state.operation_active {',s.index('pub(crate) fn seal'));b=s.index('        let result = state.first_failure;',a);s=s[:a]+s[b:]
 if lane=='M-F':s=s.replace('while state.operation_active {','while state.operation_active && state.first_failure.is_none() {',1)
 source.write_text(s)
 run(['cargo','clean','-p','qianqian-headless'],lane+'-clean')
 run(['cargo','test','-p','qianqian-headless','--lib','--no-run','--message-format=json'],lane+'-build')
 artifacts=[]
 for line in (out/(lane+'-build.log')).read_text().splitlines():
  try:d=json.loads(line)
  except ValueError:continue
  if d.get('reason')=='compiler-artifact' and d.get('executable') and d['target']['name']=='qianqian_headless':artifacts.append(d['executable'])
 assert len(artifacts)==1,artifacts
 binary=pathlib.Path(artifacts[0]);run([str(binary),'seal_final_read_witnesses','--list'],lane+'-discovery')
 assert (out/(lane+'-discovery.log')).read_text().count(': test')==4
 (out/(lane+'-source.rs')).write_text(s)
 with open(out/(lane+'-patch.diff'),'w') as f:subprocess.run(['git','diff','--binary'],cwd=root,stdout=f,check=True)
 targets=['normal_response_and_drop_ack','normal_returned_response_with_held_guard','failure_response_and_drop_ack','failure_returned_response_with_held_guard']
 results={}
 for target in targets:
  expected=101 if lane=='M-S' or lane=='M-F' and target.startswith('failure') else 0
  prefix=lane+'-'+target
  run([str(binary),'--exact','machine_input::tests::seal_final_read_witnesses_'+target,'--nocapture'],prefix,expected)
  log=(out/(prefix+'.log')).read_text()
  if expected:
   assert 'seal final read preceded response completion or Drop ACK' in log
   assert 'left: 7' in log if 'held_guard' in target else 'left: 3' in log
  results[target]='TARGET_ORACLE_RED' if expected else 'GREEN'
 if lane in ['green','restored']:run([str(binary),'machine_input::tests','--nocapture'],lane+'-siblings')
 meta={'run_id':datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')+'-'+lane,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'platform':subprocess.check_output(['rustc','-vV'],text=True),'binary':str(binary),'binary_sha256':sha(binary),'source_sha256':sha(source),'tests_sha256':sha(root/'apps/headless/src/machine_input/tests.rs'),'patch_sha256':sha(out/(lane+'-patch.diff')),'results':results}
 (out/(lane+'-metadata.json')).write_text(json.dumps(meta,indent=2)+'\n');print(lane,results,flush=True)
source.write_text(original)
