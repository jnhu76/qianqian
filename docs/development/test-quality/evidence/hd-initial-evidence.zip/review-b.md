# Independent Reviewer B — Test Value / Cost / Causality

Verdict: **APPROVE**. Reviewed final HEAD `e70a5b42bf663d4465fb887b880c8e6e8edabc46` against `bc0b317b4f502f986d8dc480b8b0d4e29c7bf525`. No outstanding P0/P1/P2/P3 findings. Read-only review; no source, ADR, infrastructure or GitHub write. The only files written by this reviewer are this report and execution logs under /tmp.

Read: AGENTS.md, CONTEXT.md, docs/README.md, PBK-001 §2.2–2.3, PBK-002 D11/D14.5 C2/D14.7 current authority, frozen execution model D3/§8–9, concurrency-test-design, hd-subject-and-authority, the complete Rust diff and real production/test call paths. Existing #257/#261 descriptions and reviewer receipts were inspected as inherited evidence; no new mutation campaign was run.

## Findings and disposition

**Resolved P2 — evidence target identity**: initial audit document identified H4 as the qianqian-headless binary. The test is compiled in the library through src/lib.rs:43. Actual `--bin qianqian-headless` execution returned zero tests; actual `--lib` execution of its fully qualified name returned one passing test. Final document line 25 now correctly says `qianqian-headless lib`. The zero-test receipt is preserved and is not counted as a PASS witness.

Final pre-catch scope statement (audit document lines 201–213) is accurate: `decode_stream.format`, binding the observation reader, and observation analyst spawn precede catch_unwind at session.rs:591. A panic there can bypass the pair at session.rs:921–922. This is an existing scope limit, not a regression from these removals. Normal loop EOF/error/stop/seek-ending returns remain in the caught closure, and a caught loop panic reaches the outer funnel. No new mechanism is warranted by this narrow test-disposition task. Final text no longer claims all possible panics pass the funnel.

## R3A-H4 — preserve natural-terminal host matrix, remove history pin

The four cases are two natural terminals (Completed/Failed) times terminal-before-failure versus recorded-failure-before-response. The second ordering really records failure, releases the host mutex, waits for natural terminal inside response, then calls late Stop. Host-result return still traverses terminal/disposal/seal. The first ordering uses production Operation::fail after terminal and currently skips Stop. These are distinct cuts with observable host-result and terminal consequences.

Assertion classification:

- `wait_terminal == expected` both inside cut and at final return: NORMATIVE_SEMANTIC_ASSERTION; rejects terminal relabeling and host failure forged as playback Failed.
- Host mutex `try_lock` during terminal response wait: NECESSARY_MECHANISM_ASSERTION; verifies the D3 lock firewall on this cut, not a universal lock-order proof.
- `exit == 1`: NORMATIVE_SEMANTIC_ASSERTION; independent admitted host failure contributes failure result.
- `disposed.get()`: NECESSARY_MECHANISM_ASSERTION; fixture resource-disposal witness independent of terminal observation.
- Completed `failure_diagnostic.is_none()`: NORMATIVE_SEMANTIC_ASSERTION; truth-class rule. Failed diagnostic presence is deliberately not pinned.
- Deleted `!stop_requested`: INCIDENTAL_IMPLEMENTATION_PIN; command history cannot identify whether this host dispatched Stop and late history is legal under D11/D14.4. No semantic witness is lost.

Entire matrix deletion would lose valuable host-natural-terminal coverage. Retaining it is correct. Unsettled Read/Panic response and preexisting genuine Stop siblings complement it; they do not replace this matrix. Removal leaves its runtime cost and causal premises unchanged.

## R3B-P1-04 — remove unused latch and its self-pinning test

Compared base code and searched current source including hidden files, excluding .git/build artifacts. At the base, private `disengagement_observed` has constructor initialization and three writes; its only read is the deleted test closure. CompletionState is private, not serialized, FFI or reflection input. No production conditional, resolver, observation, gate routing or seek decision reads it. The production `PauseEngagement` read maps only `(engaged, tail_quiesced)` at completion.rs:1122–1125. Engaged and Disengaged still clear the current tail, and seek engagement/quiescence remains a separate pair. The deleted new-pause conditional only reset the unused bool.

Deleted assertions:

- `pause_requested`: REDUNDANT_ASSERTION; surviving command/seam witnesses observe the real command.
- Old Disengaged latches true, Engaged clears it, Resume leaves it false, current Disengaged latches true: all INCIDENTAL_IMPLEMENTATION_PIN; only reject unused-field writer/reset mutations.
- Terminal remains None: REDUNDANT_ASSERTION; real pause/resume cycle and seam tests retain nonterminal behavior.

The deleted comment claiming this latch protects PauseEngagement had no read edge. Final source also removes its stale neighboring delayed-delivery comment. Deleting the latch and unique consumer loses no unique required product witness. Preserving the test would require recreating dead representation for its own oracle.

Surviving actual protection is narrower and useful: pause_seam.rs:316 exercises two real gate cycles. Cycle 2 freezes mock device playout while real Engaged is observed, requires `pause_requested && Engaged && !paused`, then independently allows tail drain and waits for establishment. This protects stale tail attribution and actual Engaged spelling; it does not reproduce the exact deleted delayed-old-Disengaged delivery schedule. That lost schedule checked only the dead latch. Completion `s0_operation_evidence_cannot_cross_cycles_and_cleared_parks_ground_nothing` clears old SeekDisengaged/release/slot before cycle 2, requires fresh operation evidence and Pending without a current park, then publishes cycle 2 evidence and commits. The pause attribution and paused-cut siblings check reuse of the current pause pair. No new liveness state or authority is introduced.

## R3B-P1-02 — keep assembled EOF liveness test and narrow claim

Unchanged body: wait past 7 seconds of Position, 200 seek requests at 2 ms pacing to a late landing, hammer join, wait_terminal, terminal Position withdrawal, runtime disposal. Workload and deadlines are unchanged.

Assertions: Completed is NORMATIVE_SEMANTIC_ASSERTION for the fixture's ordinary EOF course; position None is NORMATIVE_SEMANTIC_ASSERTION for terminal projection withdrawal; disposal snapshot quiet is NECESSARY_MECHANISM_ASSERTION scoped to fixture disposal (not independent platform or complete Discharged proof). Hammer join is test hygiene, and timeout is a bounded failure watchdog. Neither burst nor pacing is synchronization proof of an exit window.

Source causality: H2 guards/plant/reset/hold route serialize with worker-gone under completion lock. In the intended production sequence, a prior record is cleared by abort duty; a later H2 rejects. Worker loop exits reach worker_exited before abort_stranded_seek, and observation close/join comes later. The two calls' strict order is established by source review, not by a passing stress test.

#257 witnesses actually suspend the real request after its Open sample. All other H2 rejection predicates are explicitly unmasked; the completion twin drives the pair, while the session twin runs the real decode worker and then a real leg/drain. Inherited M2/M3 RED receipts establish the second-hold worker_gone conjunct's nonvacuity at their recorded subjects. The real-worker twin completes both funnel calls before releasing H2; swapping those calls would preserve that constructed final state, so it does not prove strict two-call program order.

#261 ending/Open and post-seek-read witnesses establish different properties: ending-raced private records are not automatically semantic Accepted, provider/purge/rebase are gated correctly, and multicut fixtures possess real slot-free/read causality. Those receipts strengthen admission and seek attribution evidence; they provide no new deterministic witness between the production funnel calls. No exact swapped-order mutant was executed here. The revised comment accurately preserves this boundary. Keeping the assembled test retains wiring/liveness regression value beyond white-box boundary twins.

## Cost, scope and validation

Rust diff is coherent and near-minimal: four assertion lines removed, unused private field/writes/docs/unique test removed, stale dead-test reference removed, EOF comments clarified. No new sleep, retry, loop, scheduler, public API, lock, observer, hook, instrumentation or test dependency. Runtime decreases slightly; flaky probability is not increased by any schedule change. The audit document is lengthy relative to code but contains the requested durable subject/authority, assertion and evidence reconciliation; no product authority is added.

Independent targeted runs on Linux default non-loom, mock/device-free mechanisms: 10 nonempty tests passed across seven commands: H4 1, s0 family 4, pause cycle 1, EOF integration 1, completion straddle 1, real-worker straddle 1, worker-exit cleanup 1. Exact argv, raw combined logs, return codes and SHA256 are in `/tmp/qianqian-hd-audit/reviewer-b-runs/{1..7}.json` and `.log` (0 is the preserved zero-test wrong-binary run). No test failures observed. Initial targeted runs preceded final comment/document-only corrections; reviewed executable behavior is unchanged. No mutant, device, Windows, FFI, Loom/TLC/Miri or full pre-push run performed by this reviewer; coordinator's independent gate receipts are separate. Passing tests are regression evidence within these fixture schedules, not architecture or universal-liveness proof.

Final-head confirmation: `git diff 564fbe3f3914497da32d88c7bc645b74915c983e e70a5b42bf663d4465fb887b880c8e6e8edabc46 -- '*.rs'` is empty. The sole commit delta is the audit identity correction binary→lib at line 25, already observed in the previous working-tree read. No test rerun required; APPROVE applies to this exact final HEAD.
