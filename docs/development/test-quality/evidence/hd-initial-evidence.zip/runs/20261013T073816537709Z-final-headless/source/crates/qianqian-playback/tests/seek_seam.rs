//! F5 seek seam tests (ADR-PBK-002 D14.5): the REAL Playback Session
//! over mechanism doubles, asserting what a seek command observably
//! does — and observably does NOT do.
//!
//! Truth classes under test: `request_seek` is a Command whose
//! acceptance is not a cutover; the observable consequences are exactly
//! (a) the Position projection rebasing to the decoder's ACTUAL landing
//! at a committed cutover (or withdrawing forever for an unknown
//! landing), (b) the consumed CONTENT sequence showing exactly one
//! discontinuity — the cut — for a commit, and none for a refusal
//! (refusal equals the no-seek control, frame for frame), and (c) for a
//! destructive provider failure, the ordinary terminal `Failed` through
//! the existing D11 path. There is deliberately no public positive seek
//! state to read; these matrices pin the consequences instead.
//!
//! The content oracle: the decode double position-tags every frame
//! (sample value = absolute frame index), and the output double records
//! the channel-0 value of every submitted frame in submission order. A
//! committed cutover MUST appear as exactly one discontinuity `K →
//! landing` with both sides contiguous; the skipped stretch between the
//! old position and the landing is what a seek IS, so the sequence
//! length is a witness only for the refusal (zero loss) and is
//! meaningless for a cut. A refused seek MUST produce the frame-exact
//! sequence of the no-seek control.
//!
//! What the mechanism doubles cannot cover is stated, not implied:
//!
//! ```text
//! covered elsewhere
//!   gate algebra      qianqian-audio-api's render_gate_seek oracles
//!                     (payload-awaits-consumption, one-payload, hold
//!                     resets, closed gate)
//!   position algebra  qianqian-audio-api's position_evidence oracles
//!                     (rebase as the one legal backward step, zero
//!                     landing, withdrawal discipline)
//!   real leg order    the Windows render loop's source-order oracle
//!                     (publish/unconditional-slice rules P1–P13,
//!                     including the failed-observation answer P13)
//!   protocol latches  the completion's own white-box tests inside the
//!                     crate (slot policy, acceptance conditions, the
//!                     commit conjunction, first-wins latches) —
//!                     deliberately NOT public product surface (D14.5:
//!                     no public positive seek state)
//!
//! blind spots of ANY double-driven test here
//!   failed submission  the mock has no failing ReleaseBuffer; "a failed
//!                      submission is never counted" rests on the order
//!                      oracle, not on this file
//!   frame units        the mock is unit-agnostic (see common/mod.rs)
//! ```

mod common;

use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use qianqian_app::QianqianApp;
use qianqian_audio_api::ports::{
    DecodeError, DecodeOpenError, DecodeOutcome, DecodedPcmStream, PcmDecode, ProviderSeekOutcome,
};
use qianqian_composition::{DesiredEntry, Revision};
use qianqian_playback::{EpisodeTerminalOutcome, PlaybackSessionHandle};

use common::{
    DeviceTail, OutputBehavior, Playout, ProducerFreezeWitness, SourceBehavior, TEST_FORMAT,
    TailProbe, TestDecode, TestOutput, within,
};

const DUMMY_PATH: &str = "test://seek-seam";

/// An 8-second source: long enough that a seek fired in the first second
/// is decisively mid-stream (the bounded edge is full and the worker is
/// parked inside its interruptible write when the command is planted),
/// short enough that the slow mock consumer still finishes it in
/// seconds.
const SOURCE_FRAMES: usize = 44_100 * 8;
/// 0.5 s, 1 s and 5 s of source, in frames (the episode format's rate).
const HALF_A_SECOND: u64 = 22_050;
const ONE_SECOND: u64 = 44_100;
const FIVE_SECONDS: u64 = 5 * 44_100;

fn desired(id: &str, component: &'static str) -> DesiredEntry {
    DesiredEntry::enabled(id, component, Revision::new(1))
}

/// Bounded poll for an asynchronously-published observation.
fn wait_until(limit: Duration, mut predicate: impl FnMut() -> bool) -> bool {
    let deadline = Instant::now() + limit;
    loop {
        if predicate() {
            return true;
        }
        if Instant::now() >= deadline {
            return false;
        }
        std::thread::sleep(Duration::from_millis(5));
    }
}

/// The witnesses one seek test drives and asserts on; the test owns
/// every one of them, so a test can read them before, while and after
/// the runtime uses them.
struct Witnesses {
    consumed: Arc<AtomicUsize>,
    consumed_values: Arc<Mutex<Vec<f32>>>,
    device_tail: DeviceTail,
    tail_probe: TailProbe,
    post_seek_read: Arc<AtomicUsize>,
    controlled_eof: bool,
    eof_allowed: Arc<std::sync::atomic::AtomicBool>,
    committed_offsets: common::CommittedOffsets,
}

/// Observe the real worker's first decoder read after each seek. For
/// Applied, worker program order is release take -> clear_seek_in_flight
/// -> read_frames. Position/rebase alone does NOT prove that slot-free.
#[derive(Clone)]
struct ReadWitnessDecode {
    inner: TestDecode,
    post_seek_read: Arc<AtomicUsize>,
    controlled_eof: bool,
    eof_allowed: Arc<std::sync::atomic::AtomicBool>,
}

impl PcmDecode for ReadWitnessDecode {
    fn open_media(
        &self,
        path: &std::path::Path,
    ) -> Result<Box<dyn DecodedPcmStream>, DecodeOpenError> {
        Ok(Box::new(ReadWitnessStream {
            inner: self.inner.open_media(path)?,
            post_seek_read: self.post_seek_read.clone(),
            seeks: 0,
            cursor: 0,
            controlled_eof: self.controlled_eof,
            eof_allowed: self.eof_allowed.clone(),
        }))
    }
}

struct ReadWitnessStream {
    inner: Box<dyn DecodedPcmStream>,
    post_seek_read: Arc<AtomicUsize>,
    seeks: usize,
    cursor: u64,
    controlled_eof: bool,
    eof_allowed: Arc<std::sync::atomic::AtomicBool>,
}

impl DecodedPcmStream for ReadWitnessStream {
    fn format(&self) -> qianqian_audio_api::ports::PcmFormat {
        self.inner.format()
    }
    fn source_duration(&self) -> Option<Duration> {
        self.inner.source_duration()
    }
    fn read_frames(&mut self, dst: &mut [f32]) -> Result<DecodeOutcome, DecodeError> {
        self.post_seek_read.store(self.seeks, Ordering::SeqCst);
        // Multi-cut fixtures stay Open until the test releases EOF, even
        // when the main thread is delayed beyond the finite prefix. Paced
        // continuation feeds the render read, so park stays reachable.
        // EOF permission ends at the source extent; no wait blocks stop.
        if self.controlled_eof
            && self.eof_allowed.load(Ordering::SeqCst)
            && self.cursor >= SOURCE_FRAMES as u64
        {
            return Ok(DecodeOutcome::Eof);
        }
        let result = self.inner.read_frames(dst)?;
        if let DecodeOutcome::Frames(n) = result {
            self.cursor += n as u64;
        }
        Ok(result)
    }
    fn seek(&mut self, target: Duration) -> ProviderSeekOutcome {
        let result = self.inner.seek(target);
        if let ProviderSeekOutcome::Applied { landing } = result {
            self.cursor = landing
                .unwrap_or(
                    (target.as_nanos() * u128::from(TEST_FORMAT.sample_rate) / 1_000_000_000)
                        as u64,
                )
                .min(SOURCE_FRAMES as u64);
        }
        self.seeks += 1;
        result
    }
}

fn wait_post_seek_read(witnesses: &Witnesses, cycle: usize) {
    assert!(
        wait_until(Duration::from_secs(5), || witnesses
            .post_seek_read
            .load(Ordering::SeqCst)
            >= cycle),
        "seek {cycle}: real post-seek read must witness worker slot-free"
    );
}

/// Register the standard F5 episode: a seek-scripted decode double, an
/// output double sharing the caller's witnesses, and the real session
/// over `handle`.
fn registered_runtime(
    decode: TestDecode,
    output: OutputBehavior,
    witnesses: &Witnesses,
    handle: PlaybackSessionHandle,
) -> common::EpisodeFixture {
    let decode = ReadWitnessDecode {
        inner: decode,
        post_seek_read: witnesses.post_seek_read.clone(),
        controlled_eof: witnesses.controlled_eof,
        eof_allowed: witnesses.eof_allowed.clone(),
    };
    let consumed = witnesses.consumed.clone();
    let consumed_values = witnesses.consumed_values.clone();
    let device_tail = witnesses.device_tail.clone();
    let tail_probe = witnesses.tail_probe.clone();
    let committed_offsets = witnesses.committed_offsets.clone();
    let mut runtime = common::EpisodeFixture::new(QianqianApp::new(), witnesses.tail_probe.clone());

    runtime
        .register_component({
            qianqian_composition::ComponentSpec::new("test_decode_plugin")
                .provides::<qianqian_audio_api::ports::PcmDecodeCapability>()
                .on_activate(move |ctx| {
                    ctx.provide::<qianqian_audio_api::ports::PcmDecodeCapability>(
                        std::rc::Rc::new(decode.clone()),
                    )
                    .map_err(|e| qianqian_composition::ActivationError::new(format!("{e:?}")))?;
                    Ok(())
                })
        })
        .expect("decode provider registers");

    runtime
        .register_component({
            qianqian_composition::ComponentSpec::new("test_output_plugin")
                .provides::<qianqian_audio_api::ports::AudioOutputCapability>()
                .on_activate(move |ctx| {
                    let mut service = TestOutput::observed_with_content(
                        output,
                        consumed.clone(),
                        consumed_values.clone(),
                        device_tail.clone(),
                    );
                    service.tail_probe = tail_probe.clone();
                    service.committed_offsets = committed_offsets.clone();
                    ctx.provide::<qianqian_audio_api::ports::AudioOutputCapability>(
                        std::rc::Rc::new(service),
                    )
                    .map_err(|e| qianqian_composition::ActivationError::new(format!("{e:?}")))?;
                    Ok(())
                })
        })
        .expect("output provider registers");

    runtime
        .register_component(qianqian_playback::playback_session_spec(
            std::path::PathBuf::from(DUMMY_PATH),
            handle,
        ))
        .expect("session registers");
    runtime
}

fn activate(runtime: &mut QianqianApp) {
    runtime
        .revise_desired(vec![
            desired("decode", "test_decode_plugin"),
            desired("output", "test_output_plugin"),
            desired("session", "playback_session"),
        ])
        .expect("composition is legal");
}

/// The standard episode: an 8-second position-tagged source played out
/// by a slow mock consumer (so a seek fired in the first second is
/// decisively mid-stream), with the standard witness set.
fn episode(
    seeks: Vec<ProviderSeekOutcome>,
) -> (Witnesses, PlaybackSessionHandle, common::EpisodeFixture) {
    episode_with_freeze(seeks, &ProducerFreezeWitness::default())
}

/// [`episode`] with the caller owning the decode double's producer
/// freeze witness, so a destructive-seek oracle can pin the
/// producer-side "never resumes old-cursor production" guarantee
/// directly (see `common::ProducerFreezeWitness`).
fn episode_with_freeze(
    seeks: Vec<ProviderSeekOutcome>,
    freeze: &ProducerFreezeWitness,
) -> (Witnesses, PlaybackSessionHandle, common::EpisodeFixture) {
    episode_with_source_policy(seeks, freeze, false)
}

fn episode_with_source_policy(
    seeks: Vec<ProviderSeekOutcome>,
    freeze: &ProducerFreezeWitness,
    controlled_eof: bool,
) -> (Witnesses, PlaybackSessionHandle, common::EpisodeFixture) {
    let witnesses = Witnesses {
        consumed: Arc::new(AtomicUsize::new(0)),
        consumed_values: Arc::new(Mutex::new(Vec::new())),
        device_tail: DeviceTail::default(),
        tail_probe: TailProbe::default(),
        post_seek_read: Arc::new(AtomicUsize::new(0)),
        controlled_eof,
        eof_allowed: Arc::new(std::sync::atomic::AtomicBool::new(false)),
        committed_offsets: Arc::new(Mutex::new(Vec::new())),
    };
    let handle = PlaybackSessionHandle::new();
    let mut runtime = registered_runtime(
        TestDecode {
            behavior: if controlled_eof {
                SourceBehavior::Paced {
                    after: SOURCE_FRAMES,
                    delay: Duration::from_millis(1),
                }
            } else {
                SourceBehavior::EofAfter(SOURCE_FRAMES)
            },
            duration: Some(Duration::from_secs(8)),
            seeks,
            freeze: freeze.clone(),
        },
        OutputBehavior::SlowConsume {
            per_read: Duration::from_millis(1),
        },
        &witnesses,
        handle.clone(),
    );
    activate(&mut runtime);
    (witnesses, handle, runtime)
}

/// Block until the projection has climbed past `frames` (the episode is
/// decisively playing) and return the sample seen there.
fn wait_for_position_past(handle: &PlaybackSessionHandle, frames: u64) -> u64 {
    let mut sample = 0u64;
    assert!(
        wait_until(Duration::from_secs(5), || {
            if let Some(position) = handle.observe().position {
                sample = position;
                position >= frames
            } else {
                false
            }
        }),
        "the position never reached {frames}: {sample}"
    );
    sample
}

/// The consumed content, snapped once.
fn content(witnesses: &Witnesses) -> Vec<f32> {
    witnesses.consumed_values.lock().unwrap().clone()
}

/// After disposal, each nonempty submission window starts at that cut's
/// actual source landing. Final jump counts cannot establish this boundary.
fn assert_committed_windows(witnesses: &Witnesses, expected: &[(Option<u64>, u64)]) {
    let cuts = witnesses.committed_offsets.lock().unwrap().clone();
    let values = content(witnesses);
    assert_eq!(
        cuts.len(),
        expected.len(),
        "every committed callback, not last wins"
    );
    for (i, &(landing, actual)) in expected.iter().enumerate() {
        assert_eq!(cuts[i].0, landing, "cut {i} receipt");
        let first = cuts[i].1;
        let end = cuts.get(i + 1).map_or(values.len(), |c| c.1);
        assert!(
            first <= end && end <= values.len(),
            "submission indices must be ordered"
        );
        if first < end {
            assert_eq!(
                values[first], actual as f32,
                "cut {i}: first submission after committed receipt must exclude old ring PCM"
            );
        }
    }
}

/// Indices where the position-tagged sequence does not continue the
/// previous frame index. Frame values stay exact in f32 far beyond this
/// source's length (< 2^24), so the comparison is exact.
fn discontinuities(values: &[f32]) -> Vec<usize> {
    values
        .iter()
        .zip(values.iter().skip(1))
        .enumerate()
        .filter_map(|(i, (a, b))| (*b != *a + 1.0).then_some(i + 1))
        .collect()
}

/// Assert the canonical committed-cut content shape: contiguous from
/// frame 0, exactly ONE discontinuity, landing exactly at `landing`,
/// contiguous after.
fn assert_one_cut_to(values: &[f32], landing: u64) {
    let breaks = discontinuities(values);
    assert_eq!(
        breaks.len(),
        1,
        "a committed cutover must appear as exactly one content \
         discontinuity (got {breaks:?} in {} frames)",
        values.len()
    );
    assert_eq!(
        values[0], 0.0,
        "the first stretch must start at the source's frame 0"
    );
    assert_eq!(
        values[breaks[0]] as u64, landing,
        "the cut must land exactly at the provider's ACTUAL landing"
    );
}

// --- committed cut -------------------------------------------------------

/// The core happy path: a mid-stream seek to 5 s lands the consumed
/// content exactly at the provider's actual landing — contiguous before,
/// one discontinuity, contiguous after — and the projection climbs again
/// from the landing. The episode still runs to its ordinary Completed
/// terminal. This also drives the mid-write cut point: by half a second
/// the bounded edge is full and the worker is parked inside its
/// interruptible write when the command is planted.
#[test]
fn a_committed_forward_seek_jumps_the_content_exactly_at_the_actual_landing() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        handle.request_seek(Duration::from_secs(5));
        assert!(
            wait_until(Duration::from_secs(5), || handle
                .observe()
                .position
                .is_some_and(|p| p >= FIVE_SECONDS)),
            "the position never rebased to the landing: {:?}",
            handle.observe()
        );
        assert_eq!(
            handle.wait_terminal(),
            EpisodeTerminalOutcome::Completed,
            "the seek must not disturb the episode's ordinary EOF course"
        );
        assert_one_cut_to(&content(&witnesses), FIVE_SECONDS);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// A backward seek is the same mechanism with the cut pointing earlier:
/// the projection legally steps backward exactly once (the rebase — the
/// one backward step the cell admits), the content shows the one jump
/// back to the landing, and afterwards the sample resumes its
/// never-backward discipline.
#[test]
fn a_committed_backward_seek_rebases_the_position_legally_backward() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        let pre = wait_for_position_past(&handle, ONE_SECOND);
        handle.request_seek(Duration::from_millis(200));
        assert!(
            wait_until(Duration::from_secs(5), || handle
                .observe()
                .position
                .is_some_and(|p| p < pre)),
            "the position must step backward to below {pre} at the rebase: {:?}",
            handle.observe()
        );
        // After the rebase the sample resumes its monotone course: a
        // later read never goes backward again.
        let first = handle.observe().position.expect("published");
        let second = handle.observe().position.expect("published");
        assert!(
            second >= first,
            "after the one legal backward step the sample must never go \
             backward again: {first} -> {second}"
        );
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        assert_one_cut_to(&content(&witnesses), 8_820); // 200 ms at 44.1 kHz
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// A seek to time zero is a real landing: the projection legally steps
/// backward to the landing and KEEPS PUBLISHING from it — a zero landing
/// is a position, and only an unknown landing withdraws (that
/// distinction is pinned at the cell's own algebra in
/// qianqian-audio-api; here it is pinned end-to-end: any published
/// sample below the pre-seek one proves the zero landing published
/// rather than withdrew, and the content restarts from frame 0). The
/// exact `Some(0)` instant is a freshness race for a poller — the
/// sample sits at zero for one publication cadence before it climbs —
/// so it is deliberately not what this test waits for.
#[test]
fn a_zero_landing_publishes_position_zero_not_undefined() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        handle.request_seek(Duration::ZERO);
        let mut saw_rebased_sample = false;
        wait_until(Duration::from_secs(5), || {
            let observation = handle.observe();
            if let Some(p) = observation.position
                && p < HALF_A_SECOND
            {
                saw_rebased_sample = true;
                return true;
            }
            // Stop early once the episode settled: past the terminal the
            // projection is withdrawn by design, which would mask the
            // question this poll answers.
            observation.terminal_outcome.is_some()
        });
        assert!(
            saw_rebased_sample,
            "a zero landing is a position, never undefined: the projection \
             must publish a live sample below the pre-seek position at the \
             rebase (last: {:?})",
            handle.observe()
        );
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        assert_one_cut_to(&content(&witnesses), 0);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// Beyond-extent targets pass through untouched: duration evidence is
/// never consulted at acceptance, and the PROVIDER's decision — its own
/// validity rule and its own landing — is authoritative. The scripted
/// landing stands in for that decision (near the extent, deliberately
/// unrelated to the 999 s request), and the cut must land THERE: the
/// request is never the landing.
#[test]
fn a_beyond_duration_target_is_the_providers_decision() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let landing = SOURCE_FRAMES as u64 - 100;
        let (witnesses, handle, mut runtime) = episode(vec![ProviderSeekOutcome::Applied {
            landing: Some(landing),
        }]);
        wait_for_position_past(&handle, HALF_A_SECOND);
        handle.request_seek(Duration::from_secs(999));
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        assert_one_cut_to(&content(&witnesses), landing);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// An `Applied` cutover whose landing the provider could not report:
/// the commit still happens (the content jumps — stale exclusion is
/// independent of landing knowledge), production continues from the
/// provider's own continuation, and the Position projection is
/// withdrawn for the REST OF THE EPISODE — through production, a later
/// committed cutover with a KNOWN landing, EOF, and the terminal Fact.
/// Unknown stays unknown; it never becomes zero and never becomes the
/// requested target.
#[test]
fn an_unknown_landing_withdraws_the_position_for_the_rest_of_the_episode() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let later_landing = 6 * ONE_SECOND;
        let (witnesses, handle, mut runtime) = episode_with_source_policy(
            vec![
                ProviderSeekOutcome::Applied { landing: None },
                ProviderSeekOutcome::Applied {
                    landing: Some(later_landing),
                },
            ],
            &ProducerFreezeWitness::default(),
            true,
        );
        wait_for_position_past(&handle, HALF_A_SECOND);
        handle.request_seek(Duration::from_secs(5));
        assert!(
            wait_until(Duration::from_secs(5), || handle
                .observe()
                .position
                .is_none()),
            "the unknown landing withdraws the projection"
        );
        // The real worker read comes AFTER payload take and slot-free;
        // Position None alone occurs earlier and cannot order request 2.
        wait_post_seek_read(&witnesses, 1);
        handle.request_seek(Duration::from_secs(6));
        wait_post_seek_read(&witnesses, 2);
        assert!(
            wait_until(Duration::from_secs(5), || witnesses
                .committed_offsets
                .lock()
                .unwrap()
                .len()
                == 2),
            "both on-leg rebases must be applied"
        );
        let live = handle.observe();
        assert_eq!(
            live.terminal_outcome, None,
            "EOF is held until this live oracle"
        );
        assert!(
            live.position.is_none(),
            "known rebase cannot restore Position before terminal withdrawal: {live:?}"
        );
        witnesses.eof_allowed.store(true, Ordering::SeqCst);
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        assert!(
            handle.observe().position.is_none(),
            "the withdrawal survives a later known-landing cutover: {:?}",
            handle.observe()
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_committed_windows(
            &witnesses,
            &[(None, FIVE_SECONDS), (Some(later_landing), later_landing)],
        );
        // Both cuts are in the content, at the two landings.
        let values = content(&witnesses);
        let breaks = discontinuities(&values);
        assert_eq!(breaks.len(), 2);
        assert_eq!(values[breaks[0]] as u64, FIVE_SECONDS);
        assert_eq!(values[breaks[1]] as u64, later_landing);
    });
}

// --- refusal -------------------------------------------------------------

/// A proven pre-mutation refusal loses NOTHING: the preserved remainder
/// of the interrupted staging block is finished frame-for-frame, and the
/// consumed content is INDISTINGUISHABLE from a no-seek control — every
/// frame index in order, zero discontinuities.
#[test]
fn a_refused_seek_finishes_its_own_remainder_with_zero_content_loss() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(vec![ProviderSeekOutcome::RefusedUnchanged]);
        wait_for_position_past(&handle, HALF_A_SECOND);
        handle.request_seek(Duration::from_secs(5));
        assert_eq!(
            handle.wait_terminal(),
            EpisodeTerminalOutcome::Completed,
            "a refusal is not a failure and not a cut"
        );
        let values = content(&witnesses);
        assert!(
            discontinuities(&values).is_empty(),
            "a refused seek must be content-indistinguishable from no seek"
        );
        let control: Vec<f32> = (0..SOURCE_FRAMES).map(|i| i as f32).collect();
        assert_eq!(values, control, "zero content loss, frame for frame");
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

// --- destructive provider failure ---------------------------------------

/// An unprovable provider failure is destructive by definition: the
/// episode NEVER resumes old-cursor production — it takes the ordinary
/// D11 `Failed` route, production stops for good, and the terminal is
/// `Failed` (not Stopped, not Completed), with the diagnostic as
/// presentation only. "Never resumes" is witnessed on the PRODUCER
/// side — the decode endpoint's own count of reads arriving after the
/// destructive outcome — because a consumed-total bound alone cannot
/// separate a short resumption from the legal post-failure drain, and
/// teardown's own stop could truncate a resuming worker before the
/// consumer side ever shows it.
#[test]
fn a_destructive_provider_failure_fails_the_episode_and_never_resumes() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let freeze = ProducerFreezeWitness::default();
        let (witnesses, handle, mut runtime) = episode_with_freeze(
            vec![ProviderSeekOutcome::MutatedThenFailed {
                diagnostic: "mid-stream corruption".to_owned(),
            }],
            &freeze,
        );
        wait_for_position_past(&handle, HALF_A_SECOND);
        handle.request_seek(Duration::from_secs(5));
        assert_eq!(
            handle.wait_terminal(),
            EpisodeTerminalOutcome::Failed,
            "an unprovable seek failure is a decode failure (D11)"
        );
        let observation = handle.observe();
        assert!(
            observation
                .failure_diagnostic
                .as_deref()
                .is_some_and(|d| d.contains("seek failed")),
            "the diagnostic is presentation evidence of the route: {observation:?}"
        );
        assert!(
            handle.observe().position.is_none(),
            "the terminal Fact withdraws the projection"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        // The producer-side freeze oracle, final now that teardown
        // joined the worker: a resumed worker READS before it writes,
        // so the endpoint's own count sees a resumption even when the
        // edge, the consumer total or teardown's stop would hide it.
        assert_eq!(
            freeze.post_failed_seek_reads(),
            0,
            "the producer resumed old-cursor production after the \
             destructive seek"
        );
        // Secondary consumer-side bound (the Failed Fact and the data
        // plane's own terminal are separate events, so the render leg
        // may legally drain PCM published before the failure): the
        // final total must still sit short of the source — resumption
        // draining to exhaustion is the coarse failure this catches.
        let settled = witnesses.consumed.load(Ordering::SeqCst);
        assert!(
            settled < SOURCE_FRAMES,
            "a failed episode must never resume production: {settled} frames \
             consumed — the destructive failure must leave the source \
             unexhausted"
        );
    });
}

/// Run `f` and report whether it panicked — the negative-control shape:
/// an oracle MUST be able to fail, and the control proves it does on
/// the exact defect signature it exists to catch.
fn rejects(f: impl FnOnce()) -> bool {
    std::panic::catch_unwind(std::panic::AssertUnwindSafe(f)).is_err()
}

/// Negative control: the producer-freeze oracle must be able to FAIL.
/// Production never resumes after a destructive seek, so no real
/// episode can reach the wrong shape — the control drives the decode
/// double directly: the scripted destructive outcome issues, then ONE
/// old-cursor read arrives, exactly the resumed-production defect the
/// oracle exists to catch. The oracle predicate must reject that
/// shape, so a green destructive oracle above proves something.
#[test]
fn negative_control_the_producer_freeze_oracle_rejects_a_resumed_read() {
    let freeze = ProducerFreezeWitness::default();
    let decode = TestDecode {
        behavior: SourceBehavior::EofAfter(SOURCE_FRAMES),
        duration: None,
        seeks: vec![ProviderSeekOutcome::MutatedThenFailed {
            diagnostic: "synthetic destructive outcome".to_owned(),
        }],
        freeze: freeze.clone(),
    };
    let mut endpoint = decode
        .open_media(std::path::Path::new(DUMMY_PATH))
        .expect("the double opens");
    assert!(
        matches!(
            endpoint.seek(Duration::from_secs(5)),
            ProviderSeekOutcome::MutatedThenFailed { .. }
        ),
        "precondition: the scripted destructive outcome issues"
    );
    let mut dst = vec![0.0f32; 256 * usize::from(TEST_FORMAT.channels)];
    assert!(
        matches!(endpoint.read_frames(&mut dst), Ok(DecodeOutcome::Frames(_))),
        "precondition: the resumed read produces old-cursor frames"
    );
    assert_eq!(
        freeze.post_failed_seek_reads(),
        1,
        "precondition: the witness counted the one resumed read"
    );
    assert!(
        rejects(|| {
            assert_eq!(
                freeze.post_failed_seek_reads(),
                0,
                "the producer resumed old-cursor production after the \
                 destructive seek"
            );
        }),
        "the producer-freeze oracle must reject the resumed-production shape"
    );
}

// --- pause x seek --------------------------------------------------------

/// A paused episode is seekable: the cutover commits through the PAUSE
/// engagement (its park is the same physical evidence class), the pause
/// intent and the Paused projection SURVIVE the seek, and — the
/// implementation corrective-1 behavior (C1) — the REBASE lands WHILE
/// STILL PAUSED: the leg consumes the committed payload mid-park, so
/// the projection reads at the landing before any resume. On resume the
/// content shows exactly the one cut and the projection climbs from the
/// landing.
#[test]
fn a_paused_episode_commits_its_seek_and_rebases_while_still_paused() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(30), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        let pre_seek_sample = handle.observe().position.expect("playing");
        handle.request_pause();
        assert!(
            wait_until(Duration::from_secs(5), || handle.observe().paused()),
            "precondition: the episode never established Paused: {:?}",
            handle.observe()
        );
        handle.request_seek(Duration::from_secs(5));
        // The commit must have routed — and REBASED — while still
        // paused, and nothing about the seek may have implicit-resumed
        // the episode.
        std::thread::sleep(Duration::from_millis(200));
        let during = handle.observe();
        assert!(
            during.paused(),
            "pause intent survives a seek; the seek never resumes: {during:?}"
        );
        assert_eq!(
            during.terminal_outcome, None,
            "a seek is never a terminal event"
        );
        assert!(
            during.position.is_some_and(|p| p >= FIVE_SECONDS),
            "the committed cut must rebase the projection to the landing \
             BEFORE the resume (still paused): {during:?} (pre-seek sample \
             {pre_seek_sample})"
        );
        handle.request_resume();
        assert!(
            wait_until(Duration::from_secs(5), || handle
                .observe()
                .position
                .is_some_and(|p| p >= FIVE_SECONDS)),
            "after resume the projection must climb from the landing: {:?}",
            handle.observe()
        );
        assert!(!handle.observe().paused(), "resumed is not paused");
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        assert_one_cut_to(&content(&witnesses), FIVE_SECONDS);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

// --- one-seek policy -----------------------------------------------------

/// One seek in flight: requests fired while the cut's protocol is still
/// running (held open by the armed tail probe) are INERT — no queueing,
/// no coalescing, no latest-wins. Exactly one cutover happens, at the
/// FIRST seek's landing; a queued or latest-wins policy would cut again.
#[test]
fn a_second_seek_while_one_is_in_flight_is_inert() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        // The armed probe holds the leg inside its seek-park tail
        // observation: the park cannot publish its quiescence, so the
        // commit decision cannot route while we fire the extra requests.
        witnesses.tail_probe.arm();
        handle.request_seek(Duration::from_secs(5));
        assert!(
            witnesses
                .tail_probe
                .wait_held_within(Duration::from_secs(5)),
            "precondition: the leg never parked under the cut's hold"
        );
        // Both later requests linearize while the first seek is provably
        // still in flight.
        handle.request_seek(Duration::from_secs(6));
        handle.request_seek(Duration::from_secs(7));
        std::thread::sleep(Duration::from_millis(200));
        witnesses.tail_probe.unhold();
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        // Exactly one cut, to the FIRST seek's landing — a queueing or
        // latest-wins policy would show a second cut (to 6 s or 7 s).
        assert_one_cut_to(&content(&witnesses), FIVE_SECONDS);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// A committed cut RESOLVES while the leg is pause-parked (the leg
/// consumes the payload mid-park and the worker frees the slot), so a
/// paused episode is seekable AGAIN immediately: a second seek fired
/// while still paused commits through the same pause attribution, cuts
/// again, and rebases the projection to the SECOND landing — still
/// without any resume. Nothing of the first cut is lost: its purge
/// already happened, and the never-wiped rule (slot occupied through
/// consumption, pinned white-box) makes an unwiped-payload hazard
/// unreachable — a new hold can only route after the previous payload
/// was consumed. Both mid-pause cuts purge pre-resume content, so the
/// consumed content shows exactly ONE visible discontinuity, at the
/// SECOND landing, after the resume.
#[test]
fn a_paused_episode_can_seek_again_after_its_committed_cut() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(30), move || {
        let second_landing = 6 * ONE_SECOND;
        let (witnesses, handle, mut runtime) = episode_with_source_policy(
            vec![
                ProviderSeekOutcome::Applied {
                    landing: Some(FIVE_SECONDS),
                },
                ProviderSeekOutcome::Applied {
                    landing: Some(second_landing),
                },
            ],
            &ProducerFreezeWitness::default(),
            true,
        );
        wait_for_position_past(&handle, HALF_A_SECOND);
        handle.request_pause();
        assert!(
            wait_until(Duration::from_secs(5), || handle.observe().paused()),
            "precondition: the episode never established Paused"
        );
        let paused_prefix = content(&witnesses).len();
        handle.request_seek(Duration::from_secs(5));
        // Cut #1 commits and rebases while still paused (C1).
        assert!(
            wait_until(Duration::from_secs(5), || handle
                .observe()
                .position
                .is_some_and(|p| p >= FIVE_SECONDS)),
            "cut #1 must rebase the projection mid-pause: {:?}",
            handle.observe()
        );
        assert!(handle.observe().paused(), "still paused after cut #1");
        // Real worker program order establishes slot-free, including on
        // Windows timer granularity; neither sleep nor repeated requests.
        wait_post_seek_read(&witnesses, 1);
        handle.request_seek(Duration::from_secs(6));
        assert!(
            wait_until(Duration::from_secs(5), || handle
                .observe()
                .position
                .is_some_and(|p| p >= second_landing)),
            "cut #2 must rebase the projection mid-pause to its own \
             landing: {:?}",
            handle.observe()
        );
        wait_post_seek_read(&witnesses, 2);
        let still = handle.observe();
        assert!(
            still.paused(),
            "the episode never resumed through either cut: {still:?}"
        );
        witnesses.eof_allowed.store(true, Ordering::SeqCst);
        handle.request_resume();
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        let cuts = witnesses.committed_offsets.lock().unwrap().clone();
        assert_eq!(
            cuts.iter().map(|c| c.1).collect::<Vec<_>>(),
            vec![paused_prefix, paused_prefix],
            "no submission during either paused cut"
        );
        assert_committed_windows(
            &witnesses,
            &[
                (Some(FIVE_SECONDS), FIVE_SECONDS),
                (Some(second_landing), second_landing),
            ],
        );
        // Both mid-pause cuts purged their pre-resume content, so the
        // consumed sequence shows exactly ONE visible discontinuity —
        // at the SECOND landing, after the resume.
        let values = content(&witnesses);
        let breaks = discontinuities(&values);
        assert_eq!(
            breaks.len(),
            1,
            "mid-pause cuts purge pre-resume content (breaks: {breaks:?})"
        );
        assert_eq!(
            values[breaks[0]] as u64, second_landing,
            "the visible cut must be the SECOND landing"
        );
    });
}

// --- stop x seek ---------------------------------------------------------

/// Stop intent recorded while a cut's protocol is running WINS: the
/// commit decision sees the stop, routes an abort, and the episode
/// settles `Stopped` — never `Completed` through a post-cut course,
/// never `Failed` through the seek.
#[test]
fn stop_intent_wins_over_an_in_flight_seek() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        witnesses.tail_probe.arm();
        handle.request_seek(Duration::from_secs(5));
        assert!(
            witnesses
                .tail_probe
                .wait_held_within(Duration::from_secs(5)),
            "precondition: the leg never parked under the cut's hold"
        );
        handle.request_stop();
        witnesses.tail_probe.unhold();
        assert_eq!(
            handle.wait_terminal(),
            EpisodeTerminalOutcome::Stopped,
            "stop recorded before the commit wins the race"
        );
        assert_eq!(handle.observe().failure_diagnostic, None);
        let stopped_at = witnesses.consumed.load(Ordering::SeqCst);
        std::thread::sleep(Duration::from_millis(200));
        assert_eq!(
            witnesses.consumed.load(Ordering::SeqCst),
            stopped_at,
            "a stopped episode produces nothing further"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

// --- unreachable commit boundary: liveness -------------------------------

/// The D14.5 commit boundary can be permanently unreachable when the
/// device's queued-to-play tail never quiesces (here: a device frozen
/// mid-buffer, emptying nothing per observation). The episode must still
/// be able to END: teardown stops the data plane first (the decode
/// relation's `edge.stop()`, before the worker join), and that is the
/// frozen failure policy's own "data plane not Open" episode-ending
/// class — the seek wait observes it, routes the abort release, and the
/// join returns. Before the protocol's waits read the data plane, they
/// polled only the session's own endings, which teardown records AFTER
/// the join: a cut over a never-quiescing tail wedged teardown forever.
/// This test is that counterexample's oracle — it fails by the harness
/// bound, not by an assertion, if the wait stops escaping.
#[test]
fn a_cut_over_a_never_draining_device_still_tears_down() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        // Freeze the device mid-buffer: every later tail observation
        // reports a non-empty queue, so the cut's park can never publish
        // its quiescence and the boundary is unreachable by construction.
        witnesses
            .device_tail
            .set_playout(Playout::FramesPerObservation(0));
        handle.request_seek(Duration::from_secs(5));
        assert!(
            wait_until(Duration::from_secs(5), || witnesses.device_tail.queued()
                > 0),
            "precondition: the device holds queued-to-play frames"
        );
        std::thread::sleep(Duration::from_millis(200));
        let stuck = handle.observe();
        assert_eq!(
            stuck.terminal_outcome, None,
            "the episode stays UNSETTLED with the cut in flight: {stuck:?}"
        );
        // The liveness claim: teardown completes.
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// Control for the regression above: an application stop releases the
/// cut over the same never-draining device through the recorded stop
/// intent (the class the wait already re-checked), so this side was
/// never the wedge. It pins that the fix did not make stop the only
/// escape the protocol has.
#[test]
fn a_stop_releases_a_cut_over_a_never_draining_device() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        witnesses
            .device_tail
            .set_playout(Playout::FramesPerObservation(0));
        handle.request_seek(Duration::from_secs(5));
        assert!(
            wait_until(Duration::from_secs(5), || witnesses.device_tail.queued()
                > 0),
            "precondition: the device holds queued-to-play frames"
        );
        std::thread::sleep(Duration::from_millis(200));
        handle.request_stop();
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Stopped);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// The device itself fails WHILE the leg is parked under the cut's
/// hold — the R1 half teardown cannot speak for (F5 implementation
/// corrective-4): no stop is requested, nothing tears the data plane
/// down, and the failed tail observation is the ONLY event that can
/// end the park. The mock's held observation pins the leg provably
/// inside the park before the failure is armed, so the interleaving is
/// deterministic, not raced. The whole chain must then run through
/// existing semantics only: the leg exits the park through its own
/// failure path, the dead render leg stops the data plane (the edge
/// goes terminal), the seek worker's data-plane escape fires, the
/// drain reports Aborted, and the episode settles D11 `Failed` — the
/// frozen "existing output/device-failure" class. Before the
/// corrective, the park masked the failure as "not quiesced yet": the
/// leg parked forever, the edge stayed Open, and the worker stayed
/// Pending with no episode ending ever recorded — this test fails by
/// the harness bound, not by an assertion, if that mask returns.
#[test]
fn a_device_failure_inside_the_cut_park_settles_failed_through_d11() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, HALF_A_SECOND);
        // Freeze the device mid-buffer first: the park's tail can never
        // quiesce, so whatever ends the park below cannot be an
        // incidental drain.
        witnesses
            .device_tail
            .set_playout(Playout::FramesPerObservation(0));
        assert!(
            wait_until(Duration::from_secs(5), || witnesses.device_tail.queued()
                > 0),
            "precondition: the device holds queued-to-play frames"
        );
        // Hold the leg's next PARK observation (only a park calls it):
        // once the accepted seek parks the leg, its first probe blocks
        // here — the deterministic in-park window.
        witnesses.tail_probe.arm();
        handle.request_seek(Duration::from_secs(5));
        assert!(
            witnesses
                .tail_probe
                .wait_held_within(Duration::from_secs(5)),
            "the leg never parked under the cut's hold"
        );
        // The endpoint invalidates while that observation is in flight:
        // every later observation — the park's next slice first — fails.
        witnesses.device_tail.fail_observations();
        witnesses.tail_probe.unhold();
        assert_eq!(
            handle.wait_terminal(),
            EpisodeTerminalOutcome::Failed,
            "a device failure inside the cut park is the existing D11 \
             output/device-failure class — never a hang, never Stopped"
        );
        let failed = handle.observe();
        assert!(
            failed.failure_diagnostic.is_some(),
            "the device failure carries its diagnostic: {failed:?}"
        );
        assert!(
            failed.position.is_none(),
            "the terminal Fact withdraws the projection"
        );
        let stopped_at = witnesses.consumed.load(Ordering::SeqCst);
        std::thread::sleep(Duration::from_millis(200));
        assert_eq!(
            witnesses.consumed.load(Ordering::SeqCst),
            stopped_at,
            "a failed episode must never resume production"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

// --- inert acceptance windows -------------------------------------------

/// The post-EOF drain window is explicitly NOT seekable, and a terminal
/// Fact freezes the whole command surface: a seek after Completed is
/// inert command history — nothing new plays, nothing changes.
#[test]
fn a_seek_after_the_episode_has_settled_is_inert() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let (witnesses, handle, mut runtime) = episode(Vec::new());
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        let values_before = content(&witnesses);
        handle.request_seek(Duration::from_secs(1));
        std::thread::sleep(Duration::from_millis(200));
        assert_eq!(content(&witnesses), values_before, "nothing new plays");
        let settled = handle.observe();
        assert_eq!(
            settled.terminal_outcome,
            Some(EpisodeTerminalOutcome::Completed)
        );
        assert!(
            settled.position.is_none(),
            "the projection stays withdrawn after the terminal Fact"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// A seek on a handle bound to no episode (never activated) is a no-op:
/// the command records nothing and cannot fabricate any state.
#[test]
fn a_seek_on_a_never_activated_episode_is_inert() {
    let handle = PlaybackSessionHandle::new();
    handle.request_seek(Duration::from_secs(1));
    let observation = handle.observe();
    assert_eq!(observation.terminal_outcome, None);
    assert_eq!(observation.position, None);
}

// --- seek x worker EOF (implementation corrective-1, C2) ------------------

/// A request_seek racing the worker's EOF exit can never wedge the
/// episode: recording/worker-exit ordering (atomic recording hold +
/// exit-funnel cleanup, reviewed in source) means
/// a request is rejected or its private record is cleared. A record may
/// be Accepted then aborted, or never-Accepted Refused/Inert when ending
/// invalidated Open before plant (temporal semantics §6.1) —
/// and EITHER way the episode's ordinary EOF course completes. This is
/// the integration sweep over that envelope: requests are hammered while
/// the episode approaches and enters its EOF window, and the terminal
/// MUST settle `Completed` (a stranded hold would park the leg past the
/// final drain and D11 Completed would never settle). The deterministic
/// boundary witnesses live in the completion and real-worker suites;
/// they test admission and cleanup, while the strict order of the real
/// funnel's two calls remains a source-review obligation. This sweep
/// checks integration liveness on visited schedules; the burst and its
/// pacing do not prove that a particular exit interleaving occurred.
#[test]
fn seek_acceptance_racing_worker_eof_settles_without_wedge() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(30), move || {
        let (_witnesses, handle, mut runtime) = episode(Vec::new());
        wait_for_position_past(&handle, 7 * ONE_SECOND);
        // Hammer the acceptance envelope with a BOUNDED burst while the
        // worker approaches and passes its EOF exit. Requests target a
        // LATE landing (7.5 s), so even an accepted-and-completed cut
        // keeps the ordinary short course to EOF instead of rewinding
        // the episode into a self-sustaining replay loop; and the burst
        // is finite (200 requests, 2 ms apart), so the sweep always
        // terminates. An accepted seek whose worker then exits is
        // aborted by the exit cleanup — either way the drain completes.
        let hammer_handle = handle.clone();
        let hammer = std::thread::spawn(move || {
            for _ in 0..200 {
                hammer_handle.request_seek(Duration::from_millis(7500));
                std::thread::sleep(Duration::from_millis(2));
            }
        });
        hammer.join().expect("the hammer thread joins");
        let outcome = handle.wait_terminal();
        assert_eq!(
            outcome,
            EpisodeTerminalOutcome::Completed,
            "the seek × EOF race must never wedge the drain or relabel \
             the episode's ordinary EOF course (diagnostic: {:?})",
            handle.observe()
        );
        assert!(
            handle.observe().position.is_none(),
            "the terminal Fact withdraws the projection"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}
