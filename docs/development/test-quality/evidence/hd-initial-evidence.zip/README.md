# H-D initial execution archive

Evidence only. run.py collects command argv, source snapshots, patches, logs and
hashes; it is no product/test scheduler. Replay recorded argv from repository root.
Source identity includes working-tree patch/snapshots. Target runs preceded
later comment/docs-only changes; compare Rust source hashes. The isolated gate
at e70a5b4 rebuilt this checkout: 876 tests/0 failures and all 7 checks PASS.

Initial gate failure and diagnosis preserved, not semantic RED. Reviewer B run 0
is zero-test target discovery, excluded; runs 1-7 execute 10 tests. A SOURCE_REVIEW
only. No new swapped-order mutant. Historical mutations keep historical source
identity; base CI logs at bc0b317 are not final PR proof. Later publication and
PR CI receipts are separate. Baseline shared binaries were not freshly rebuilt;
later collected hashes cannot establish original overwritten binary identity.
Final isolated gate has fresh source/artifacts (41 executed binary paths/hashes).
No physical audio/FFI/other-platform/new-formal proof.
