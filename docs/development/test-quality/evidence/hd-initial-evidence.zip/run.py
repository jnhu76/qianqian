import subprocess,datetime,json,hashlib,sys,pathlib,platform,os
root=pathlib.Path('/home/hoo/Source/qianqian')
base=pathlib.Path('/tmp/qianqian-hd-audit/runs');base.mkdir(exist_ok=True)
label=sys.argv[1];cmd=sys.argv[2:]
run=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'-'+label
out=base/run;out.mkdir()
sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
files=['apps/headless/src/machine_input.rs','apps/headless/src/machine_input/tests.rs','crates/qianqian-playback/src/completion.rs','crates/qianqian-playback/src/session.rs','crates/qianqian-playback/tests/seek_seam.rs','docs/adr/ADR-PBK-001.md','docs/adr/ADR-PBK-002.md','docs/architecture/playback-execution-model.md']
hashes={}
for f in files:
 data=(root/f).read_bytes();dest=out/'source'/f;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);hashes[f]=hashlib.sha256(data).hexdigest()
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=root);(out/'working-tree.patch').write_bytes(patch)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'stdout-stderr.log').open('wb') as log:
 process=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
meta=dict(run_id=run,head=sha,argv=cmd,platform=platform.platform(),start=start,end=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit_code=process.returncode,source_sha256=hashes,patch_sha256=hashlib.sha256(patch).hexdigest(),log_sha256=hashlib.sha256((out/'stdout-stderr.log').read_bytes()).hexdigest())
artifacts={}
for line in (out/'stdout-stderr.log').read_text(errors='replace').splitlines():
 try: event=json.loads(line)
 except (json.JSONDecodeError,ValueError): continue
 if event.get('reason')=='compiler-artifact' and event.get('executable'):
  binary=pathlib.Path(event['executable'])
  if binary.exists(): artifacts[str(binary)]=hashlib.sha256(binary.read_bytes()).hexdigest()
import re
for match in re.finditer(r'Running .+?\(([^)]+)\)',(out/'stdout-stderr.log').read_text(errors='replace')):
 binary=pathlib.Path(match.group(1))
 if not binary.is_absolute(): binary=root/binary
 if binary.is_file(): artifacts[str(binary)]=hashlib.sha256(binary.read_bytes()).hexdigest()
meta['compiler_artifact_executable_sha256']=artifacts
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(dict(run_id=run,exit_code=process.returncode,log=str(out/'stdout-stderr.log'))),flush=True)
sys.exit(process.returncode)
