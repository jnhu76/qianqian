//! F3 pause/resume-seam tests (ADR-PBK-002 D14.7): the application-facing
//! pause/resume commands drive the REAL Playback Session through the
//! mechanism-A render-loop gate, on mechanism doubles at the ports seams.
//! Platform-independent: these run wherever the workspace tests run; the
//! physical audibility/latency claims live in the F3-GATE evidence
//! (`experiments/f3-pause-mechanism`), not here.
//!
//! Truth classes under test: pause/resume are commands (inert after
//! settlement); engagement and output-tail quiescence are mechanism
//! evidence belonging to the CURRENT engagement only; Paused is the
//! derived projection of the frozen establishment conjunction; resume
//! is command-only — disengagement is NOT a product projection
//! (D14.7 AUTHORITY-CORRECTIVE); D11 terminal outcomes are untouched
//! by any of it.

mod common;

use std::path::Path;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::time::{Duration, Instant};

use qianqian_app::QianqianApp;
use qianqian_audio_api::ports::{
    DecodeError, DecodeOpenError, DecodeOutcome, DecodedPcmStream, PcmDecode, PcmFormat,
    ProviderSeekOutcome,
};
use qianqian_composition::{DesiredEntry, FiberState, Revision};
use qianqian_playback::{
    EpisodeTerminalOutcome, PauseEngagement, PlaybackSessionHandle, playback_session_spec,
};

use common::{
    DeviceTail, OutputBehavior, Playout, SourceBehavior, TailProbe, TestDecode, TestOutput, within,
};

const DUMMY_PATH: &str = "test://pause-seam";

fn desired(id: &str, component: &'static str) -> DesiredEntry {
    DesiredEntry::enabled(id, component, Revision::new(1))
}

/// A decode source producing ~`seconds` of frames at the test format
/// before clean EOF.
fn seconds_of_audio(seconds: u64) -> SourceBehavior {
    SourceBehavior::EofAfter(44_100 * seconds as usize)
}

/// A decode source producing ~`seconds` of frames fast, then one frame
/// per 50ms forever — never EOF. The multi-cycle release tests wait for
/// the mechanism to observe a release while the episode stays alive; a
/// finite source can drain to EOF during a test's release window and
/// settle the episode (freezing the evidence latches at settlement)
/// before the observation is polled, so these tests keep the episode
/// unsettled on purpose.
fn endless_audio(seconds: u64) -> SourceBehavior {
    SourceBehavior::Paced {
        after: 44_100 * seconds as usize,
        delay: Duration::from_millis(50),
    }
}

/// Register the standard F3 episode: a decode source, an output double
/// sharing the caller's consumption counter, mock device-tail flag and
/// tail probe, and the real session over `handle`.
fn registered_runtime(
    source: SourceBehavior,
    output: OutputBehavior,
    consumed: Arc<AtomicUsize>,
    device_tail: DeviceTail,
    tail_probe: TailProbe,
    handle: PlaybackSessionHandle,
) -> QianqianApp {
    registered_runtime_with_decode(
        EofWitnessedDecode::new(TestDecode::new(source)),
        output,
        consumed,
        device_tail,
        tail_probe,
        handle,
    )
}

/// [`registered_runtime`] with the caller owning the decode double: the
/// runtime captures clones of `decode` (every clone sharing its EOF
/// witness), while the test may keep `decode.eof.clone()` to prove the
/// decode-EOF premise through the real `read_frames` path before it
/// issues a stop. Live on every platform via [`registered_runtime`];
/// only the latch's `returned()` reader is Linux-scoped (the post-EOF
/// stop test), which is where the dead-code allowance lives.
fn registered_runtime_with_decode(
    decode: EofWitnessedDecode,
    output: OutputBehavior,
    consumed: Arc<AtomicUsize>,
    device_tail: DeviceTail,
    tail_probe: TailProbe,
    handle: PlaybackSessionHandle,
) -> QianqianApp {
    let mut runtime = QianqianApp::new();

    runtime
        .register_component({
            qianqian_composition::ComponentSpec::new("test_decode_plugin")
                .provides::<qianqian_audio_api::ports::PcmDecodeCapability>()
                .on_activate(move |ctx| {
                    ctx.provide::<qianqian_audio_api::ports::PcmDecodeCapability>(
                        std::rc::Rc::new(decode.clone()),
                    )
                    .map_err(|e| qianqian_composition::ActivationError::new(format!("{e:?}")))?;
                    Ok(())
                })
        })
        .expect("decode provider registers");

    runtime
        .register_component({
            qianqian_composition::ComponentSpec::new("test_output_plugin")
                .provides::<qianqian_audio_api::ports::AudioOutputCapability>()
                .on_activate(move |ctx| {
                    let mut service = TestOutput::observed_with_tail(
                        output,
                        consumed.clone(),
                        device_tail.clone(),
                    );
                    service.tail_probe = tail_probe.clone();
                    ctx.provide::<qianqian_audio_api::ports::AudioOutputCapability>(
                        std::rc::Rc::new(service),
                    )
                    .map_err(|e| qianqian_composition::ActivationError::new(format!("{e:?}")))?;
                    Ok(())
                })
        })
        .expect("output provider registers");

    runtime
        .register_component(playback_session_spec(
            std::path::PathBuf::from(DUMMY_PATH),
            handle,
        ))
        .expect("session registers");
    runtime
}

/// Decode-side EOF witness: latched at the single point where a REAL
/// production decode worker's `read_frames` call returns
/// `Ok(DecodeOutcome::Eof)` — decode-seam mechanism evidence, not a
/// Fact and not a projection. The provider's clones share the latch
/// while the test keeps one handle, the same provider-clones-share
/// shape as the fixture's `ProducerFreezeWitness`; the test only polls
/// it, so it can never block the worker it observes.
#[derive(Clone, Default)]
struct EofWitness {
    latched: Arc<AtomicBool>,
}

impl EofWitness {
    /// Has a `read_frames` call returned EOF yet? (Polled only by the
    /// Linux-scoped post-EOF stop test; off Linux nothing reads it.)
    #[cfg_attr(not(target_os = "linux"), allow(dead_code))]
    fn returned(&self) -> bool {
        self.latched.load(Ordering::SeqCst)
    }

    fn latch(&self) {
        self.latched.store(true, Ordering::SeqCst);
    }
}

/// The pause-seam decode double: every behavior delegates to the shared
/// fixture `TestDecode`, plus the EOF witness above. Local to this
/// binary because the shared `TestDecode` cannot grow a field without
/// breaking other binaries' struct-literal constructions of it, and no
/// other binary needs the witness.
#[derive(Clone)]
struct EofWitnessedDecode {
    inner: TestDecode,
    eof: EofWitness,
}

impl EofWitnessedDecode {
    fn new(inner: TestDecode) -> Self {
        Self {
            inner,
            eof: EofWitness::default(),
        }
    }
}

impl PcmDecode for EofWitnessedDecode {
    fn open_media(&self, path: &Path) -> Result<Box<dyn DecodedPcmStream>, DecodeOpenError> {
        let inner = self.inner.open_media(path)?;
        Ok(Box::new(EofWitnessedStream {
            inner,
            eof: self.eof.clone(),
        }))
    }
}

/// The endpoint wrapper: the latch lives exactly on the `Eof` return
/// the production worker drives — the boundary a witnessing test
/// observes, deliberately BEFORE the worker's own `edge.close_eof()`
/// (which stays invisible to the test; see the Linux thread-gone
/// premise in `stop_from_parked_after_eof_still_completes` for how that
/// seam is closed).
struct EofWitnessedStream {
    inner: Box<dyn DecodedPcmStream>,
    eof: EofWitness,
}

impl DecodedPcmStream for EofWitnessedStream {
    fn format(&self) -> PcmFormat {
        self.inner.format()
    }

    fn source_duration(&self) -> Option<Duration> {
        self.inner.source_duration()
    }

    fn read_frames(&mut self, dst: &mut [f32]) -> Result<DecodeOutcome, DecodeError> {
        let outcome = self.inner.read_frames(dst)?;
        if matches!(outcome, DecodeOutcome::Eof) {
            self.eof.latch();
        }
        Ok(outcome)
    }

    fn seek(&mut self, target: Duration) -> ProviderSeekOutcome {
        self.inner.seek(target)
    }
}

fn activate(runtime: &mut QianqianApp) {
    runtime
        .revise_desired(vec![
            desired("decode", "test_decode_plugin"),
            desired("output", "test_output_plugin"),
            desired("session", "playback_session"),
        ])
        .expect("composition is legal");
}

/// Bounded poll for an asynchronously-published observation.
fn wait_until(limit: Duration, mut predicate: impl FnMut() -> bool) -> bool {
    let deadline = Instant::now() + limit;
    loop {
        if predicate() {
            return true;
        }
        if Instant::now() >= deadline {
            return false;
        }
        std::thread::sleep(Duration::from_millis(5));
    }
}

/// The full establishment wait: intent is not enough — the projection
/// may only go true through engagement AND the current engagement's
/// tail quiescence (the mock device plays its queue out — `Playout::
/// Everything`, the default — so the first bounded park slice drains
/// it and quiescence follows).
fn wait_established(handle: &PlaybackSessionHandle) {
    assert!(
        wait_until(Duration::from_secs(5), || handle.observe().paused()),
        "the Paused projection never established: {:?}",
        handle.observe()
    );
}

/// The D14.7-corrective negative oracle in isolation: with the mock
/// device still holding queued frames, an engagement must NOT
/// establish Paused.
fn assert_engaged_but_not_paused(handle: &PlaybackSessionHandle) {
    assert!(
        wait_until(Duration::from_secs(5), || handle.observe().pause_engagement
            == PauseEngagement::Engaged),
        "the render leg never engaged: {:?}",
        handle.observe()
    );
    let snapshot = handle.observe();
    assert!(
        snapshot.pause_requested && snapshot.pause_engagement == PauseEngagement::Engaged,
        "expected engaged pause intent: {snapshot:?}"
    );
    assert!(
        !snapshot.paused(),
        "stale/absent tail quiescence must not establish Paused: {snapshot:?}"
    );
}

/// A pause that establishes, then a resume that releases it, repeated
/// cycles staying truthful — including the D14.7-corrective negative
/// oracle: a NEW pause while the mock device still plays its tail must
/// NOT project Paused, and only the NEW engagement's quiescence may.
#[test]
fn pause_establishes_resume_releases_and_cycles_stay_truthful() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();
        let mut runtime = registered_runtime(
            endless_audio(30),
            OutputBehavior::Consume,
            consumed.clone(),
            device_tail.clone(),
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);

        // Playing before anything is paused: consumption progresses.
        assert!(
            wait_until(Duration::from_secs(5), || consumed.load(Ordering::SeqCst)
                > 0),
            "the episode never produced audio"
        );
        let observation = handle.observe();
        assert!(!observation.paused(), "fresh episode: {observation:?}");
        assert!(
            observation.pause_engagement == PauseEngagement::Disengaged,
            "no engagement yet: {observation:?}"
        );

        // Cycle 1: pause -> full establishment -> resume -> released.
        // The truthful release observation is the COMMAND state cleared
        // plus the current engagement ended (`Disengaged` spelling):
        // there is no Resumed projection (D14.7 AUTHORITY-CORRECTIVE).
        handle.request_pause();
        assert!(handle.observe().pause_requested, "intent is recorded");
        wait_established(&handle);
        handle.request_resume();
        assert!(
            wait_until(Duration::from_secs(5), || {
                let observation = handle.observe();
                !observation.pause_requested
                    && observation.pause_engagement == PauseEngagement::Disengaged
            }),
            "resume never released the episode: {:?}",
            handle.observe()
        );

        // Cycle 2 — the stale-quiescence negative oracle: the mock
        // device still holds queued frames while the leg re-engages (its
        // playout stops, so the frames it already accepted stay queued).
        device_tail.set_playout(Playout::FramesPerObservation(0));
        handle.request_pause();
        assert_engaged_but_not_paused(&handle);

        // Only the CURRENT engagement's tail quiescence establishes: the
        // device plays its queue out again, so the tail drains.
        device_tail.set_playout(Playout::Everything);
        wait_established(&handle);

        handle.request_resume();
        assert!(
            wait_until(Duration::from_secs(5), || {
                let observation = handle.observe();
                !observation.pause_requested
                    && observation.pause_engagement == PauseEngagement::Disengaged
            }),
            "second resume never released: {:?}",
            handle.observe()
        );

        // Commands stay commands: stop settles the episode normally.
        handle.request_stop();
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Stopped);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// Stop from an established pause mid-play: the gate release lets the
/// leg reach the stopped edge and the episode settles the ordinary
/// `Stopped` fact (D14.7 terminal interactions; D11 monotonicity —
/// late pause/resume history never relabels it).
#[test]
fn stop_from_an_established_pause_settles_stopped_and_late_commands_stay_inert() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();
        // The premise "still playing at the stop" must not rest on the
        // source's length against decode/render scheduling: a finite
        // source could drain toward EOF while a slow machine establishes
        // the pause, and an EOF-completed settle would false-RED the
        // Stopped oracle below. `endless_audio` keeps the episode
        // unsettled until the stop, structurally (Paced never returns
        // Eof), so the shape under test is the only reachable one.
        let mut runtime = registered_runtime(
            endless_audio(30),
            OutputBehavior::Consume,
            consumed,
            device_tail,
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);

        handle.request_pause();
        wait_established(&handle);

        handle.request_stop();
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Stopped);
        let observation = handle.observe();
        assert_eq!(
            observation.terminal_outcome,
            Some(EpisodeTerminalOutcome::Stopped)
        );
        // The settled episode is never Paused, whatever the
        // mechanism evidence still latches (D14.7 unsettled guard).
        assert!(!observation.paused());
        assert!(
            observation.pause_requested,
            "pause intent stays recorded history"
        );

        // Late pause/resume after settlement: inert command history.
        handle.request_pause();
        handle.request_resume();
        handle.request_pause();
        let observation = handle.observe();
        assert_eq!(
            observation.terminal_outcome,
            Some(EpisodeTerminalOutcome::Stopped),
            "D11 monotonicity: settlement is never relabelled"
        );
        assert!(!observation.paused());

        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// Pause intent routed before activation: the render leg's FIRST loop
/// iteration parks at the gate (start-paused), and EOF while parked
/// leaves the episode unsettled until it is released and drained.
#[test]
fn eof_while_parked_leaves_the_episode_unsettled_until_resumed() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();

        // Record pause intent BEFORE the episode exists: it is applied
        // the moment the render leg reaches its gate.
        handle.request_pause();
        assert!(handle.observe().pause_requested);

        // A tiny source: the worker produces, EOFs and exits while the
        // render leg stays parked at the gate.
        let mut runtime = registered_runtime(
            SourceBehavior::EofAfter(64),
            OutputBehavior::Consume,
            consumed.clone(),
            device_tail,
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);

        // Start-paused: the parked leg establishes the projection
        // without ever having submitted a frame.
        wait_established(&handle);
        assert_eq!(
            consumed.load(Ordering::SeqCst),
            0,
            "a parked leg must not consume"
        );

        // EOF while parked: the worker has long exited (tiny source),
        // yet no terminal Fact may commit while the leg is parked.
        assert!(
            !wait_until(Duration::from_millis(500), || handle
                .observe()
                .terminal_outcome
                .is_some()),
            "the episode settled while parked at the gate (D14.7: EOF \
             while parked stays unsettled until released)"
        );

        // Resume-and-drain completes it.
        handle.request_resume();
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Completed);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// Stop from a parked post-EOF episode: the gate must NOT force-abort —
/// the tail plays out and drains, settling the SAME Completed fact as
/// today's stop-after-EOF (no Failed{device} fabrication).
///
/// The post-EOF premise is PROVEN, never assumed (no sleep, source
/// shortness, or timing stands for synchronization): `wait_established`
/// only proves the leg is parked — its establishment needs the leg's
/// own first park slice and says nothing about worker progress — so the
/// test additionally proves (1) the PRODUCTION worker's `read_frames`
/// returned Eof (decode-seam evidence, polled without blocking the
/// worker), and (2) that the worker's OS thread is fully gone: thread
/// exit is program-ordered after the worker's `edge.close_eof()` and
/// `worker_exited` publication (the session's single exit funnel),
/// which closes the one seam where the stop's own `edge.stop()` could
/// still win the edge's first-wins terminal race and legally relabel
/// the episode `Stopped`.
///
/// Platform scope (honest NOT_RUN, not a debt hidden behind a runnable
/// assertion): no portable observation of the post-`close_eof` commit
/// exists — the edge is crate-private by design and the ports seam
/// (`RenderPcmInput`) exposes no terminal query — so the test runs on
/// Linux only, where the thread-gone witness proves the premise. On
/// other targets this property is NOT_RUN here, never reported as
/// passing; giving it a portable witness would need a production-side
/// test seam (a product API decision outside this pilot). The sibling
/// negative control below stays cross-platform: its oracle needs no
/// EOF premise, since without worker-terminal EOF evidence `Stopped`
/// is structurally the only reachable outcome in every legal
/// interleaving.
#[test]
#[cfg(target_os = "linux")]
fn stop_from_parked_after_eof_still_completes() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();
        handle.request_pause();

        let decode = EofWitnessedDecode::new(TestDecode::new(SourceBehavior::EofAfter(64)));
        let eof = decode.eof.clone();
        let mut runtime = registered_runtime_with_decode(
            decode,
            OutputBehavior::Consume,
            consumed,
            device_tail,
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);
        wait_established(&handle);

        // Premise: decode EOF happened through the real read_frames
        // call the production worker drives — `EofAfter(64)` alone
        // would only make that probable, not proven.
        assert!(
            wait_until(Duration::from_secs(5), || eof.returned()),
            "decode never reached EOF through the real read_frames path"
        );
        // Premise: the worker is fully gone, so its close_eof and
        // worker_exited(Eof) both happened before the stop below
        // issues edge.stop().
        assert!(
            common::named_thread_gone_within("qianqian-decode", Duration::from_secs(5)),
            "the decode worker never exited after EOF"
        );

        handle.request_stop();
        assert_eq!(
            handle.wait_terminal(),
            EpisodeTerminalOutcome::Completed,
            "stop-from-paused-after-EOF must play out and drain, not fail"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_no_leg_threads();
    });
}

/// Negative control for the post-EOF oracle above: stop from an
/// established pause whose decode NEVER EOFs (one paced frame per
/// 50ms, forever) must settle `Stopped`. `Completed` is structurally
/// unreachable in this shape — it requires worker-terminal EOF
/// evidence the resolver never receives — so this pins that the target
/// test's `Completed` assertion rests on the EOF premise rather than
/// accepting any stopped-from-paused shape.
#[test]
fn stop_from_parked_without_eof_settles_stopped() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();
        handle.request_pause();

        let mut runtime = registered_runtime(
            SourceBehavior::Paced {
                after: 0,
                delay: Duration::from_millis(50),
            },
            OutputBehavior::Consume,
            consumed,
            device_tail,
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);
        wait_established(&handle);

        // No EOF premise here: the stop is free to race the worker,
        // and every legal interleaving settles Stopped.
        handle.request_stop();
        assert_eq!(
            handle.wait_terminal(),
            EpisodeTerminalOutcome::Stopped,
            "stop from a parked episode whose decode never EOF'd must \
             settle Stopped, never Completed"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_no_leg_threads();
    });
}

/// Failure while parked settles immediately by the existing precedence,
/// and the teardown releases the parked gate (dispose must terminate).
#[test]
fn failure_while_parked_settles_failed_without_wedging_teardown() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();
        handle.request_pause();

        let mut runtime = registered_runtime(
            SourceBehavior::FailAfter(64),
            OutputBehavior::Consume,
            consumed,
            device_tail,
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);

        // The leg parks (never established against a failed decode —
        // and once settled, never at all).
        assert!(
            wait_until(Duration::from_secs(5), || handle.observe().terminal_outcome
                == Some(EpisodeTerminalOutcome::Failed)),
            "failure while parked never settled: {:?}",
            handle.observe()
        );
        assert!(
            !handle.observe().paused(),
            "a settled episode is never Paused"
        );

        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Failed);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_no_leg_threads();
    });
}

/// Stop while the producer is wedged through pause backpressure: the
/// edge is full and the decode worker is blocked mid-write; the stop
/// wakes BOTH participants (worker via the data-plane stop, render leg
/// via the gate release) and no thread leaks.
#[test]
fn stop_wakes_a_producer_blocked_through_pause_backpressure() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(30), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();

        // The consumer is slower than the producer: the bounded edge
        // fills long before EOF and the worker blocks mid-write.
        let mut runtime = registered_runtime(
            seconds_of_audio(30),
            OutputBehavior::SlowConsume {
                per_read: Duration::from_millis(50),
            },
            consumed.clone(),
            device_tail,
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);

        // Playback progressing, then pause: consumption halts entirely
        // (the parked leg submits nothing), the edge fills, and the
        // producer blocks behind it.
        assert!(
            wait_until(Duration::from_secs(5), || consumed.load(Ordering::SeqCst)
                > 0),
            "the episode never produced audio"
        );
        handle.request_pause();
        wait_established(&handle);
        let at_pause = consumed.load(Ordering::SeqCst);
        assert!(
            !wait_until(Duration::from_millis(400), || consumed
                .load(Ordering::SeqCst)
                != at_pause),
            "a parked leg must not consume (pause backpressure)"
        );

        // Stop through the backpressure: both legs must wake.
        handle.request_stop();
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Stopped);
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_no_leg_threads();
    });
}

/// A pause command that linearizes AFTER stop intent — the deterministic
/// shape of the stop→settlement window race — is recorded as inert
/// command history but must NOT re-park the released episode: the gate
/// stays released, the leg reaches the stopped edge, and the episode
/// settles `Stopped` with bounded latency (D14.7: stop wakes every
/// parked participant; the stop-from-paused→Stopped interaction).
#[test]
fn pause_routed_after_stop_cannot_repark_the_released_episode() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(20), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let handle = PlaybackSessionHandle::new();

        // Stop first, THEN pause: both before activation. Without
        // linearized routing the second command would park the gate the
        // stop just released, and this episode would never settle.
        handle.request_stop();
        handle.request_pause();
        let observation = handle.observe();
        assert!(observation.stop_requested, "stop intent recorded");
        assert!(
            observation.pause_requested,
            "pause stays recorded command history"
        );

        let mut runtime = registered_runtime(
            seconds_of_audio(30),
            OutputBehavior::Consume,
            consumed,
            device_tail,
            TailProbe::default(),
            handle.clone(),
        );
        activate(&mut runtime);

        // Bounded settlement: the leg must reach the stopped edge, not
        // sit parked against released intent.
        assert_eq!(handle.wait_terminal(), EpisodeTerminalOutcome::Stopped);
        assert!(
            !handle.observe().paused(),
            "a settled episode is never Paused"
        );
        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_no_leg_threads();
    });
}

/// A pause that linearizes AFTER the teardown release must not re-park
/// the leg: the stream teardown releases the gate and then joins it, so
/// a pause landing between the two would wedge `stop_and_join` forever
/// (the teardown-side twin of the stop-linearization oracle). The leg
/// is held inside a slow (legal) tail observation, so it cannot observe
/// the release until the hostile pause has routed and the probe lets
/// go — the ordering is decided by the routing linearization, not by a
/// race. If extreme scheduling ever delayed dispose past the hostile
/// pause, the test would degrade to the safe interleaving (still
/// passing, no longer exercising the suppressor); the mutation check
/// is what proves the oracle's bite.
#[test]
fn pause_routed_after_teardown_release_cannot_wedge_the_join() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(30), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let tail_probe = TailProbe::default();
        let handle = PlaybackSessionHandle::new();
        let mut runtime = registered_runtime(
            endless_audio(30),
            OutputBehavior::Consume,
            consumed.clone(),
            device_tail.clone(),
            tail_probe.clone(),
            handle.clone(),
        );
        activate(&mut runtime);

        assert!(
            wait_until(Duration::from_secs(5), || consumed.load(Ordering::SeqCst)
                > 0),
            "the episode never produced audio"
        );

        // Park the leg and hold it inside its first (slow, legal) tail
        // observation: from here it cannot observe any release until the
        // probe lets go.
        tail_probe.arm();
        handle.request_pause();
        assert!(
            wait_until(Duration::from_secs(5), || handle.observe().pause_engagement
                == PauseEngagement::Engaged),
            "the render leg never engaged: {:?}",
            handle.observe()
        );
        tail_probe.wait_held();

        // Fire the hostile pause from another thread well after dispose
        // began (dispose is already inside the teardown join by then:
        // the release runs within microseconds of dispose on this
        // thread, five orders of magnitude before the pause fires), and
        // only then let the leg re-check. With linearized routing the
        // post-release pause is inert and the leg exits; without it, it
        // re-parks and the join below never returns.
        let hostile = {
            let handle = handle.clone();
            let tail_probe = tail_probe.clone();
            std::thread::spawn(move || {
                std::thread::sleep(Duration::from_millis(100));
                handle.request_pause();
                tail_probe.unhold();
            })
        };
        let snapshot = runtime.dispose().snapshot;
        hostile.join().expect("the hostile pauser joins");
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
    });
}

/// The D14.7 AUTHORITY-CORRECTIVE never-activated oracle. A
/// never-activated episode can legally accumulate pre-activation pause
/// intent, a PARKED render gate (engagement ack), and then an open
/// abort that permanently closes the gate and joins the leg. On that
/// episode the previously frozen Resumed proposition (unsettled ∧
/// resume released ∧ disengagement observed) evaluated TRUE after a
/// later resume — while the render leg is provably gone and can never
/// submit again. That proposition was removed as a product projection;
/// this oracle pins the truthful residue: engagement really happened
/// before the abort (witness), the episode stays unsettled (D11
/// activation firewall), the activation diagnostic travels, resume
/// stays command-only, Paused never establishes, and the closed gate
/// admits no later engagement. The compile-time absence of a public
/// `resumed()`/`pause_disengaged_observed` surface is pinned by the
/// boundary gate's episode-handle allowlist + negative control.
#[test]
fn a_never_activated_open_aborted_episode_has_no_resumed_proposition() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(30), move || {
        let consumed = Arc::new(AtomicUsize::new(0));
        let device_tail = DeviceTail::default();
        let tail_probe = TailProbe::default();
        // Armed from the start: the aborted leg is proven parked through
        // its held (armed) tail observation inside the park loop.
        tail_probe.arm();
        let open_abort_engaged = Arc::new(AtomicBool::new(false));
        let handle = PlaybackSessionHandle::new();

        // Pre-activation pause: intent is routed before any leg exists.
        handle.request_pause();
        assert!(handle.observe().pause_requested);

        let mut runtime = QianqianApp::new();
        runtime
            .register_component({
                qianqian_composition::ComponentSpec::new("test_decode_plugin")
                    .provides::<qianqian_audio_api::ports::PcmDecodeCapability>()
                    .on_activate(|ctx| {
                        let service = TestDecode::new(seconds_of_audio(30));
                        ctx.provide::<qianqian_audio_api::ports::PcmDecodeCapability>(
                            std::rc::Rc::new(service),
                        )
                        .map_err(|e| {
                            qianqian_composition::ActivationError::new(format!("{e:?}"))
                        })?;
                        Ok(())
                    })
            })
            .expect("decode provider registers");
        runtime
            .register_component({
                let consumed = consumed.clone();
                let device_tail = device_tail.clone();
                let tail_probe = tail_probe.clone();
                let open_abort_engaged = open_abort_engaged.clone();
                qianqian_composition::ComponentSpec::new("test_output_plugin")
                    .provides::<qianqian_audio_api::ports::AudioOutputCapability>()
                    .on_activate(move |ctx| {
                        let service = TestOutput::open_timeout_abort(
                            consumed.clone(),
                            device_tail.clone(),
                            tail_probe.clone(),
                            open_abort_engaged.clone(),
                        );
                        ctx.provide::<qianqian_audio_api::ports::AudioOutputCapability>(
                            std::rc::Rc::new(service),
                        )
                        .map_err(|e| {
                            qianqian_composition::ActivationError::new(format!("{e:?}"))
                        })?;
                        Ok(())
                    })
            })
            .expect("output provider registers");
        runtime
            .register_component(playback_session_spec(
                std::path::PathBuf::from(DUMMY_PATH),
                handle.clone(),
            ))
            .expect("session registers");
        activate(&mut runtime);

        // The old formula's false premise, pinned as a precondition:
        // the leg REALLY parked at the gate before the abort (so
        // disengagement evidence really exists).
        assert!(
            open_abort_engaged.load(Ordering::SeqCst),
            "precondition: the render leg never parked before the abort"
        );

        let snap = runtime.composition_snapshot();
        assert_eq!(
            snap.fibers.get("session").map(|f| f.state),
            Some(FiberState::Failed),
            "the open abort lands the session FAILED"
        );

        let observation = handle.observe();
        // D11 activation firewall: an episode that never started has no
        // terminal Fact — the abort is NOT forged into Failed.
        assert_eq!(
            observation.terminal_outcome, None,
            "an open abort must never forge a terminal Fact: {observation:?}"
        );
        // The activation diagnostic travels separately.
        assert!(
            observation
                .activation_error
                .as_deref()
                .is_some_and(|m| m.contains("render stream open failed")),
            "activation diagnostic: {observation:?}"
        );
        // No Paused establishment, and no engagement latched after the
        // abort released the parked leg.
        assert!(!observation.paused());
        assert_eq!(observation.pause_engagement, PauseEngagement::Disengaged);
        assert!(
            observation.pause_requested,
            "pre-activation intent stays recorded history"
        );

        // The resume after the failure: command state only. There is NO
        // public Resumed proposition to become true — the render leg is
        // gone and the gate is permanently closed.
        handle.request_resume();
        let observation = handle.observe();
        assert!(!observation.pause_requested);
        assert!(!observation.paused());
        assert_eq!(observation.terminal_outcome, None);

        // The closed gate stays closed: a later pause records intent but
        // routes nothing — no engagement can ever arrive, so Paused can
        // never establish on this episode.
        handle.request_pause();
        assert!(handle.observe().pause_requested);
        assert!(
            !wait_until(Duration::from_millis(500), || handle
                .observe()
                .pause_engagement
                != PauseEngagement::Disengaged),
            "the closed gate admitted an engagement after the open abort"
        );
        assert!(!handle.observe().paused());
        assert_eq!(handle.observe().terminal_outcome, None);

        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_no_leg_threads();
    });
}

#[cfg(target_os = "linux")]
fn assert_no_leg_threads() {
    const LEAK_ORACLE_GRACE: Duration = Duration::from_secs(2);
    assert!(
        common::named_thread_gone_within("qianqian-decode", LEAK_ORACLE_GRACE),
        "decode worker thread leaked"
    );
    assert!(
        common::named_thread_gone_within("qianqian-test-render", LEAK_ORACLE_GRACE),
        "render thread leaked"
    );
}

#[cfg(not(target_os = "linux"))]
fn assert_no_leg_threads() {}
