//! Real Decode capability provider over the SongCore C ABI v1.
//!
//! Mechanism provider only: it owns the SongCore binding (ABI identity
//! check, host-IO callback machinery, handle RAII) and publishes the
//! `PcmDecode` capability through a kernel `ComponentSpec`. Per-episode
//! state — one opened media file, one `DecodedPcmStream` endpoint —
//! belongs to the caller (the Playback Session), never to this provider
//! (first-audible-slice design §2).

use std::fs::File;
use std::os::raw::c_void;
use std::path::Path;
use std::rc::Rc;
use std::slice;
use std::time::Duration;

use qianqian_audio_api::ports::{
    DecodeError, DecodeOpenError, DecodeOutcome, DecodedPcmStream, PcmDecode, PcmDecodeCapability,
    PcmFormat, ProviderSeekOutcome, SourceFacts,
};
use qianqian_composition::{ActivationError, ComponentSpec};
use qianqian_songcore_sys as sys;

/// Real decode mechanism over one SongCore native library instance.
/// Long-lived and stateless across opens.
///
/// Crate-private by design (plugin-boundary hardening H1): this is the
/// concrete mechanism, not product API. Composition roots admit this
/// plugin through [`songcore_decode_plugin`]; the capability consumer
/// sees only the `PcmDecode` service trait.
struct SongcoreDecode {
    _private: (),
}

impl SongcoreDecode {
    /// Bind the mechanism fail-closed: the loaded native library must
    /// report the ABI version this crate was generated against.
    fn new() -> Result<Self, DecodeOpenError> {
        let loaded = unsafe { sys::songcore_abi_version() };
        if loaded != sys::SONGCORE_ABI_VERSION {
            return Err(DecodeOpenError {
                message: format!(
                    "SongCore ABI mismatch: native library reports v{loaded}, \
                     bindings were generated for v{}",
                    sys::SONGCORE_ABI_VERSION
                ),
            });
        }
        Ok(Self { _private: () })
    }
}

impl PcmDecode for SongcoreDecode {
    fn open_media(&self, path: &Path) -> Result<Box<dyn DecodedPcmStream>, DecodeOpenError> {
        SongcoreDecodeStream::open(path)
    }
}

// --- host-IO callbacks over std::fs::File --------------------------------
//
// FFI boundary discipline: every callback fails closed (-1) on a null
// userdata pointer, a null destination (regardless of the requested
// length: `from_raw_parts_mut` requires a non-null data pointer even for
// a zero-length slice), and a negative absolute offset (the ABI defines
// offsets as non-negative). The pointer preconditions for
// `from_raw_parts_mut` are checked before the slice is formed; the
// SongCore side never legitimately passes these values, so a guard hit is
// a caller bug, not a decode result.

unsafe extern "C" fn file_read(ud: *mut c_void, dst: *mut u8, size: usize) -> i64 {
    if ud.is_null() || dst.is_null() {
        return -1;
    }
    use std::io::Read;
    let file = unsafe { &mut *(ud as *mut File) };
    let buf = unsafe { slice::from_raw_parts_mut(dst, size) };
    match file.read(buf) {
        Ok(n) => n as i64,
        Err(_) => -1,
    }
}

unsafe extern "C" fn file_seek(ud: *mut c_void, offset: i64) -> i64 {
    if ud.is_null() || offset < 0 {
        return -1;
    }
    use std::io::{Seek, SeekFrom};
    let file = unsafe { &mut *(ud as *mut File) };
    match file.seek(SeekFrom::Start(offset as u64)) {
        Ok(n) => n as i64,
        Err(_) => -1,
    }
}

unsafe extern "C" fn file_size(ud: *mut c_void) -> i64 {
    if ud.is_null() {
        return -1;
    }
    let file = unsafe { &mut *(ud as *mut File) };
    match file.metadata() {
        Ok(m) => m.len() as i64,
        Err(_) => -1,
    }
}

fn status_open_error(path: &Path, status: u32) -> DecodeOpenError {
    DecodeOpenError {
        message: format!(
            "cannot decode this file: {} (decoder status {status})",
            path.display()
        ),
    }
}

/// The container-declared duration as product evidence (ADR-PBK-002
/// D14.8). The ABI documents `duration_us == -1` as "the container
/// declares no duration"; every negative value is treated the same way,
/// fail-closed, so no sentinel can be mistaken for a real length.
///
/// A reported `0` is NOT folded into "unknown": it stays a legitimate
/// zero-length source, which the observation can therefore distinguish
/// from an absent duration. The value is relayed as mechanism evidence
/// and never corrected here — not at EOF, and not against the decoded
/// frame total (the probe measured a truncated stream still declaring
/// its full original length).
fn probe_duration(duration_us: i64) -> Option<Duration> {
    u64::try_from(duration_us).ok().map(Duration::from_micros)
}

/// One playback-specific decode endpoint: owns one native song handle and
/// the file it reads from. Released on drop (song_close), single-thread
/// serialized by contract (`DecodedPcmStream: Send` but not `Sync`).
/// Crate-private: consumers reach it only as the `DecodedPcmStream` trait
/// object returned by the capability service.
struct SongcoreDecodeStream {
    handle: *mut sys::song_handle,
    format: PcmFormat,
    /// Source duration evidence from the same `song_probe` snapshot that
    /// produced the format: the container's own declaration, `None` when
    /// it declared none (the ABI's `-1` sentinel). Truth class per
    /// ADR-PBK-002 D14.8: optional source-scoped Mechanism Evidence —
    /// never a Fact and not exact in general (a truncated stream still
    /// declares its original length).
    duration: Option<Duration>,
    /// Kept alive for the handle's lifetime; the callbacks borrow it raw.
    /// Declared after `handle` so drop runs song_close while the file is
    /// still alive. Never read: its whole job is being alive, then dropped.
    #[allow(dead_code)]
    file: Box<File>,
}

// The native handle is externally serialized (SongCore contract): moving
// the endpoint to another thread is safe; concurrent calls are not made.
unsafe impl Send for SongcoreDecodeStream {}

impl SongcoreDecodeStream {
    fn open(path: &Path) -> Result<Box<dyn DecodedPcmStream>, DecodeOpenError> {
        let file = File::open(path)
            .map_err(|e| DecodeOpenError {
                message: format!("cannot open this file: {}: {e}", path.display()),
            })?
            .into();
        let io = sys::song_io {
            userdata: Box::into_raw(file) as *mut c_void,
            read: Some(file_read),
            seek: Some(file_seek),
            size: Some(file_size),
        };
        let mut handle: *mut sys::song_handle = std::ptr::null_mut();
        let status = unsafe { sys::song_open(&io, &mut handle) };
        if status != sys::SONG_OK {
            unsafe { drop(Box::from_raw(io.userdata as *mut File)) };
            return Err(status_open_error(path, status));
        }
        // Fail closed: the ABI does not spell out "SONG_OK implies a
        // non-null handle", so the wrapper refuses to build on one. A null
        // here would make every later handle call undefined behavior.
        if handle.is_null() {
            unsafe { drop(Box::from_raw(io.userdata as *mut File)) };
            return Err(DecodeOpenError {
                message: format!(
                    "decoder error: opened {} successfully but it returned no handle",
                    path.display()
                ),
            });
        }
        let mut info: sys::song_info = unsafe { std::mem::zeroed() };
        let status = unsafe { sys::song_probe(handle, &mut info) };
        if status != sys::SONG_OK {
            unsafe {
                sys::song_close(handle);
                drop(Box::from_raw(io.userdata as *mut File));
            }
            return Err(DecodeOpenError {
                message: format!(
                    "cannot read this file's audio: {} (decoder status {status})",
                    path.display()
                ),
            });
        }
        Ok(Box::new(SongcoreDecodeStream {
            handle,
            format: PcmFormat {
                sample_rate: info.sample_rate as u32,
                channels: info.channels as u16,
                channel_mask: info.channel_mask,
            },
            duration: probe_duration(info.duration_us),
            file: unsafe { Box::from_raw(io.userdata as *mut File) },
        }))
    }

    fn last_error(&self) -> String {
        let mut err: *const sys::song_error = std::ptr::null();
        let status = unsafe { sys::song_last_error(self.handle, &mut err) };
        if status == sys::SONG_OK && !err.is_null() {
            let e = unsafe { &*err };
            if !e.message.is_null() && e.message_len > 0 {
                let bytes = unsafe {
                    slice::from_raw_parts(e.message as *const u8, e.message_len as usize)
                };
                return String::from_utf8_lossy(bytes).into_owned();
            }
        }
        "SongCore decode failed".to_owned()
    }
}

/// Raw `song_seek` status → the frozen semantic class (ADR-PBK-002
/// D14.5), payload-free so the mapping is pinnable without a live
/// handle. Exactly ONE status proves the pre-call decoding continuation
/// intact: `SONG_ERR_INVALID_ARGUMENT` is the ABI's pure parameter
/// check, which runs only on an OPEN handle (the not-probed guard
/// returns earlier) and mutates nothing before returning.
///
/// Everything else is destructive by the conservative rule — unprovable
/// means destructive:
///   - `SONG_ERR_NOT_OPEN` reports `!probed || !dec`: the handle is NOT
///     in an opened/probed state, so it certifies no usable old cursor.
///     A constructed endpoint is always probed, so this status is an
///     abnormal provider state, not an inert refusal — it must fail
///     closed (the F5 gate earned `INVALID_ARGUMENT` only, and never
///     measured a not-opened handle's continuation).
///   - generic `SEEK_ERROR` is returned both before `av_seek_frame` and
///     again after a successful reposition + decoder flush/reset, so
///     the status code alone proves nothing.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SeekClass {
    Applied,
    RefusedUnchanged,
    MutatedThenFailed,
}

fn classify_seek_status(status: u32) -> SeekClass {
    match status {
        sys::SONG_OK => SeekClass::Applied,
        sys::SONG_ERR_INVALID_ARGUMENT => SeekClass::RefusedUnchanged,
        _ => SeekClass::MutatedThenFailed,
    }
}

impl DecodedPcmStream for SongcoreDecodeStream {
    fn format(&self) -> PcmFormat {
        self.format
    }

    fn source_duration(&self) -> Option<Duration> {
        self.duration
    }

    fn read_frames(&mut self, dst: &mut [f32]) -> Result<DecodeOutcome, DecodeError> {
        let channels = self.format.channels as usize;
        if channels == 0 || dst.len() < channels {
            return Err(DecodeError {
                message: format!(
                    "decode destination holds {} samples, needs at least one frame ({channels})",
                    dst.len()
                ),
            });
        }
        let capacity = (dst.len() / channels) as u64;
        let mut produced: u64 = 0;
        let status =
            unsafe { sys::song_read_pcm(self.handle, dst.as_mut_ptr(), capacity, &mut produced) };
        match status {
            sys::SONG_OK => Ok(DecodeOutcome::Frames(produced as usize)),
            sys::SONG_EOF => Ok(DecodeOutcome::Eof),
            _ => Err(DecodeError {
                message: self.last_error(),
            }),
        }
    }

    fn seek(&mut self, target: Duration) -> ProviderSeekOutcome {
        // The ABI's native unit is microseconds; clamp the (unbounded)
        // Duration into it rather than inventing a wrap. Beyond-duration
        // and invalid targets stay the PROVIDER's decision (the ABI
        // clamps against known duration; negative is unrepresentable
        // here).
        let target_us = i64::try_from(target.as_micros()).unwrap_or(i64::MAX);
        let mut landing_us: i64 = -1;
        let status = unsafe { sys::song_seek(self.handle, target_us, &mut landing_us) };
        match classify_seek_status(status) {
            SeekClass::Applied => {
                // The ABI reports the retained-PCM start measured from
                // the first decoded frame's timestamp; -1 is the
                // explicit "landing unknown" sentinel (never
                // manufactured, never replaced by the requested target).
                // Convert to source PCM frames — the Position
                // projection's unit — rounding the µs quantization
                // (measured ±1 frame; mechanism noise, not a lie).
                let landing = u64::try_from(landing_us).ok().map(|us| {
                    let rate = u128::from(self.format.sample_rate);
                    ((u128::from(us) * rate + 500_000) / 1_000_000) as u64
                });
                ProviderSeekOutcome::Applied { landing }
            }
            SeekClass::RefusedUnchanged => ProviderSeekOutcome::RefusedUnchanged,
            SeekClass::MutatedThenFailed => ProviderSeekOutcome::MutatedThenFailed {
                diagnostic: self.last_error(),
            },
        }
    }
}

impl Drop for SongcoreDecodeStream {
    fn drop(&mut self) {
        // Defensive FFI-boundary hardening: every open path above either
        // leaves a non-null handle or refuses to construct the endpoint, so
        // the guard below can only fire on a construction invariant
        // violation — it exists to keep Drop itself sound, not to excuse
        // a null handle reaching the endpoint.
        if !self.handle.is_null() {
            unsafe { sys::song_close(self.handle) };
        }
    }
}

/// The F6 source preflight query (ADR-PBK-002 D14.6, the
/// F6-AUTHORITY-PROMOTION-1 amendment): ONE public, stateless mechanism
/// query — open the media, read the container's declared facts, close.
/// It reuses the production open/probe machinery internally (`song_open`
/// + `song_probe`) and reads NO PCM frames; it owns no render stream, no
/// edge, no worker, no device session — nothing RT-visible — so it is
/// not a second live playback episode and does not trigger P1–P5.
///
/// The result is mechanism evidence for an application composition
/// decision (an Open preflight: "this source opened and declared X at
/// probe time") — advisory, never episode truth; the episode
/// activation's own open/probe publishes the authoritative
/// `source_format` / `source_duration` evidence. Failure classes are
/// exactly [`DecodeOpenError`] today.
///
/// D13 record: a plain one-shot read operation owned by its caller —
/// no Capability, no Plugin, no composition identity. This is the
/// decode provider's ONLY public surface besides the plugin
/// constructor; the boundary gate rule was updated by the same
/// amendment on purpose.
pub fn probe_media(path: &Path) -> Result<SourceFacts, DecodeOpenError> {
    // Constructing the stream performs exactly song_open + song_probe
    // (the production open path); dropping it runs song_close. No
    // `read_frames` call exists on this path. The declared facts are
    // read through the endpoint trait — the same evidence the session
    // relays at activation.
    let stream = SongcoreDecodeStream::open(path)?;
    let facts = SourceFacts {
        format: stream.format(),
        duration: stream.source_duration(),
    };
    drop(stream);
    Ok(facts)
}

/// The Decode Plugin component definition: provides the `PcmDecode`
/// capability backed by the real SongCore mechanism.
pub fn songcore_decode_plugin() -> ComponentSpec {
    ComponentSpec::new("songcore_decode_plugin")
        .provides::<PcmDecodeCapability>()
        .on_activate(|ctx| {
            let service = SongcoreDecode::new().map_err(|e| ActivationError::new(e.message))?;
            ctx.provide::<PcmDecodeCapability>(Rc::new(service))
                .map_err(|e| ActivationError::new(format!("provision refused: {e:?}")))?;
            Ok(())
        })
}
#[cfg(test)]
mod tests {
    // Callback-guard regressions from NATIVE-BOUNDARY-AUDIT-0（round record：Git 历史 / PR #134）. These run
    // against the callback machinery only — no native library, no fixture.
    // They are the executable form of the guard contract: a host-IO
    // callback must fail closed (-1) without ever forming a Rust slice
    // from a pointer the slice rules forbid.
    use super::*;

    /// Holds a `Box<File>` leaked to a raw userdata pointer for the
    /// duration of one assertion, reclaiming it on drop.
    struct RawFile(*mut c_void);
    impl RawFile {
        fn from_temp() -> Self {
            let path = std::env::temp_dir().join("qianqian-callback-guard-test");
            let file: Box<File> = Box::new(File::create(path).unwrap());
            Self(Box::into_raw(file) as *mut c_void)
        }
        fn as_ud(&self) -> *mut c_void {
            self.0
        }
    }
    impl Drop for RawFile {
        fn drop(&mut self) {
            if !self.0.is_null() {
                drop(unsafe { Box::from_raw(self.0 as *mut File) });
            }
        }
    }

    /// S1 regression: a null destination is rejected even for a
    /// zero-length read. `from_raw_parts_mut` requires a non-null data
    /// pointer for every slice, length zero included — the guard must
    /// fire before the slice is formed, not rely on the native side
    /// never issuing this call. (Negative control: with the guard
    /// relaxed to `size > 0 &&`, Miri flags this call as UB at the
    /// `from_raw_parts_mut` site.)
    #[test]
    fn read_fails_closed_on_null_destination_even_for_zero_length() {
        let ud = RawFile::from_temp();
        let dst: *mut u8 = std::ptr::null_mut();
        unsafe {
            assert_eq!(file_read(ud.as_ud(), dst, 0), -1);
            assert_eq!(file_read(ud.as_ud(), dst, 16), -1);
        }
    }

    #[test]
    fn read_fails_closed_on_null_userdata() {
        let mut byte = 0u8;
        unsafe {
            assert_eq!(file_read(std::ptr::null_mut(), &mut byte, 1), -1);
            assert_eq!(file_seek(std::ptr::null_mut(), 0), -1);
            assert_eq!(file_size(std::ptr::null_mut()), -1);
        }
    }

    /// The ABI defines seek offsets as non-negative absolute positions.
    #[test]
    fn seek_fails_closed_on_negative_offset() {
        let ud = RawFile::from_temp();
        unsafe {
            assert_eq!(file_seek(ud.as_ud(), -1), -1);
        }
    }

    /// The raw-status → semantic-class map (ADR-PBK-002 D14.5) is the one
    /// place the F5 fail-closed rule can be lost silently: the session
    /// resumes its old cursor ONLY on `RefusedUnchanged`. Exactly one
    /// status earns that class — the ABI's pure parameter check, which
    /// runs on an OPEN handle and mutates nothing.
    ///
    /// `SONG_ERR_NOT_OPEN` in particular is NOT a refusal: it reports
    /// that the handle is not in an opened/probed state, hence certifies
    /// no usable old cursor. Promoting it would let a broken decode
    /// continuation look inert (F5-SEEK-IMPLEMENTATION-CORRECTIVE-2).
    #[test]
    fn only_invalid_argument_earns_a_pre_mutation_refusal() {
        assert_eq!(classify_seek_status(sys::SONG_OK), SeekClass::Applied);
        assert_eq!(
            classify_seek_status(sys::SONG_ERR_INVALID_ARGUMENT),
            SeekClass::RefusedUnchanged
        );

        // The whole declared ABI surface besides that one status — plus
        // EOF — is unprovable, therefore destructive.
        let destructive = [
            ("SONG_EOF", sys::SONG_EOF),
            ("SONG_ERR_NOT_OPEN", sys::SONG_ERR_NOT_OPEN),
            ("SONG_ERR_STATE", sys::SONG_ERR_STATE),
            ("SONG_ERR_IO", sys::SONG_ERR_IO),
            (
                "SONG_ERR_UNSUPPORTED_CONTAINER",
                sys::SONG_ERR_UNSUPPORTED_CONTAINER,
            ),
            ("SONG_ERR_NO_AUDIO_STREAM", sys::SONG_ERR_NO_AUDIO_STREAM),
            (
                "SONG_ERR_UNSUPPORTED_CODEC",
                sys::SONG_ERR_UNSUPPORTED_CODEC,
            ),
            ("SONG_ERR_CORRUPT_DATA", sys::SONG_ERR_CORRUPT_DATA),
            ("SONG_ERR_DECODE_ERROR", sys::SONG_ERR_DECODE_ERROR),
            ("SONG_ERR_SEEK_UNSUPPORTED", sys::SONG_ERR_SEEK_UNSUPPORTED),
            ("SONG_ERR_SEEK_ERROR", sys::SONG_ERR_SEEK_ERROR),
            ("SONG_ERR_STREAM_CHANGE", sys::SONG_ERR_STREAM_CHANGE),
            ("SONG_ERR_OUT_OF_MEMORY", sys::SONG_ERR_OUT_OF_MEMORY),
            ("SONG_ERR_INTERNAL_ERROR", sys::SONG_ERR_INTERNAL_ERROR),
        ];
        for (name, status) in destructive {
            assert_eq!(
                classify_seek_status(status),
                SeekClass::MutatedThenFailed,
                "{name} must never let the session resume old-cursor production"
            );
        }
    }
}

// White-box tests, moved inside the crate boundary by the plugin-boundary
// hardening (H1): they exercise the concrete mechanism and the real
// native corpus, so the mechanism stays crate-private and the tests
// reach it through the crate path. The shared fixture helper stays in
// tests/common/ (not auto-discovered) and is included once here.
#[cfg(test)]
mod decode_endpoint_tests;
#[cfg(test)]
mod plugin_tax_tests;
#[cfg(test)]
#[path = "../tests/common/mod.rs"]
mod test_common;
