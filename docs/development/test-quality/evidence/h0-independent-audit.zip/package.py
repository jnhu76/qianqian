import csv,html,json,pathlib,subprocess,hashlib,shutil,zipfile
root=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path('/home/hoo/Source/qianqian')
cards=json.loads((root/'property-cards.json').read_text())
invalid={x['run_id'] for x in json.loads((root/'invalid-attempts.json').read_text())}
runs=[]
for p in sorted((root/'runs').glob('*/metadata.json')):
 m=json.loads(p.read_text());label=m['run_id'];cls='RUN_PASS' if m['rc']==0 else 'RUN_FAILED'
 if label in invalid:cls='INVALID_SOURCE_IDENTITY_RACE'
 elif any(x in label for x in ['count-negative','finite-negative','post-commit-content-negative','existing-worker-oracle','hostile-pause-negative','straddle-negative-r2','full-exit-negative']):cls='SEMANTIC_MUTANT_CAUGHT'
 elif 'locked-destruction-negative' in label:cls='PROGRESS_MUTANT_CAUGHT'
 elif any(x in label for x in ['duplicate-seek-original','duplicate-seek-base-original','duplicate-pause-original','nan-original','nan-base-original','no-purge-whitebox','no-purge-real-content','no-purge-all-seek','late-quiescence-original','late-quiescence-head-original']):cls='ORIGINAL_ORACLE_MUTANT_SURVIVES'
 elif 'forced-premise-cleanup' in label:cls='REAL_RELEASE_JOIN_HELPER_PASS'
 elif 'real-session-root-unwind' in label:cls='REAL_FIXTURE_UNWIND_COUNTEREXAMPLE'
 if m['external_timeout']:cls='EXTERNAL_TIMEOUT_NOT_SEMANTIC_CREDIT'
 assert hashlib.sha256((p.parent/'stdout-stderr.log').read_bytes()).hexdigest()==m['log_sha256']
 assert hashlib.sha256((p.parent/'patch.diff').read_bytes()).hexdigest()==m['patch_sha256']
 runs.append(dict(RUN_ID=label,CLASSIFICATION=cls,SUBJECT=m['subject_sha'],TARGETS=json.dumps(m['test_targets_run']),COUNTS=json.dumps(m['test_results']),RC=m['rc'],SECONDS=round(m['seconds'],3),ARGV=json.dumps(m['argv']),CWD=m['cwd'],LOG_SHA256=m['log_sha256'],PATCH_SHA256=m['patch_sha256'],METADATA=str(p.relative_to(root)),RAW_LOG=str((p.parent/'stdout-stderr.log').relative_to(root)),PATCH=str((p.parent/'patch.diff').relative_to(root))))
def csvwrite(path,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csvwrite(root/'execution-index.csv',runs)
csvwrite(root/'mutation-matrix.csv',[r for r in runs if '-h0-' not in r['RUN_ID'] and 'discovery' not in r['RUN_ID'] and 'full-gate' not in r['RUN_ID']])
exits=[]
for c in cards:
 path=c['SOURCE_PATH'];name=c['TEST_ID'].split('::')[-1]
 if 'direct_pcm_flow' in path:owned='Rc flow/source/stage/sink arena; no worker';released='ordinary owned Rust resources';risk='no parked-thread cleanup claim';level='STATIC_OWNERSHIP'
 elif 'realtime_view_publication' in path:owned='control + acquire-probe threads; blocking destructor gate';released='guard only after entry success; normal explicit release + two joins';risk='entry-before-guard timeout, probe failure does not collect; release != join';level='RUN_I04_PLUS_STATIC_FAILURE_EXITS'
 elif path.endswith('render_gate.rs'):owned='one real pause leg per engagement';released='normal release then bounded join';risk='premise/semantic asserts before release skip cleanup; negative sampled before exit';level='RUN_I05_PLUS_STATIC_UNWIND'
 elif path.endswith('render_gate_seek.rs'):
  owned='real seek or pause+seek leg'
  released='selected wait failures -> real helper release + is_finished + join; normal paths mostly bounded join'
  risk='retained normal failed-tail handle not joined; mid-park semantic assertions bypass helper; bounded helper cannot kill genuinely hung leg'
  level='RUN_I08_HELPER_PLUS_STATIC_CALLER_EXITS'
 elif '/src/completion.rs' in path:
  owned='completion/edge/gate cells; no actual render/decode legs in H0 body'
  released='synchronous helper consumption; paused-cut uses outer within watchdog'
  risk='watchdog timeout detaches body; manual evidence cannot establish real worker/device release'
  level='STATIC_BODY_WITH_36_RUN_POSITIVES'
 else:
  owned='real app/K0 root, decode/render/observation worker relationships; possible held tail probe'
  released='normal explicit runtime.dispose; ordinary app Drop is not teardown'
  risk='pre-dispose semantic assertion panic can lose inverse-owned JoinHandles; held probe release must precede disposal'
  level='RUN_REAL_FIXTURE_UNWIND_PLUS_STATIC_BODY_EXITS'
 exits.append(dict(CARD_ID=c['CARD_ID'],TEST_ID=c['TEST_ID'],SOURCE_PATH=path,HEAD_FUNCTION_LINE=c['HEAD_LINE'],OWNED=owned,NORMAL_OR_SELECTED_FAILURE_CLEANUP=released,UNCLOSED_OR_UNPROVEN_EXITS=risk,EVIDENCE_CLASS=level))
csvwrite(root/'lifecycle-exits.csv',exits)
snapshot=root/'source-snapshots'
paths=set(c['SOURCE_PATH'] for c in cards)
paths.update(['crates/qianqian-playback/src/session.rs','crates/qianqian-playback/src/edge.rs','crates/qianqian-playback/src/handle.rs','crates/qianqian-playback/tests/common/mod.rs','crates/qianqian-audio-api/src/ports.rs','crates/qianqian-audio-api/tests/direct_pcm_flow/participants.rs','crates/qianqian-audio-api/tests/realtime_view_publication/publication.rs','crates/qianqian-audio-api/tests/realtime_view_publication/resources.rs','crates/qianqian-app/src/lib.rs','crates/qianqian-composition/src/kernel.rs','crates/qianqian-output-wasapi/src/wasapi.rs','crates/qianqian-output-wasapi/src/render_order_oracle.rs','crates/qianqian-decode-songcore/src/lib.rs','native/include/songcore.h','docs/adr/ADR-PBK-001.md','docs/adr/ADR-PBK-002.md','docs/adr/ADR-PBK-003.md','docs/development/concurrency-test-design.md','.github/workflows/windows-compile-gate.yml'])
for p in paths:
 t=snapshot/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(subprocess.check_output(['git','show','HEAD:'+p],cwd=repo))
data=json.dumps(cards,ensure_ascii=False).replace('</',r'<\/')
template=r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>H0 独立调用链审计</title>
<style>body{margin:0;font:15px system-ui;color:#182330;background:#f4f6fa}header{padding:24px 30px;background:#122438;color:white}h1{font-size:23px;margin:0 0 10px}main{display:grid;grid-template-columns:330px 1fr;gap:20px;padding:22px}aside,article{background:white;border-radius:12px;padding:18px}input{width:95%;padding:10px;margin:0 0 12px;border:1px solid #bbb;border-radius:6px}button{display:block;width:100%;text-align:left;border:0;background:#edf2f7;padding:10px;margin-bottom:7px;border-radius:7px;cursor:pointer;overflow-wrap:anywhere}button.active{background:#123e61;color:white}small{color:#66717e}h2{font-size:18px;overflow-wrap:anywhere}.steps{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:20px 0}.node{padding:12px;border:1px solid #74a7ba;border-radius:8px;background:#edf7fb;max-width:260px}.arrow{color:#6a7d8c}.row{border-top:1px solid #dde3eb;padding:12px 0}.label{font-weight:700;font-size:12px;letter-spacing:.4px;color:#415971;margin-bottom:6px}.row p{margin:0;line-height:1.65;overflow-wrap:anywhere}.note{background:#fff5e5;border-left:4px solid #c67d1e;padding:14px;line-height:1.6}a{color:#17618a}@media(max-width:800px){main{display:block}aside{margin-bottom:18px}}</style>
<header><h1>H0：从源码、所有者与观测边界重新推导</h1>18 个身份 · baseline/head 各 18 个非空单项执行 · HEAD b002a69<br><small style="color:#bdd1e2">这是局部证据浏览器。完整同步 / wait-for / cleanup DAG 见 execution-dags.md；调用链文字不是穷举证明。</small></header>
<main><aside><input id="search" placeholder="筛选名称、性质、调用链"><div id="nav"></div><a href="REPORT.md">完整报告</a> · <a href="execution-dags.md">执行 DAG</a> · <a href="mutation-matrix.csv">mutation matrix</a></aside><article id="detail"></article></main>
<script>const cards=__DATA__;let chosen=cards[0].CARD_ID;const keys=['AUTHORITY','PROPERTY','PRECONDITION','LEGAL_OUTCOMES','OBSERVATION','FALSIFIER','AUDIT_DISPOSITION','LIMITS'];const titles={AUTHORITY:'Authority',PROPERTY:'Property',PRECONDITION:'真实前提与同步点',LEGAL_OUTCOMES:'合法结果集合',OBSERVATION:'Oracle 读取边界',FALSIFIER:'具体反例',AUDIT_DISPOSITION:'独立审计判定',LIMITS:'范围 / 未覆盖出口'};
function render(){const q=document.querySelector('#search').value.toLowerCase();const nav=document.querySelector('#nav');nav.replaceChildren();cards.filter(c=>JSON.stringify(c).toLowerCase().includes(q)).forEach(c=>{const b=document.createElement('button');b.textContent=c.CARD_ID+' · '+c.TEST_ID.split('::').at(-1);b.className=c.CARD_ID===chosen?'active':'';b.onclick=()=>{chosen=c.CARD_ID;render()};nav.append(b)});const c=cards.find(c=>c.CARD_ID===chosen),d=document.querySelector('#detail');d.replaceChildren();const h=document.createElement('h2');h.textContent=c.CARD_ID+' · '+c.TEST_ID;d.append(h);const where=document.createElement('small');where.textContent=c.SOURCE_PATH+':'+c.HEAD_LINE;d.append(where);const chain=document.createElement('div');chain.className='steps';c.REAL_CALL_CHAIN.split(/\s*->\s*/).forEach((s,i)=>{if(i){const a=document.createElement('span');a.className='arrow';a.textContent='→';chain.append(a)}const n=document.createElement('div');n.className='node';n.textContent=s;chain.append(n)});d.append(chain);for(const k of keys){const row=document.createElement('div');row.className='row';const title=document.createElement('div');title.className='label';title.textContent=titles[k];const p=document.createElement('p');p.textContent=c[k];row.append(title,p);d.append(row)}const note=document.createElement('div');note.className='note';note.textContent='Baseline run: '+c.BASE_RUN_ID+'；HEAD run: '+c.HEAD_RUN_ID+'。平台：'+c.PLATFORM_RUNTIME;d.append(note)}document.querySelector('#search').oninput=render;render();</script></html>'''
(root/'explorer.html').write_text(template.replace('__DATA__',data))
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and 'target' not in p.relative_to(root).parts and p.name not in ['audit-bundle.zip','SHA256SUMS']}
(root/'SHA256SUMS').write_text(''.join(f'{h}  {p}\n' for p,h in sorted(manifest.items())))
with zipfile.ZipFile(root/'audit-bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(manifest):z.write(root/p,p)
 z.write(root/'SHA256SUMS','SHA256SUMS')
print(json.dumps({'cards':len(cards),'runs':len(runs),'invalid_source_race':len(invalid),'bundle_bytes':(root/'audit-bundle.zip').stat().st_size},ensure_ascii=False))
