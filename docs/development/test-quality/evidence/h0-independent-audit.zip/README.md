# 使用与复现

直接打开 `explorer.html` 浏览18条独立卡片；完整结论看 `REPORT.md`，执行展开看 `execution-dags.md`。HTML全离线、无CDN或外部依赖。ZIP与SHA256SUMS包含raw logs、metadata、patch、源码snapshot和复现脚本，不包含Cargo build cache。

本次实际67次run，其中2次SOURCE_IDENTITY_RACE无效；65次有效，未删除失败/无效日志。Linux当前HEAD完整gate PASS/862 tests；Windows/Miri/TLC/Loom/FFI/device本轮未执行，见报告。

所有隔离变更已恢复，两侧各203个Rust/Cargo文件byte-compare无差异；工作树已移除。canonical HEAD仍b002a69，源代码/PR未修改；原先的untracked target-r3excluded目录保留。

从仓库目录重新建立两个隔离worktree（若同名路径已被其他工作使用，应先调整脚本中的路径，不覆盖）：

```sh
git worktree add --detach /home/hoo/Source/qianqian-h0-independent-base daad414582b2a31eddc4a5b3fdb85bcce4bd60b0
git worktree add --detach /home/hoo/Source/qianqian-h0-independent-head b002a69370fb623b210c019da096a1fb4a6507e7
```

每个case独立先restore原文件再应用该case，source patch随run保存。**务必等run完成再改同一个worktree的case**，避免被本轮无效日志记录的身份race。并行只能用于不相互修改的不同worktree/读操作。

示例：重复release callback的独立Oracle：

```sh
python3 mutate.py head count-control
python3 run.py repeat-count-control /home/hoo/Source/qianqian-h0-independent-head cargo test -p qianqian-audio-api --test render_gate_seek independent_
python3 mutate.py head dup-seek-probe
python3 run.py repeat-count-negative /home/hoo/Source/qianqian-h0-independent-head cargo test -p qianqian-audio-api --test render_gate_seek independent_seek_exit_delivers_once -- --exact
python3 mutate.py head restore
```

其他case/argv在 `mutate.py`、`execution-index.csv` 和每次metadata中。`h0-run.py base/head`分别跑18个exact身份，`cards.py`在worktree存在且baseline/head运行完成后生成卡片。重复run必须使用新label以创建新RUN_ID，不能覆盖旧结果。

run.py自身退出0表示capture已完成，不代表target test通过；target rc、非空target/count与outcome必须看metadata/日志。外部240s timeout仅终止探针process group，不能当semantic RED。semantic negative的rc=101是预期，需要核对具体断言而不是只看退出码。

Windows connector/历史一轮证据不冒充本轮新执行。卡片body extractor是特定已检查函数的文本提取，不是Rust parser或自动branch-coverage工具。DAG是手动依据源码建立的一次operation展开，不声明全仓库自动静态分析或穷举验证。
