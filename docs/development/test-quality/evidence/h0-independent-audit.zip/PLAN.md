# 独立重建 H0 质量审计：本轮计划及事先预测

对象：base daad414582b2a31eddc4a5b3fdb85bcce4bd60b0；head b002a69370fb623b210c019da096a1fb4a6507e7。日期按客户端 2026-10-12 Asia/Shanghai，机器执行时间以各 run UTC 记录。

用户要求从头推导，故本轮从 authority + 生产源码 + 测试 body 重建：使用冻结 inventory 的 18 个身份，不继承 Flash 的分组、性质充分性、修复状态或 DAG。已阅读过上一轮结果，所以不冒充 fresh-context blind review。既有候选只能在独立卡片中重新论证后采用。

顺序：生产执行路径/资源所有者 -> 所需性质 -> 合法分支及同步边 -> 可观察边界 -> 实际测试路径 -> 负控制。每一条卡片需明确何处进入 mock、手动 evidence、合成机制。DAG 只解释执行，不新增运行时语义。审计不修改 canonical 源码，不提交或发布 PR 评论。

待执行预测（记录后再动 mutant）：

I01 DUPLICATE_RELEASE：real RenderGate seek_park 的出口重复执行一次 GateSlice::SeekRelease callback。payload 值与下次空槽不变。预测 gate_probe 的 last-wins Option 不能拒绝，render_gate_seek 全集可能仍 GREEN。独立 oracle 用 callback count，原实现 count=1，mutant count=2。对 pause_park 的 mid-park 路径另做同形验证，均是原协议的 exactly-once 实现回归，不创造新产品机制。

I02 NAN：test-only IdentityStage 在一个实际 payload sample 写入 NaN，source 的 deterministic expected 保持有限。预测 VerifyingSink 的 abs > epsilon 对 NaN 为 false，direct_pcm_flow 全集可能仍 GREEN。独立 oracle 验证有限预期值 vs 非有限输出，原实现 PASS，mutant 应 semantic RED。此项是数值 Oracle 缺陷，不把所有架构处理都限定为禁止 NaN。

I03 EDGE_PURGE：删除 real decode_worker Applied 分支的唯一 edge.invalidate。H0 completion 的手动 evidence 路径预测不能看到；真实 seek 内容集应拒绝旧 PCM。分别测白盒目标与真实 session/content 目标，若现有其他测试已抓住，归为局部覆盖范围，而非全仓库缺口。

I04 LOCKED_DESTRUCTION：test-only PublishedViews::release_reclaimable 在 publication lock 内 drop retired view。原 blocking destructor 测试应在 acquire progress bound 上 RED；这能证明它实际调用锁边界，但不证明 panic cleanup。baseline/head 比较，旧 baseline 外部 deadline 保底、head 保留失败日志。

I05 FRESH_TAIL：删除真实 pause park 的 current-engagement quiescence重置/改变归属，或在第三个 Pending engagement发布错误 TailQuiesced。各 engagement合法固定后，existing per-engagement oracle应RED。不用 sleep 证明第三次probe发生，新增独立计数/握手排除调度真空。

I06 COMMAND_ROUTING：在真实 SessionCompletion::request_pause 的 teardown 拒绝中删除 teardown guard；以白盒真实 release_pause_gate 后 hostile pause，再用 real gate验证没有 Engaged。原 integration sleep测试是否击中另行观察，不把睡眠当成 release witness。

I07 SLOT_AND_PAYLOAD：实际取走 release payload与 callback apply/worker清slot是不同节点。用持有回调的线程与 next-seek命令验证“slot约束到 take 或到 apply”的 authority边界；若 authority只约束消费，不提额外ack语义。如遇 OPEN，记录gap并停该项。

I08 FAILURE_CLEANUP：对所有 test-owned parked legs，独立枚举每个 await/assert前后的panic出口。对普通可释放场景注入各等待未达/语义Oracle失败；release全部条件后用真实 JoinHandle::is_finished和join收集（探针自己持有句柄，不以收到消息代替线程退出）。资源不能强行停止时明确限制。旧报告的 release-on-unwind候选重新按这一准则验证。

所有实际命令留 raw log + metadata + source manifest + patch hash。编译错误归 INVALID_RUN；未执行渠道写 NOT_RUN；green不等于 adequacy。所有 transient变更恢复并逐字节比较。
