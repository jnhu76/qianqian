import csv,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
which=sys.argv[1]
w='/home/hoo/Source/qianqian-h0-independent-'+which
inventory=root/'frozen-inventory.csv'
rows=[r for r in csv.DictReader(inventory.open()) if r['RISK']=='R-H' and r['RH_TAG']=='H0']
assert len(rows)==18
for i,r in enumerate(rows,1):
    name=r['TEST_ID'].split('::',1)[1]
    argv=['cargo','test','-p',r['CRATE']]
    if r['TARGET']=='qianqian_playback':argv+=['--lib']
    else:argv+=['--test',r['TARGET']]
    argv += [name,'--','--exact','--nocapture']
    subprocess.run(['python3',str(root/'run.py'),f'{which}-h0-{i:02}',w,*argv],check=True)
