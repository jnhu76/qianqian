# 18 条独立 property cards

源码与authority推导；不继承PR disposition。完整before/after body与hash在body-snapshots/。

## C01 — qianqian-audio-api::honest_path_observes_reused_storage_without_intermediates

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/direct_pcm_flow/main.rs

- **AUTHORITY**: PBK-001 §2.4; narrower fixture storage/content contract

- **PROPERTY**: 每个返回块使用 flow arena；有限 deterministic source 经 identity 保持数值及帧顺序

- **PRECONDITION**: 64帧/8帧一块，8次实际consume；first address应是arena，后续地址一致

- **LEGAL_OUTCOMES**: 8块；地址全等；预期样本逐项保持；合法reborrow不改变地址

- **OBSERVATION**: sink verify_in_order；结束后storage witness、source/sink cursor；实际payload未独立保留

- **REAL_CALL_CHAIN**: K0 setup -> test source -> PreboundPcmFlow::run_quantum -> IdentityStage -> VerifyingSink

- **FALSIFIER**: I02 NaN corruption；每块address替换；scratch-copy-back作为证据范围探针

- **AUDIT_DISPOSITION**: STORAGE_IMPROVED_VALUE_ORACLE_GAP

- **LIMITS**: sink abs comparison accepts NaN; final pointer cannot see intermediate copies

- **BASE_RUN_ID**: 20261012T153612-base-h0-01

- **HEAD_RUN_ID**: 20261012T154053-head-h0-01

## C02 — qianqian-audio-api::blocking_destruction_does_not_hold_the_publication_lock

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/realtime_view_publication/main.rs

- **AUTHORITY**: PBK-001 §6 P3-P5; test mechanism engineering invariant

- **PROPERTY**: 阻塞析构已进入时，publication acquire不能被析构持有的锁阻挡

- **PRECONDITION**: 无读者的retired view已certified；gate entry handshake必须先于probe

- **LEGAL_OUTCOMES**: destructor保持阻塞，probe acquire新view；释放后control/probe均退出并join

- **OBSERVATION**: entry condvar；acquire channel progress；join后的destroy log

- **REAL_CALL_CHAIN**: test PublishedViews::release_reclaimable -> drop view/resource -> DestructorGate; concurrent acquire

- **FALSIFIER**: I04在publication mutex内drop；另查guard构造前entry失败路径

- **AUDIT_DISPOSITION**: REAL_PROGRESS_ORACLE_CLEANUP_PARTIAL

- **LIMITS**: I04 caught; entry deadline occurs before guard creation; release does not collect failure-path threads

- **BASE_RUN_ID**: 20261012T153613-base-h0-02

- **HEAD_RUN_ID**: 20261012T154054-head-h0-02

## C03 — qianqian-audio-api::a_park_publishes_engagement_quiescence_and_disengagement_then_returns

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate.rs

- **AUTHORITY**: PBK-002 D14.7

- **PROPERTY**: pause park发布Engaged、合法TailQuiesced、Disengaged且release后不再次park

- **PRECONDITION**: pause在spawn之前；tail在第三次probe才回答Quiesced

- **LEGAL_OUTCOMES**: 有序完整cycle；每种event各一次；Pending不是quiescence

- **OBSERVATION**: events的真实observer publication；exit/join后settled counts

- **REAL_CALL_CHAIN**: real RenderGate::park_loop_top -> pause_park -> test TailProbe/event observer

- **FALSIFIER**: 错误event顺序、提前quiescence、post-release仍park；premise失败清理

- **AUDIT_DISPOSITION**: PARTIAL_ORDER_AND_UNWIND

- **LIMITS**: oracle uses counts rather than order; pre-release asserts can strand parked leg

- **BASE_RUN_ID**: 20261012T153613-base-h0-03

- **HEAD_RUN_ID**: 20261012T154054-head-h0-03

## C04 — qianqian-audio-api::tail_quiescence_belongs_to_each_engagement_separately

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate.rs

- **AUTHORITY**: PBK-002 D14.7 current-engagement attribution

- **PROPERTY**: 每个engagement独立取得quiescence；第三次一直Pending不能获得quiescence

- **PRECONDITION**: 每次pause在spawn前；前两个Quiesced，第三个Pending；真实probe是必要前提

- **LEGAL_OUTCOMES**: 前两次各有own TailQuiesced；第三次从进入直到退出都没有

- **OBSERVATION**: 当前只在第三次release之前读事件计数；join后未重查negative

- **REAL_CALL_CHAIN**: real pause_park -> fresh local quiesced_published -> observer -> release/exit

- **FALSIFIER**: I05 release时才伪造TailQuiesced；独立在真实probe后、join后断言完整事件集

- **AUDIT_DISPOSITION**: SEMANTIC_EXIT_WINDOW_GAP

- **LIMITS**: third negative sampled before release; I05 survives all render_gate tests

- **BASE_RUN_ID**: 20261012T153613-base-h0-04

- **HEAD_RUN_ID**: 20261012T154055-head-h0-04

## C05 — qianqian-audio-api::a_closed_gate_never_seek_parks_again

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate_seek.rs

- **AUTHORITY**: PBK-002 D14.5; gate closed-lifetime implementation invariant

- **PROPERTY**: close后hold无效；already parked leg由close释放并得到abort

- **PRECONDITION**: 第一case先close再hold；第二case由TailProbe entry证明真实seek park

- **LEGAL_OUTCOMES**: case1无事件/无payload；case2 seek engagement/disengagement和Aborted，无quiescence

- **OBSERVATION**: 无park case同步返回；park case在实际join后读取payload及events

- **REAL_CALL_CHAIN**: real close_and_release -> set_seek_hold; real seek_park -> close wake -> exit funnel

- **FALSIFIER**: close后重新park或不唤醒；closed-first和parked-close分别控制

- **AUDIT_DISPOSITION**: NARROW_MECHANISM_ORACLE

- **LIMITS**: bounded helper improves exit failure reporting; open_abort/backend not executed here

- **BASE_RUN_ID**: 20261012T153614-base-h0-05

- **HEAD_RUN_ID**: 20261012T154055-head-h0-05

## C06 — qianqian-audio-api::a_committed_release_reaches_the_parked_leg_exactly_once

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate_seek.rs

- **AUTHORITY**: PBK-002 D14.5 once-on-leg payload discipline

- **PROPERTY**: 一个Committed release产生恰好一个callback，后续gate call无payload

- **PRECONDITION**: seek hold在spawn前；真实TailProbe entry先于release

- **LEGAL_OUTCOMES**: callback一次且landing=44100；下一次0次；thread已join

- **OBSERVATION**: Option last-wins payload加下一次None，未计本次callback次数

- **REAL_CALL_CHAIN**: real seek_park -> SeekDisengaged -> take_release_internal -> callback

- **FALSIFIER**: I01重复同一次callback而payload仍take一次；用count捕捉

- **AUDIT_DISPOSITION**: EXACTLY_ONCE_ORACLE_GAP

- **LIMITS**: same payload twice is masked by Option overwrite; original 9/9 survive

- **BASE_RUN_ID**: 20261012T153614-base-h0-06

- **HEAD_RUN_ID**: 20261012T154055-head-h0-06

## C07 — qianqian-audio-api::a_committed_release_rebases_a_pause_parked_leg_while_still_parked

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate_seek.rs

- **AUTHORITY**: PBK-002 D14.5/D14.7

- **PROPERTY**: pause保持时Committed交付并rebase；不产生seek park或pause disengagement

- **PRECONDITION**: pause+seek hold先于spawn；真实TailQuiesced已published；release后callback已到

- **LEGAL_OUTCOMES**: 一次mid-park release，仍pause parked；resume后单个continuous pause cycle

- **OBSERVATION**: callback bool和Option；mid-park event snapshot；resume/join后的event set

- **REAL_CALL_CHAIN**: real pause_park -> take release -> GateSlice::SeekRelease -> continue paused

- **FALSIFIER**: I01重复mid-park交付；语义断言失败时仍应release并join

- **AUDIT_DISPOSITION**: EXACTLY_ONCE_AND_CLEANUP_GAP

- **LIMITS**: callback bool/last payload hide duplicate; mid-park asserts precede pause release

- **BASE_RUN_ID**: 20261012T153614-base-h0-07

- **HEAD_RUN_ID**: 20261012T154056-head-h0-07

## C08 — qianqian-audio-api::a_failed_tail_observation_exits_the_seek_park_reported_and_settled

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate_seek.rs

- **AUTHORITY**: PBK-002 D14.5 failed-tail observation implementation obligation

- **PROPERTY**: Failed不变成Quiesced/Pending；single exit funnel交付abort并报告failure

- **PRECONDITION**: seek hold已routed；实际TailProbe返回Failed，未显式release

- **LEGAL_OUTCOMES**: TailProbeFailed；Aborted恰好一次；SeekEngaged->SeekDisengaged，无quiescence

- **OBSERVATION**: channel result加captured Option/event log；收到消息不是thread exit

- **REAL_CALL_CHAIN**: real seek_park -> failed probe -> disengage -> abort callback -> outcome -> send -> epilogue

- **FALSIFIER**: I01重复failure出口交付；Failed->Pending；send之后panic或未完成

- **AUDIT_DISPOSITION**: PAYLOAD_CARDINALITY_AND_JOIN_GAP

- **LIMITS**: last-wins payload masks duplicate; success and semantic-panic paths do not join

- **BASE_RUN_ID**: 20261012T153615-base-h0-08

- **HEAD_RUN_ID**: 20261012T154056-head-h0-08

## C09 — qianqian-audio-api::a_new_hold_drops_a_stale_unconsumed_release

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate_seek.rs

- **AUTHORITY**: gate defensive-resource invariant; PBK-002 D14.5 production slot obligation separately

- **PROPERTY**: 新hold清掉旧未消费release，不能把旧Committed回答新park

- **PRECONDITION**: 测试主动制造旧payload未消费而新hold到来；这是机制防御case，非生产合法seek cycle

- **LEGAL_OUTCOMES**: cycle2等待自己的release并得到Aborted；旧landing9未交付

- **OBSERVATION**: real TailProbe entry、join后payload值；没有生产worker参与

- **REAL_CALL_CHAIN**: set_seek_hold -> release_seek_hold -> set_seek_hold -> real seek_park

- **FALSIFIER**: 去掉new-hold的payload reset；独立观察旧landing是否泄露

- **AUDIT_DISPOSITION**: DEFENSIVE_SCOPE_ONLY

- **LIMITS**: valid port-level defensive test; cannot establish production slot ownership/order

- **BASE_RUN_ID**: 20261012T153615-base-h0-09

- **HEAD_RUN_ID**: 20261012T154056-head-h0-09

## C10 — qianqian-audio-api::a_seek_park_publishes_only_seek_events_in_order

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate_seek.rs

- **AUTHORITY**: PBK-002 D14.5 attribution separation; current per-park probe discipline

- **PROPERTY**: seek park只发布SeekEngaged->SeekTailQuiesced->SeekDisengaged；第二probeQuiesced后不再probe

- **PRECONDITION**: hold先于spawn；实际probe entry和真实SeekTailQuiesced append先于release；25ms只是诊断窗口

- **LEGAL_OUTCOMES**: 正好两个tail observations；按序三个seek events；Aborted一次；没有pause事件

- **OBSERVATION**: actual mutex-backed event publication；release/join后exact event vector与counter

- **REAL_CALL_CHAIN**: real seek_park -> Pending probe1 -> Quiesced probe2 -> event -> release -> callback

- **FALSIFIER**: 错误pause attribution、重复probe、event乱序；I01可重复payload而vector/counter不变

- **AUDIT_DISPOSITION**: EVENT_ORDER_STRONG_PAYLOAD_COUNT_WEAK

- **LIMITS**: ordered vector witnesses attribution; last-wins captured Option misses duplicate release callback

- **BASE_RUN_ID**: 20261012T153615-base-h0-10

- **HEAD_RUN_ID**: 20261012T154056-head-h0-10

## C11 — qianqian-audio-api::the_seek_park_calls_the_tail_observation_only_while_parked

- **SOURCE_PATH**: crates/qianqian-audio-api/tests/render_gate_seek.rs

- **AUTHORITY**: PBK-002 D14.5 park evidence production boundary

- **PROPERTY**: TailProbe只发生在park，不在unheld或release后的新slice

- **PRECONDITION**: hold先routed；actual callback counter在parked flag之前更新

- **LEGAL_OUTCOMES**: 至少一次真实probe；in-flight slice允许完成；不发生新的post-release probe

- **OBSERVATION**: before sampled aftercallback-entry flag；after sampled atjoin；<=before+1留一个slice窗口

- **REAL_CALL_CHAIN**: real seek_park wait -> TailProbe -> release -> no further probe -> exit

- **FALSIFIER**: 在exit后追加probe；本test可允许一次，需其他event/count test交叉验证

- **AUDIT_DISPOSITION**: PARTIAL_SLICE_BOUND

- **LIMITS**: count permits one in-flight observation; no finite deadline is a synchronization edge

- **BASE_RUN_ID**: 20261012T153615-base-h0-11

- **HEAD_RUN_ID**: 20261012T154056-head-h0-11

## C12 — qianqian-playback::completion::tests::s0_a_paused_episodes_quiesced_park_commits_the_cut

- **SOURCE_PATH**: crates/qianqian-playback/src/completion.rs

- **AUTHORITY**: PBK-002 D14.5 pause-attributed commit; D14.7

- **PROPERTY**: pause-attributed parked+quiesced pair可使Applied cut commit，payload消费无debris

- **PRECONDITION**: 手动publish Engaged/TailQuiesced；手动landing；无真实worker/device

- **LEGAL_OUTCOMES**: decision Committed；resume后consume Committed7一次，下一次None

- **OBSERVATION**: white-box decision/consume_release Cell read；watchdog不参与正确性

- **REAL_CALL_CHAIN**: manual evidence -> real completion decision -> gate release -> helper real no-park consumption

- **FALSIFIER**: wrong attribution拒绝pause pair；删除fixture resume会hang；重复callback可被Cell覆盖

- **AUDIT_DISPOSITION**: WHITEBOX_ONLY_FAILURE_BOUND

- **LIMITS**: HEAD bounds reporting with within, but timeout neither cancels nor joins body

- **BASE_RUN_ID**: 20261012T153616-base-h0-12

- **HEAD_RUN_ID**: 20261012T154056-head-h0-12

## C13 — qianqian-playback::completion::tests::s0_operation_evidence_cannot_cross_cycles_and_cleared_parks_ground_nothing

- **SOURCE_PATH**: crates/qianqian-playback/src/completion.rs

- **AUTHORITY**: PBK-002 D14.5 per-cycle evidence and one-seek slot

- **PROPERTY**: 下一cycle重置landing/commit；已disengaged park不能满足新cycle

- **PRECONDITION**: cycle1完整commit且payload已取走再清slot；第二cycle先无park再建立自己的pair

- **LEGAL_OUTCOMES**: new landing=None、commit=false、park=false；只有第二cycleown evidence可commit

- **OBSERVATION**: manual state publications/read-outs plus actual gate payload; not real worker purge

- **REAL_CALL_CHAIN**: request_seek -> manual pair/landing -> decision -> gate consume -> manual disengage -> clear slot -> next cycle

- **FALSIFIER**: 删除evidence reset；I03删除worker purge不会影响此白盒调用链

- **AUDIT_DISPOSITION**: FIXTURE_REPAIRED_BOUNDED_SCOPE

- **LIMITS**: baseline frees slot while payload pending; head consumes first; real seek exit emits disengagement before take

- **BASE_RUN_ID**: 20261012T153624-base-h0-13

- **HEAD_RUN_ID**: 20261012T154057-head-h0-13

## C14 — qianqian-playback::completion::tests::seek_acceptance_fails_closed_on_every_frozen_condition

- **SOURCE_PATH**: crates/qianqian-playback/src/completion.rs

- **AUTHORITY**: PBK-002 D14.5 admission; current request_seek H1/Open/H2 refinement

- **PROPERTY**: 任一eligibility failure均不plant；两hold间新增failure必须在H2复核

- **PRECONDITION**: 顺序negatives各建独立completion；paused/Open/unsettled positive；并发window应单独构造

- **LEGAL_OUTCOMES**: none/terminal/stop/settled/teardown reject，paused允许；straddled teardown也reject

- **OBSERVATION**: seek slot和command read，顺序teardown仅到H1；不能代表H2

- **REAL_CALL_CHAIN**: real request_seek H1 -> sampled edge -> existing FencedRequest -> H2 -> slot/gate

- **FALSIFIER**: 独立single-H2 teardown删除，其他predicates保持false

- **AUDIT_DISPOSITION**: SECOND_HOLD_WINDOW_GAP

- **LIMITS**: HEAD adds sequential teardown case; separate H2 witness needed

- **BASE_RUN_ID**: 20261012T153624-base-h0-14

- **HEAD_RUN_ID**: 20261012T154057-head-h0-14

## C15 — qianqian-playback::pause_routed_after_teardown_release_cannot_wedge_the_join

- **SOURCE_PATH**: crates/qianqian-playback/tests/pause_seam.rs

- **AUTHORITY**: PBK-002 D14.7 teardown wake/routing; D6

- **PROPERTY**: 真实teardown release之后的hostile pause不能重新park并阻塞output join

- **PRECONDITION**: real activation -> real pause held TailProbe -> dispose release先于hostile pause；最后一条目前只sleep100ms

- **LEGAL_OUTCOMES**: hostile command不route；held probe释放后render/worker退出且dispose quiet

- **OBSERVATION**: dispose result/hostile join；无实际release witness；within不是该顺序证明

- **REAL_CALL_CHAIN**: QianqianApp dispose -> K0 LIFO inverses -> worker edge stop/join -> release_pause_gate -> stream.stop_and_join

- **FALSIFIER**: I06实际release后删除pause teardown guard；white-box局部test不可替代整个dispose DAG

- **AUDIT_DISPOSITION**: PUBLIC_SEAM_PREMISE_DEBT

- **LIMITS**: full integration release witness unavailable; no new production test API invented

- **BASE_RUN_ID**: 20261012T153624-base-h0-15

- **HEAD_RUN_ID**: 20261012T154057-head-h0-15

## C16 — qianqian-playback::stop_from_an_established_pause_settles_stopped_and_late_commands_stay_inert

- **SOURCE_PATH**: crates/qianqian-playback/tests/pause_seam.rs

- **AUTHORITY**: PBK-002 D11/D14.7

- **PROPERTY**: 未EOF且pause已established的episode stop为Stopped；late command不重标terminal

- **PRECONDITION**: 实际pause pair+quiescence；source不得在stop前EOF；HEAD Paced无限source固定此前提

- **LEGAL_OUTCOMES**: Stopped、pause history保持、paused false、late commands不改Fact、dispose quiet

- **OBSERVATION**: real Paused read-side证据 -> wait_terminal Fact -> dispose/join

- **REAL_CALL_CHAIN**: real Session + TestDecode + TestOutput; request_pause -> gate -> request_stop -> edge stop -> worker/drain publish -> resolve

- **FALSIFIER**: finite source可先EOF导致Completed；stop intent publication次序错误应被terminal oracle拒绝

- **AUDIT_DISPOSITION**: PREMISE_CORRECTION_ACCEPTED

- **LIMITS**: real-session on doubles; no acoustic/platform evidence

- **BASE_RUN_ID**: 20261012T153629-base-h0-16

- **HEAD_RUN_ID**: 20261012T154058-head-h0-16

## C17 — qianqian-playback::a_paused_episode_can_seek_again_after_its_committed_cut

- **SOURCE_PATH**: crates/qianqian-playback/tests/seek_seam.rs

- **AUTHORITY**: PBK-002 D14.5/D14.7/D14.8

- **PROPERTY**: pause中两次cut均commit，第二landing可见；resume后没有pre-cut ring内容

- **PRECONDITION**: 第一rebase已见不等于slot-free；200ms settle；第二cut在同pause中

- **LEGAL_OUTCOMES**: 两次actual landing、pause连续；first post-resume sample属于最后landing及之后

- **OBSERVATION**: Position及event derived read；complete content只查jump个数/landing，没关联commit后的消费边界

- **REAL_CALL_CHAIN**: real worker Applied -> purge -> commit/release -> paused mock leg rebase -> next seek -> resume/content

- **FALSIFIER**: I03漏purge；新first-post-commit-content oracle以保持pause固定消费边界

- **AUDIT_DISPOSITION**: SLOT_PREMISE_AND_COMMIT_CONTENT_GAP

- **LIMITS**: sleep slot debt persists; whole seek suite survives no-purge but existing separate worker oracle catches

- **BASE_RUN_ID**: 20261012T153629-base-h0-17

- **HEAD_RUN_ID**: 20261012T154058-head-h0-17

## C18 — qianqian-playback::an_unknown_landing_withdraws_the_position_for_the_rest_of_the_episode

- **SOURCE_PATH**: crates/qianqian-playback/tests/seek_seam.rs

- **AUTHORITY**: PBK-002 D14.5/D14.8

- **PROPERTY**: unknown landing使Position永久withdraw；后续known landing不能恢复，内容仍依actual provider前进

- **PRECONDITION**: 初始sample真实存在；first unknown cut消费payload；第二request须slotfree（当前sleep200ms）

- **LEGAL_OUTCOMES**: None到EOF；两个actual jumps；commit后不消费旧ring

- **OBSERVATION**: Position None、terminal、whole content jumps；缺两个commit的消费边界marker

- **REAL_CALL_CHAIN**: real worker+scripted provider -> mock gate rebase(None) -> subsequent known rebase -> consumption

- **FALSIFIER**: restore publishing onknown；I03旧ring迟消费可保持整体两个jumps而过关

- **AUDIT_DISPOSITION**: SLOT_PREMISE_AND_COMMIT_CONTENT_GAP

- **LIMITS**: unknown permanence oracle valid; no slotfree acknowledgement; stale-PCM boundary not independently tagged

- **BASE_RUN_ID**: 20261012T153631-base-h0-18

- **HEAD_RUN_ID**: 20261012T154059-head-h0-18
