# 从源码展开的执行图

Source subject: b002a69。这些是一次操作的有限执行展开，不是全仓库无环性声明。静态调用图含循环、trait dispatch和callback；DAG的边必须注明实际program order、lock、channel、publication或join来源，未画出的边不得靠时间假设补齐。

## Seek：四个参与者与三个不同的边界

```mermaid
flowchart LR
  subgraph Command[Command issuer]
    H1[completion request_seek H1] --> OPEN[edge Open sample] --> H2[H2 + slot plant + gate hold]
  end
  subgraph Worker[real decode worker]
    PICK[take command; continue producing] --> PARKCHECK[read current parked evidence]
    PARKCHECK --> PROVIDER[provider.seek]
    PROVIDER -->|Applied| DISCARD[discard old staging/remainder]
    DISCARD --> HISTORY[reset processing history] --> PURGE[edge.invalidate] --> LAND[publish landing]
    PROVIDER -->|RefusedUnchanged| REFUSE[release old-world leg; finish exact remainder]
    PROVIDER -->|MutatedThenFailed| FAIL[D11 failure; no old-cursor production]
    LAND --> COMMIT[decision under completion lock]
    COMMIT --> ROUTE[route committed release]
    TAKEOBS[observe no pending payload] --> FREE[clear seek slot] --> NEW[write new PCM]
  end
  subgraph Leg[render leg]
    GATE[real loop-top gate] --> ENGAGE[park; publish engagement]
    ENGAGE --> TAIL[device-tail observation]
    TAIL -->|Quiesced| EVIDENCE[publish current TailQuiesced]
    TAKE[take release payload] --> APPLY[callback applies rebase]
    APPLY --> NEXT[future read/submission]
  end
  H2 --> GATE
  H2 --> PICK
  ENGAGE --> PARKCHECK
  EVIDENCE --> COMMIT
  ROUTE --> TAKE
  TAKE --> TAKEOBS
  NEW --> NEXT
  subgraph Oracle[Test observations]
    FINAL[whole consumed sequence: jump count + landing]
    MARK[paused commit marker + fixed consumed prefix]
    FIRST[first sample after resume = actual landing]
  end
  NEXT --> FINAL
  APPLY --> MARK --> FIRST
  NEXT --> FIRST
```

源码定位：completion.rs `request_seek:681`、`seek_cutover_decision:888`；session.rs provider/Applied `:644-768`；ports.rs `pause_park:598` / `seek_park:671`；test mock `common/mod.rs::consume_loop`；real backend `wasapi.rs::steady_loop`。

边界必须分开：internal record != actual acceptance；commit/release != leg consumption；payload take != callback apply completion。当前slot只等pending清除，普通单leg执行序列已经保证旧callback先于该leg未来submission，不应凭图方便新增apply-ack。正常seek出口的SeekDisengaged在take前；pause-held cut在mid-park取走payload，没有seek disengagement。图没有给两者强行统一。

删除PURGE时，FINAL仍可能看到一个最终jump而通过。FIRST把旧ring在commit之后交付的样本分出来，已实际拒绝23296而要求220500。另一个已有real-worker oracle用预置旧ring并检查Applied后无旧pull，也能拒绝漏purge，见mutation matrix；因此这是integration oracle差距，不是全仓库无防守。

## Release：事件正确不等于交付次数正确

```mermaid
flowchart LR
  HOLD[route hold] --> PARK[real TailProbe entry]
  PARK --> SEND[route Committed landing 37]
  SEND --> TAKE[take one pending payload]
  TAKE --> CB1[callback 1]
  CB1 -. duplicate dispatch mutant .-> CB2[callback 2, same value]
  CB1 --> LAST[overwrite captured Option]
  CB2 --> LAST
  LAST --> OLD[old oracle sees correct last value]
  CB1 --> COUNT[count callback deliveries]
  CB2 --> COUNT
  COUNT --> JOIN[release blocking conditions; actual join]
  JOIN --> NEW[assert count equals 1]
```

seek exit、pause mid-park、failed-tail funnel均可被last-wins遮蔽。新的count探针分别在seek和pause路径取得真实park handshake，resume/release后实际join，再断言次数。相同payload重复两次已经被执行发现，不是仅靠函数名字推测。

## Tail evidence：negative必须覆盖到settlement

```mermaid
flowchart LR
  ARM[pause before spawn] --> ENTER[actual Pending TailProbe entry]
  ENTER --> SNAP[old negative snapshot]
  SNAP --> REL[release pause]
  REL -. fabricated late TailQuiesced .-> BAD[illegal evidence]
  REL --> EXIT[disengage + thread exit]
  BAD --> EXIT
  EXIT --> JOIN[actual JoinHandle join]
  JOIN --> ASSERT[new complete event vector rejects BAD]
```

原test的第三engagement在release之前看negative，join后不再看，late-tail mutant在baseline/head的7个render_gate测试中均存活。新oracle以实际callback到达作前提、以join作negative的结算边界。

## Teardown：LIFO inverse与unwind出口

```mermaid
flowchart LR
  DISPOSE[explicit QianqianApp.dispose] --> K0[K0 run_unwind LIFO]
  K0 --> DS[decode relation: edge.stop] --> DJ[decode worker join]
  DJ --> GR[output relation: release_pause_gate] --> SS[stream.stop] --> RJ[render join] --> DROP[provider/resource release]
  PANIC[test assertion panic before explicit dispose] --> ROOTDROP[root ordinary drop]
  ROOTDROP --> DETACH[inverse closure values dropped; JoinHandles detached]
```

app/lib.rs文档显式要求dispose，production Drop不是shutdown。测试必须对自己拥有的root做失败清理；不能从Rust scope unwind推导dispose已发生。本轮Linux探针证明真实decode/render在fixture panic之后仍alive，外部Stop后才能观察OS退出。不能用这个结论要求生产新增Drop shutdown。

单独gate test同理：所有早退出口必须先释放pause/seek/latched callback/析构条件，再join。验证helper正确只检查它被调用的边，不能覆盖绕过helper的assert出口。

## Memory/content：真实生产与合成flow不是同一条线

```text
production: SongcoreDecodeStream -> song_read_pcm/seek (ABI)
    -> session staging + real processing -> bounded PcmEdge ring
    -> WASAPI GetBuffer/read_frames/ReleaseBuffer -> device tail

H0 direct flow: test StreamingSource -> test IdentityStage -> test VerifyingSink
    (setup用了真实K0；PCM阶段是test-only演示机制)

H0 realtime publication: test PublishedViews -> test RealtimeView/TrackedResource
    (不是生产Playback Session的运行机制)
```

两类合成机制仍能提供明确的局部证据，但其通过不能替代真实staging、PCM ring、FFI、WASAPI的验证。NaN探针通过实际stage->sink路径暴露数值Oracle的非全域性；不把地址provenance升级为无copy或架构全正确证明。
