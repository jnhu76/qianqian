import pathlib,subprocess,sys
which,case=sys.argv[1:]
w=pathlib.Path('/home/hoo/Source/qianqian-h0-independent-'+which)
paths=['crates/qianqian-audio-api/src/ports.rs','crates/qianqian-audio-api/tests/direct_pcm_flow/participants.rs','crates/qianqian-audio-api/tests/direct_pcm_flow/main.rs','crates/qianqian-audio-api/tests/render_gate_seek.rs','crates/qianqian-audio-api/tests/render_gate.rs','crates/qianqian-audio-api/tests/realtime_view_publication/publication.rs','crates/qianqian-playback/src/session.rs','crates/qianqian-playback/src/completion.rs','crates/qianqian-playback/tests/seek_seam.rs','crates/qianqian-playback/tests/pause_seam.rs']
for p in paths:(w/p).write_bytes(subprocess.check_output(['git','show','HEAD:'+p],cwd=w))
def replace(p,old,new):
 f=w/p;s=f.read_text();assert s.count(old)==1,(p,s.count(old),old[:70]);f.write_text(s.replace(old,new))
def add(p,new):
 with (w/p).open('a') as f:f.write(new)
if case in ['dup-seek','dup-pause','dup-seek-probe','dup-pause-probe','count-control']:
 p=paths[0];s=(w/p).read_text()
 if case.startswith('dup-seek'):
  a=s.index('    fn seek_park(');b=s.index('    /// Consume a pending release',a);part=s[a:b]
  old='        slice(GateSlice::SeekRelease(release));\n        if probe_failed {'
  assert old in part;part=part.replace(old,'        slice(GateSlice::SeekRelease(release));\n        slice(GateSlice::SeekRelease(release)); // INDEPENDENT MUTANT: duplicate dispatch\n        if probe_failed {',1)
  (w/p).write_text(s[:a]+part+s[b:])
 if case.startswith('dup-pause'):
  replace(p,'                slice(GateSlice::SeekRelease(release));\n            }\n            if released {','                slice(GateSlice::SeekRelease(release));\n                slice(GateSlice::SeekRelease(release)); // INDEPENDENT MUTANT: duplicate mid-park dispatch\n            }\n            if released {')
 if case.endswith('probe') or case=='count-control':
  add(paths[3],'''
// Independent implementation-regression oracle: callback delivery count,
// not final captured payload. No new production synchronization hook.
struct IndependentLeg {
    gate: RenderGate,
    join: Option<std::thread::JoinHandle<()>>,
}
impl IndependentLeg {
    fn collect(&mut self) {
        self.gate.close_and_release();
        if let Some(j) = self.join.take() {
            assert!(wait_until(Duration::from_secs(5), || j.is_finished()), "independent released leg failed to exit");
            j.join().expect("independent witness leg panic must be observed");
        }
    }
}
impl Drop for IndependentLeg {
    fn drop(&mut self) {
        self.gate.close_and_release();
        if let Some(j) = self.join.take() {
            if wait_until(Duration::from_secs(5), || j.is_finished()) { let _ = j.join(); }
        }
    }
}
fn independent_check_once(paused: bool) {
    let gate = RenderGate::new();
    gate.set_paused(paused);
    gate.set_seek_hold(true);
    let count = Arc::new(AtomicUsize::new(0));
    let (parked_tx, parked_rx) = std::sync::mpsc::channel();
    let (applied_tx, applied_rx) = std::sync::mpsc::channel();
    let g = gate.clone();
    let c = count.clone();
    let j = std::thread::spawn(move || {
        g.park_loop_top(|slice| match slice {
            GateSlice::TailProbe => { let _ = parked_tx.send(()); TailProbeOutcome::Quiesced }
            GateSlice::SeekRelease(r) => {
                assert_eq!(r, SeekParkRelease::Committed { landing: Some(37) });
                c.fetch_add(1, Ordering::SeqCst);
                let _ = applied_tx.send(());
                TailProbeOutcome::Pending
            }
        });
    });
    let mut owned = IndependentLeg { gate: gate.clone(), join: Some(j) };
    parked_rx.recv_timeout(Duration::from_secs(5)).expect("real callback proves park entered");
    gate.release_seek_hold(SeekParkRelease::Committed { landing: Some(37) });
    applied_rx.recv_timeout(Duration::from_secs(5)).expect("real callback received routed commit");
    gate.set_paused(false);
    owned.collect();
    assert_eq!(count.load(Ordering::SeqCst), 1, "INDEPENDENT_ORACLE: one routed release must produce exactly one callback");
}
#[test] fn independent_seek_exit_delivers_once() { independent_check_once(false); }
#[test] fn independent_pause_midpark_delivers_once() { independent_check_once(true); }
''')
elif case in ['nan','nan-probe','nan-control']:
 if case!='nan-control':replace(paths[1],"fn process<'block>(&mut self, block: PcmViewMut<'block>) -> PcmView<'block> {\n        block.freeze()\n    }","fn process<'block>(&mut self, mut block: PcmViewMut<'block>) -> PcmView<'block> {\n        if let Some(sample) = block.sample_mut(0, 0) { *sample = f32::NAN; }\n        block.freeze()\n    }")
 if case!='nan':
  add(paths[2],'''
#[test]
fn independent_identity_stage_preserves_a_finite_source_sample() {
    use crate::participants::PcmStage;
    let format = PcmFormat::new(48_000, 2).unwrap();
    let mut storage = [0.25, 0.75];
    let block = crate::harness::PcmViewMut::new(format, &mut storage).unwrap();
    let result = IdentityStage.process(block);
    assert_eq!(result.sample(0, 0), Some(0.25), "INDEPENDENT_ORACLE: identity stage must preserve finite source content");
}
''')
elif case in ['no-purge','no-purge-probe','purge-control']:
 if case!='purge-control':replace(paths[6],'                                edge.invalidate();','                                // INDEPENDENT MUTANT: omitted actual ring purge')
 if case!='no-purge':
  add(paths[8],'''
#[test]
fn independent_first_post_commit_read_starts_at_actual_landing() {
    let _lifecycle = common::lifecycle_lock();
    within(Duration::from_secs(30), || {
        let (w, h, mut runtime) = episode(vec![ProviderSeekOutcome::Applied { landing: Some(FIVE_SECONDS) }]);
        wait_for_position_past(&h, HALF_A_SECOND);
        h.request_pause();
        let paused = wait_until(Duration::from_secs(5), || h.observe().paused());
        if !paused { h.request_stop(); runtime.dispose(); panic!("independent pause premise failed"); }
        // Real pause engagement + current tail quiescence proves mock leg
        // holds no read/device-buffer and cannot append consumed content.
        let before_cut = content(&w).len();
        h.request_seek(Duration::from_secs(5));
        let rebased = wait_until(Duration::from_secs(5), || h.observe().position == Some(FIVE_SECONDS));
        if !rebased { h.request_stop(); runtime.dispose(); panic!("independent committed rebase premise failed"); }
        let remained_parked = h.observe().paused();
        let no_midpark_append = content(&w).len() == before_cut;
        h.request_resume();
        let terminal = h.wait_terminal();
        let quiet = runtime.dispose().snapshot.quiet;
        let values = content(&w);
        assert!(remained_parked && no_midpark_append);
        assert_eq!(terminal, EpisodeTerminalOutcome::Completed);
        assert!(quiet);
        assert_eq!(values.get(before_cut).copied(), Some(FIVE_SECONDS as f32), "INDEPENDENT_ORACLE: the first submission after a committed paused cut must not replay old ring PCM");
    });
}
''')
elif case=='locked-drop':
 p=paths[5];s=(w/p).read_text();start=s.index('    pub fn release_reclaimable(');end=s.index('\n}\n',start);s=s[:start]+'''    pub fn release_reclaimable(&self, identity: u64) -> bool {
        let mut inner = self.inner.lock().expect("publication lock");
        let Some(position) = inner.reclaimable.iter().position(|v| v.identity() == identity) else { return false; };
        let released = inner.reclaimable.remove(position);
        drop(released); // INDEPENDENT MUTANT: destructor inside lock
        drop(inner);
        true
    }
'''+s[end:];(w/p).write_text(s)
elif case in ['late-tail','late-tail-probe','tail-control']:
 p=paths[0]
 if case!='tail-control':
  s=(w/p).read_text();a=s.index('    fn pause_park(');b=s.index('    fn seek_park(',a);part=s[a:b]
  old='            if released {\n                break;\n            }'
  assert part.count(old)==1
  part=part.replace(old,'            if released {\n                if !quiesced_published { self.emit(GateEvent::TailQuiesced); } // INDEPENDENT MUTANT: invent evidence at release\n                break;\n            }')
  (w/p).write_text(s[:a]+part+s[b:])
 if case!='late-tail':
  add(paths[4],'''
#[test]
fn independent_pending_tail_never_publishes_quiescence_through_exit() {
    let events = Events::default();
    let writer = events.clone();
    let gate = RenderGate::with_observer(move |e| writer.record(e));
    gate.set_paused(true);
    let (entered_tx, entered_rx) = std::sync::mpsc::channel();
    let leg_gate = gate.clone();
    let j = std::thread::spawn(move || {
        pause_only(&leg_gate, || { let _ = entered_tx.send(()); false });
    });
    let entered = entered_rx.recv_timeout(Duration::from_secs(5)).is_ok();
    gate.set_paused(false);
    let finished = wait_until(Duration::from_secs(5), || j.is_finished());
    assert!(finished, "independent release failed to exit");
    j.join().unwrap();
    assert!(entered, "real TailProbe entry required");
    assert_eq!(events.snapshot(), vec![GateEvent::Engaged, GateEvent::Disengaged], "INDEPENDENT_ORACLE: Pending probes never authorize quiescence, including after release");
}
''')
elif case=='root-unwind':
 add(paths[9],'''
#[cfg(target_os = "linux")]
#[test]
fn independent_root_unwind_leaves_real_episode_threads_until_explicit_stop() {
    let _lifecycle = common::lifecycle_lock();
    let h = PlaybackSessionHandle::new();
    let body = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let mut runtime = registered_runtime(endless_audio(1), OutputBehavior::Consume,
            Arc::new(AtomicUsize::new(0)), DeviceTail::default(), TailProbe::default(), h.clone());
        activate(&mut runtime);
        h.request_pause();
        wait_established(&h);
        panic!("INDEPENDENT_HYGIENE: fail at a semantic assertion before explicit dispose");
    }));
    let decode_alive_after_unwind = common::named_thread_alive("qianqian-decode");
    let render_alive_after_unwind = common::named_thread_alive("qianqian-test-render");
    // Audit-only explicit stop prevents persistent orphaned workers.
    h.request_stop();
    let settled = wait_until(Duration::from_secs(5), || h.observe().terminal_outcome.is_some());
    let decode_gone = common::named_thread_gone_within("qianqian-decode", Duration::from_secs(5));
    let render_gone = common::named_thread_gone_within("qianqian-test-render", Duration::from_secs(5));
    assert!(body.is_err());
    assert!(settled && decode_gone && render_gone, "audit cleanup must observe actual OS-thread exit");
    assert!(decode_alive_after_unwind && render_alive_after_unwind, "counterexample requires both real threads surviving root unwind");
    eprintln!("INDEPENDENT_CONFIRMED: real decode/render threads survived fixture panic and root drop; explicit external stop was required. OS exit observed; lost handles cannot be joined retroactively.");
}
''')
elif case in ['second-hold-control','second-hold-mutant']:
 p=paths[7];f=w/p;s=f.read_text()
 if case=='second-hold-mutant':
  a=s.index('// The atomic internal-record unit');s=s[:a]+s[a:].replace('                || guard.teardown_released\n','',1)
 pos=s.rfind('\n}');s=s[:pos]+'''
    #[test]
    #[cfg(not(loom))]
    fn independent_teardown_straddles_seek_admission_holds() {
        let c = SessionCompletion::new();
        let edge = Arc::new(PcmEdge::new(2, 8));
        c.bind_stop_target(edge.clone());
        let mut r = test_sync::FencedRequest::spawn(&c, Duration::from_secs(1));
        r.wait_parked();
        c.release_pause_gate();
        let s = test_sync::second_hold_state(&c);
        assert!(s.teardown_released);
        assert!(!s.outcome_set && !s.stop_requested && !s.activation_failure_set && !s.worker_gone && !s.slot_in_flight);
        assert_eq!(edge.terminal(), EdgeTerminal::Open);
        r.release(); r.join();
        assert!(!c.seek_in_flight(), "INDEPENDENT_ORACLE: H2 must reject a teardown straddling H1 and H2");
        assert_eq!(c.take_seek_command(), None);
    }
'''+s[pos:];f.write_text(s)
elif case=='helper-proof':
 add(paths[3],'''
fn independent_exercise_premise_failure(paused: bool) {
    let gate = RenderGate::new();
    gate.set_paused(paused);
    gate.set_seek_hold(true);
    let (tx, rx) = std::sync::mpsc::channel();
    let leg_gate = gate.clone();
    let captured = Arc::new(Mutex::new(None));
    let writer = captured.clone();
    let j = std::thread::spawn(move || {
        leg_gate.park_loop_top(|s| match s {
            GateSlice::TailProbe => { let _ = tx.send(()); TailProbeOutcome::Quiesced }
            GateSlice::SeekRelease(r) => { *writer.lock().unwrap() = Some(r); TailProbeOutcome::Pending }
        });
    });
    let entered = rx.recv_timeout(Duration::from_secs(5)).is_ok();
    if !entered { gate.close_and_release(); j.join().unwrap(); panic!("independent park premise failed"); }
    let panic = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        if paused { fail_premise_releasing_pause_leg(&gate, j, "INDEPENDENT_HYGIENE_PREMISE") }
        else { fail_premise_releasing_leg(&gate, j, "INDEPENDENT_HYGIENE_PREMISE") }
    })).expect_err("original helper must preserve its premise panic");
    let message = panic.downcast_ref::<String>().unwrap();
    assert!(message.contains("INDEPENDENT_HYGIENE_PREMISE"));
    assert!(message.contains("exited_within_5s=true, joined=true"), "actual helper must release and join: {message}");
    assert_eq!(*captured.lock().unwrap(), Some(SeekParkRelease::Aborted));
}
#[test] fn independent_seek_premise_failure_releases_and_joins() { independent_exercise_premise_failure(false); }
#[test] fn independent_pause_premise_failure_releases_and_joins() { independent_exercise_premise_failure(true); }
''')
elif case in ['pause-control','pause-mutant']:
 p=paths[7]
 if case=='pause-mutant':replace(p,'if guard.stop_requested || guard.teardown_released || guard.outcome.is_some() {','if guard.stop_requested || guard.outcome.is_some() {')
 f=w/p;s=f.read_text();pos=s.rfind('\n}');s=s[:pos]+'''
    #[test]
    #[cfg(not(loom))]
    fn independent_hostile_pause_after_real_teardown_release_routes_no_park() {
        let completion = SessionCompletion::new();
        completion.bind_stop_target(Arc::new(PcmEdge::new(2, 8)));
        completion.release_pause_gate();
        completion.request_pause();
        let gate = completion.render_gate();
        let calls = Arc::new(std::sync::atomic::AtomicUsize::new(0));
        let writer = calls.clone();
        let j = std::thread::spawn(move || {
            gate.park_loop_top(|slice| { match slice {
                GateSlice::TailProbe => { writer.fetch_add(1, std::sync::atomic::Ordering::SeqCst); TailProbeOutcome::Failed }
                GateSlice::SeekRelease(_) => TailProbeOutcome::Pending,
            }});
        });
        let deadline = std::time::Instant::now() + Duration::from_secs(5);
        while !j.is_finished() && std::time::Instant::now() < deadline { std::thread::yield_now(); }
        let exited = j.is_finished();
        completion.render_gate().close_and_release();
        assert!(exited, "independent gate probe never exited");
        j.join().unwrap();
        assert_eq!(calls.load(std::sync::atomic::Ordering::SeqCst), 0, "INDEPENDENT_ORACLE: teardown-released episode reparked after hostile pause");
    }
'''+s[pos:];f.write_text(s)
elif case!='restore':raise ValueError(case)
print(which,case)
