# 从头重建：H0 独立性质、调用链与反例审计

对象：[PR #261](https://github.com/jnhu76/qianqian/pull/261)，冻结基线 `daad414582b2a31eddc4a5b3fdb85bcce4bd60b0`，当前 HEAD `b002a69370fb623b210c019da096a1fb4a6507e7`。本轮重新从源码和 authority 推导，使用 #258 清单仅获取身份/位置，不读取其 adequacy 或 PR ledger 状态来决定性质。已看过上一轮发现，所以不宣称 fresh-context blind review；本轮补出全新的独立推导与执行，不只是重新评判 Flash 的报告。

**结论：原实现通过已运行的独立正控制，但现有若干 Oracle 对真实实现错误存在盲区。** 有价值的窄修复应保留，不能把 18/18 绿灯或既有 mutation matrix 当作完整调用链已被覆盖。以下 mutant 是隔离故障注入，不代表当前 HEAD 正在发生这些错误。

## 已交付的独立工件

- `property-cards.md/json`：18 条独立 PROPERTY / PRECONDITION / LEGAL_OUTCOMES / OBSERVATION / REAL_CALL_CHAIN / FALSIFIER / disposition 卡片。
- `independent-before-after-ledger.csv`：每条 baseline/head 的源码位置、函数体 hash、实际单测试 RUN_ID；`body-snapshots/` 保留两侧 body。
- `execution-dags.md`：真实调用路径与按一次操作展开的DAG，注明三条执行路径及不同结算边界。
- `explorer.html`：离线可筛选的 18 条卡片与调用链视图，无外部依赖。
- `mutation-matrix.csv`、`execution-index.csv`：所有 run 的命令、subject、完整日志、patch/hash、结果类和无效尝试。
- `PLAN.md`：本轮最初预测；`plan-addendum.md` 是事后整理的adaptive推导，明确不冒充执行前冻结证据。
- `restore-proof.json`、`SHA256SUMS`、`audit-bundle.zip`：源码恢复与工件完整性。

冻结 inventory 918 行 SHA256 `975de34ad6d296deb8945cd8d1045fc01af8b405c5a7dda3f5494fe5702be7cd`，选出 18 个 H0。**baseline/head各18条逐项执行，共36个非空正控制，每次确实1 passed。** 所有卡片有各自独立结果；没有用一个大suite的绿色推定未执行项。

## 新推导出的语义盲区

### 1. P1：release callback 的重复交付被最后值掩盖

源码：`ports.rs:633`（pause mid-park）、`:732`（seek/failure出口）；Oracle：`tests/render_gate_seek.rs::gate_probe:52`，每次callback都覆盖 `Option`；相关 H0 是“exactly once”、pause中rebase、failed-tail出口等。

实际fault：pending payload仍只被take一次，随后相同 `GateSlice::SeekRelease` callback调用两次。它不改变最终payload、GateEvent序列、next gate的None或tail counter，因此原test都看不到第二次交付。

结果：seek双交付在baseline/head的原 `render_gate_seek` **9/9 GREEN**；pause中双交付在HEAD的 `render_gate` + `render_gate_seek` **16/16 GREEN**。独立count oracle先由真实TailProbe证明park，然后route单个Committed，解除park并**实际join**，在结束后检查callback计数：原实现 **2/2 PASS**；两个mutant各 **semantic RED**，`actual 2 != expected 1`。

这是新发现的既存语义Oracle债务；PR修了部分cleanup，却没有发现这个计数盲区。最小改进是对本次交付计数/append，而非只保存最后值；不能用“下一次没payload”替代“本次只交付一次”。

### 2. P1：Pending engagement在退出时伪造quiescence，原negative仍GREEN

源码：`ports.rs::pause_park` 的release出口；Oracle：`render_gate.rs::tail_quiescence_belongs_to_each_engagement_separately` 的第三cycle在release前snapshot，在join后没有重验negative。

实际fault：某次park一直Pending，从未Quiesced；观察release时却补发一个 `TailQuiesced`，再正常Disengaged。原test的negative已经在错误发生之前结束。

结果：baseline/head各自原 `render_gate` **7/7 GREEN**。独立oracle以callback channel证明真实Pending发生，release后先actual join，再检查完整event vector。原实现 **1/1 PASS**；mutant **semantic RED**：`[Engaged,TailQuiesced,Disengaged] != [Engaged,Disengaged]`。

这是一个具体的遗漏出口，不是单纯“sleep可能不可靠”的泛泛意见。negative范围必须覆盖合法release/exit之后，不能只覆盖park中的一次读。

### 3. P1（测试Oracle）：NaN绕过PCM内容校验

源码：test-only `direct_pcm_flow/participants.rs::VerifyingSink::verify_in_order:220` 使用 `(actual - expected).abs() > 1e-6`。预期来自有限deterministic source，IdentityStage应保持该值。NaN比较使这个拒绝条件为false。

实际fault：IdentityStage原arena中的真实sample被改成NaN，地址和帧数全部保持。原sink报告成功。

结果：baseline原direct-flow **19/19 GREEN**，HEAD **20/20 GREEN**；新增partial-copy kill test也通过。独立有限输入保持Oracle的正控制PASS，mutant在 `Some(NaN) != Some(0.25)` 上semantic RED。

这不是要求所有生产DSP禁止NaN的新产品规则；它是现有有限reference内容Oracle错误地接受不匹配值。应让比较具有完整拒绝行为，显式处理非有限actual/expected，保留合理数值容差。

### 4. P1范围差距：seek集成测试没有关联commit与之后的消费内容

真实调用链：provider Applied -> staging discard/history reset -> **PcmEdge.invalidate** -> landing -> commit -> leg rebase -> post-cut read。原集成Oracle在全部结束后数jump并验证landing，旧buffer迟到也可以保留这个整体形状。

实际fault：删掉 `session.rs:690` 的唯一worker-side edge purge。completion H0 的白盒reset test仍GREEN，全部 `seek_seam` **18/18 GREEN**。这说明它们的完整内容序列不能证明commit后的stale exclusion。

独立探针经过真实assembly/session/decode worker/gate/edge（provider与device仍是doubles）：先establish pause，固定已消费prefix长度；等待actual landing在保持pause时rebase；resume后，在完整退出/dispose之后检查第一个新交付sample必须是actual landing。正控制PASS；no-purge **semantic RED**：第一次post-commit输出 `23296`，应为 `220500`。

**重要限定：仓库已有防守。** `session::seek_record_tests::stopped_record_has_no_seek_effects_while_open_record_executes_cut` 直接运行真实worker，并用预置ring检验Applied后不再pull旧内容；同一no-purge mutant在它上面RED，`unexpected post-cut data: Frames(1)`。所以不能说“整个仓库没有测purge”。应记录：integration oracle的宣称范围过强，需要把该近机制证据明确映射进覆盖表，或补一个实际commit后的内容边界Oracle。

initial预测以为已有普通real-content集成target会拒绝no-purge，实际没有；完整原日志保留，没有替换成后来更强probe的结果。

## 生命周期重新推导后的结论

### Helper本身有真实的正证据，但不能代表所有出口

本轮直接在已由真实TailProbe证明park的leg上触发原helper的premise panic。seek-only、pause+seek两种情况均实际release并join，panic保留原premise，签名 `exited_within_5s=true, joined=true`，payload为Aborted，**2/2 PASS**。这是对当前helper的局部肯定，不能传播为全部test body已panic-safe。

源码枚举仍确认：full park/per-engagement在release前的assert可跳过清理；mid-park rebase的两个语义assert不经过helper；failed-tail正常返回与消息之后的语义assert不join；destructor entry失败发生在guard构造前。详见 `lifecycle-exits.csv`。上一轮实际fault日志另存其报告，本轮这些出口的列注明STATIC或本轮RUN，不把上一轮日志改标成本轮执行。

### 新的真实fixture异常退出证据：Drop(root)不等于dispose

`QianqianApp`明确选择explicit dispose（`crates/qianqian-app/src/lib.rs:10-14`），ordinary Drop不执行shutdown。真实session的effect closures持有JoinHandle；scope unwind若未dispose，丢弃closure会detach句柄，而不是release/join。

本轮Linux探针按真实pause integration的assembly路径建立episode并establish pause，在显式dispose之前模拟语义assert panic。catch之后独立从 `/proc` 观察：真实 `qianqian-decode` 和 `qianqian-test-render` **都仍alive**。外部保留handle显式Stop后，两个OS thread才退出；原句柄已经丢失，不能补作join。

这证明测试自己拥有的真实fixture在某些panic出口也缺少清理。它不授权修改生产Drop语义；应在测试作用域保持能够显式dispose的所有者/guard，释放held tail probe和pause等条件后统一结束执行。OS退出诊断与actual join证据明确区分。

## 有效防守、保留债务与无缺陷结论

- blocking destructor Oracle确实调用其机制的publication mutex边界：故意在锁内析构的I04被原HEAD test拒绝，10s后在 `acquire must progress...Timeout` RED。属于明确进展故障的bounded detection，不是所有cleanup已正确的证明。
- hostile pause在真实 `release_pause_gate` 后的白盒gate探针：原实现PASS，删除teardown路由guard后callback计数从0变1，semantic RED。它验证真实局部路由；原完整dispose integration的100ms排序前提仍没有同等级witness。
- admission H1/Open/H2窗口重新执行：existing per-instance FencedRequest把真实request停在H2前，实际release_pause_gate之后只有teardown predicate为true；原实现PASS，删除H2 conjunct后slot被错误plant，semantic RED。无新生产API或架构概念。
- slot等payload take的现状没有被认定为defect。单render leg的program order保证旧callback apply在该leg未来submission之前；不能单凭图画方便要求新增apply-ack/slot生命周期。
- endless source修正stop-from-pause的EOF前提有效；P1-05先消费旧payload再清slot的fixture修正有效；all-block storage witness能证明所有返回storage地址，不能证明没有scratch复制。
- 两个200ms slot-free settle点与完整teardown integration的100ms release点保留为premise debt。未绕过OQ-1/OQ-6新建生产ack/API，未以retry或更长sleep声称修复。

## 执行与平台范围

本轮自己执行：36个单项baseline/head H0；独立语义/cleanup矩阵；当前exact HEAD的 `lefthook run pre-push --all-files` **PASS**，workspace **862/0**，fmt/clippy、commit convention、vocabulary、plugin boundary、website verify/build通过。完整run index列出每次具体target数量，不将compile failure计为semantic RED。

有2个初次admission probe的隔离源码在上一编译session结束前被切换。虽然输出为PASS/RED，两次均保留并排除，标作 `INVALID_SOURCE_IDENTITY_RACE`；之后串行r2重新取得正控制PASS和语义RED。原日志/metadata不重写。cards.py一次漏填卡片导致生成器KeyError，随后补齐；不是测试run，不计mutation结果。

本轮本地 **NOT_RUN**：Windows runtime（仅安装交叉target不能当runtime）、Loom/Miri/TLC重新执行、FFI/excluded crates、真实WASAPI/device。环境检查：当前stable installed components无Miri，`specs/tools`无TLC jar，QIANQIAN_NATIVE_DIR未配置，未提供音频endpoint。本轮不为这些未执行通道计PASS，也不以安装target推定跨平台支持。

前一轮已fetch的PR CI属于同一HEAD关联的synthetic merge `f8deef5`；不是本轮新执行。Windows job runtime只运行playback/headless，audio-api的11个H0仍仅compile coverage。Miri/Loom/TLC其他机制的通过不能外推到本轮新增callback cardinality、exit-negative和fixture unwind。

## 与Flash产物的对照

本轮没有推测Flash模型内部思考方式。最终可观察差别是：Flash的property sketches主要覆盖预期成功链和某些命名failure branches；本轮从每个资源的产生者、可阻塞条件、状态writer、Oracle读取时刻反向展开，找到了**同一次调用中的重复、退出后的迟到证据、浮点非全域输入、commit后仍连续的旧PCM、fixture unwind后的真实线程**。

因此“用DAG找调用链”的做法应是：调用图定位真实路径，按一次operation展开DAG；分别画program order、mutex handoff、publication/channel、wait-for及cleanup/join边；最后给每条性质一个能击中错误的独立Oracle。仅有箭头、最终值或大suite绿灯不会证明这条路径真实被覆盖。

建议以这些独立cards/矩阵重建coverage账本，优先修callback count、join后negative、NaN拒绝和test-owned异常disposal，再针对没有合法witness的项目保留debt/owner decision。新发现应登记为scope明确的测试债务；不要为了数量整齐改写冻结918行清单或引入新产品状态。
