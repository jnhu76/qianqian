import csv,hashlib,json,pathlib,re,subprocess
root=pathlib.Path(__file__).resolve().parent
inv=root/'frozen-inventory.csv'
raw=inv.read_bytes();assert hashlib.sha256(raw).hexdigest()=='975de34ad6d296deb8945cd8d1045fc01af8b405c5a7dda3f5494fe5702be7cd'
(root/'frozen-inventory.csv').write_bytes(raw)
rows=[r for r in csv.DictReader(raw.decode().splitlines()) if r['RISK']=='R-H' and r['RH_TAG']=='H0'];assert len(rows)==18
# Independently stated properties, premises, legal outputs, observation owners,
# nearest real path, candidate falsifier and adequacy boundaries. Not read from PR ledger.
D={
'a_seek_park_publishes_only_seek_events_in_order':(
'PBK-002 D14.5 attribution separation; current per-park probe discipline',
'seek park只发布SeekEngaged->SeekTailQuiesced->SeekDisengaged；第二probeQuiesced后不再probe',
'hold先于spawn；实际probe entry和真实SeekTailQuiesced append先于release；25ms只是诊断窗口',
'正好两个tail observations；按序三个seek events；Aborted一次；没有pause事件',
'actual mutex-backed event publication；release/join后exact event vector与counter',
'real seek_park -> Pending probe1 -> Quiesced probe2 -> event -> release -> callback',
'错误pause attribution、重复probe、event乱序；I01可重复payload而vector/counter不变',
'EVENT_ORDER_STRONG_PAYLOAD_COUNT_WEAK','ordered vector witnesses attribution; last-wins captured Option misses duplicate release callback'),
'honest_path_observes_reused_storage_without_intermediates':(
'PBK-001 §2.4; narrower fixture storage/content contract',
'每个返回块使用 flow arena；有限 deterministic source 经 identity 保持数值及帧顺序',
'64帧/8帧一块，8次实际consume；first address应是arena，后续地址一致',
'8块；地址全等；预期样本逐项保持；合法reborrow不改变地址',
'sink verify_in_order；结束后storage witness、source/sink cursor；实际payload未独立保留',
'K0 setup -> test source -> PreboundPcmFlow::run_quantum -> IdentityStage -> VerifyingSink',
'I02 NaN corruption；每块address替换；scratch-copy-back作为证据范围探针',
'STORAGE_IMPROVED_VALUE_ORACLE_GAP','sink abs comparison accepts NaN; final pointer cannot see intermediate copies'),
'blocking_destruction_does_not_hold_the_publication_lock':(
'PBK-001 §6 P3-P5; test mechanism engineering invariant',
'阻塞析构已进入时，publication acquire不能被析构持有的锁阻挡',
'无读者的retired view已certified；gate entry handshake必须先于probe',
'destructor保持阻塞，probe acquire新view；释放后control/probe均退出并join',
'entry condvar；acquire channel progress；join后的destroy log',
'test PublishedViews::release_reclaimable -> drop view/resource -> DestructorGate; concurrent acquire',
'I04在publication mutex内drop；另查guard构造前entry失败路径',
'REAL_PROGRESS_ORACLE_CLEANUP_PARTIAL','I04 caught; entry deadline occurs before guard creation; release does not collect failure-path threads'),
'a_park_publishes_engagement_quiescence_and_disengagement_then_returns':(
'PBK-002 D14.7',
'pause park发布Engaged、合法TailQuiesced、Disengaged且release后不再次park',
'pause在spawn之前；tail在第三次probe才回答Quiesced',
'有序完整cycle；每种event各一次；Pending不是quiescence',
'events的真实observer publication；exit/join后settled counts',
'real RenderGate::park_loop_top -> pause_park -> test TailProbe/event observer',
'错误event顺序、提前quiescence、post-release仍park；premise失败清理',
'PARTIAL_ORDER_AND_UNWIND','oracle uses counts rather than order; pre-release asserts can strand parked leg'),
'tail_quiescence_belongs_to_each_engagement_separately':(
'PBK-002 D14.7 current-engagement attribution',
'每个engagement独立取得quiescence；第三次一直Pending不能获得quiescence',
'每次pause在spawn前；前两个Quiesced，第三个Pending；真实probe是必要前提',
'前两次各有own TailQuiesced；第三次从进入直到退出都没有',
'当前只在第三次release之前读事件计数；join后未重查negative',
'real pause_park -> fresh local quiesced_published -> observer -> release/exit',
'I05 release时才伪造TailQuiesced；独立在真实probe后、join后断言完整事件集',
'SEMANTIC_EXIT_WINDOW_GAP','third negative sampled before release; I05 survives all render_gate tests'),
'a_closed_gate_never_seek_parks_again':(
'PBK-002 D14.5; gate closed-lifetime implementation invariant',
'close后hold无效；already parked leg由close释放并得到abort',
'第一case先close再hold；第二case由TailProbe entry证明真实seek park',
'case1无事件/无payload；case2 seek engagement/disengagement和Aborted，无quiescence',
'无park case同步返回；park case在实际join后读取payload及events',
'real close_and_release -> set_seek_hold; real seek_park -> close wake -> exit funnel',
'close后重新park或不唤醒；closed-first和parked-close分别控制',
'NARROW_MECHANISM_ORACLE','bounded helper improves exit failure reporting; open_abort/backend not executed here'),
'a_committed_release_reaches_the_parked_leg_exactly_once':(
'PBK-002 D14.5 once-on-leg payload discipline',
'一个Committed release产生恰好一个callback，后续gate call无payload',
'seek hold在spawn前；真实TailProbe entry先于release',
'callback一次且landing=44100；下一次0次；thread已join',
'Option last-wins payload加下一次None，未计本次callback次数',
'real seek_park -> SeekDisengaged -> take_release_internal -> callback',
'I01重复同一次callback而payload仍take一次；用count捕捉',
'EXACTLY_ONCE_ORACLE_GAP','same payload twice is masked by Option overwrite; original 9/9 survive'),
'a_committed_release_rebases_a_pause_parked_leg_while_still_parked':(
'PBK-002 D14.5/D14.7',
'pause保持时Committed交付并rebase；不产生seek park或pause disengagement',
'pause+seek hold先于spawn；真实TailQuiesced已published；release后callback已到',
'一次mid-park release，仍pause parked；resume后单个continuous pause cycle',
'callback bool和Option；mid-park event snapshot；resume/join后的event set',
'real pause_park -> take release -> GateSlice::SeekRelease -> continue paused',
'I01重复mid-park交付；语义断言失败时仍应release并join',
'EXACTLY_ONCE_AND_CLEANUP_GAP','callback bool/last payload hide duplicate; mid-park asserts precede pause release'),
'a_failed_tail_observation_exits_the_seek_park_reported_and_settled':(
'PBK-002 D14.5 failed-tail observation implementation obligation',
'Failed不变成Quiesced/Pending；single exit funnel交付abort并报告failure',
'seek hold已routed；实际TailProbe返回Failed，未显式release',
'TailProbeFailed；Aborted恰好一次；SeekEngaged->SeekDisengaged，无quiescence',
'channel result加captured Option/event log；收到消息不是thread exit',
'real seek_park -> failed probe -> disengage -> abort callback -> outcome -> send -> epilogue',
'I01重复failure出口交付；Failed->Pending；send之后panic或未完成',
'PAYLOAD_CARDINALITY_AND_JOIN_GAP','last-wins payload masks duplicate; success and semantic-panic paths do not join'),
'a_new_hold_drops_a_stale_unconsumed_release':(
'gate defensive-resource invariant; PBK-002 D14.5 production slot obligation separately',
'新hold清掉旧未消费release，不能把旧Committed回答新park',
'测试主动制造旧payload未消费而新hold到来；这是机制防御case，非生产合法seek cycle',
'cycle2等待自己的release并得到Aborted；旧landing9未交付',
'real TailProbe entry、join后payload值；没有生产worker参与',
'set_seek_hold -> release_seek_hold -> set_seek_hold -> real seek_park',
'去掉new-hold的payload reset；独立观察旧landing是否泄露',
'DEFENSIVE_SCOPE_ONLY','valid port-level defensive test; cannot establish production slot ownership/order'),
'the_seek_park_calls_the_tail_observation_only_while_parked':(
'PBK-002 D14.5 park evidence production boundary',
'TailProbe只发生在park，不在unheld或release后的新slice',
'hold先routed；actual callback counter在parked flag之前更新',
'至少一次真实probe；in-flight slice允许完成；不发生新的post-release probe',
'before sampled aftercallback-entry flag；after sampled atjoin；<=before+1留一个slice窗口',
'real seek_park wait -> TailProbe -> release -> no further probe -> exit',
'在exit后追加probe；本test可允许一次，需其他event/count test交叉验证',
'PARTIAL_SLICE_BOUND','count permits one in-flight observation; no finite deadline is a synchronization edge'),
's0_a_paused_episodes_quiesced_park_commits_the_cut':(
'PBK-002 D14.5 pause-attributed commit; D14.7',
'pause-attributed parked+quiesced pair可使Applied cut commit，payload消费无debris',
'手动publish Engaged/TailQuiesced；手动landing；无真实worker/device',
'decision Committed；resume后consume Committed7一次，下一次None',
'white-box decision/consume_release Cell read；watchdog不参与正确性',
'manual evidence -> real completion decision -> gate release -> helper real no-park consumption',
'wrong attribution拒绝pause pair；删除fixture resume会hang；重复callback可被Cell覆盖',
'WHITEBOX_ONLY_FAILURE_BOUND','HEAD bounds reporting with within, but timeout neither cancels nor joins body'),
's0_operation_evidence_cannot_cross_cycles_and_cleared_parks_ground_nothing':(
'PBK-002 D14.5 per-cycle evidence and one-seek slot',
'下一cycle重置landing/commit；已disengaged park不能满足新cycle',
'cycle1完整commit且payload已取走再清slot；第二cycle先无park再建立自己的pair',
'new landing=None、commit=false、park=false；只有第二cycleown evidence可commit',
'manual state publications/read-outs plus actual gate payload; not real worker purge',
'request_seek -> manual pair/landing -> decision -> gate consume -> manual disengage -> clear slot -> next cycle',
'删除evidence reset；I03删除worker purge不会影响此白盒调用链',
'FIXTURE_REPAIRED_BOUNDED_SCOPE','baseline frees slot while payload pending; head consumes first; real seek exit emits disengagement before take'),
'seek_acceptance_fails_closed_on_every_frozen_condition':(
'PBK-002 D14.5 admission; current request_seek H1/Open/H2 refinement',
'任一eligibility failure均不plant；两hold间新增failure必须在H2复核',
'顺序negatives各建独立completion；paused/Open/unsettled positive；并发window应单独构造',
'none/terminal/stop/settled/teardown reject，paused允许；straddled teardown也reject',
'seek slot和command read，顺序teardown仅到H1；不能代表H2',
'real request_seek H1 -> sampled edge -> existing FencedRequest -> H2 -> slot/gate',
'独立single-H2 teardown删除，其他predicates保持false',
'SECOND_HOLD_WINDOW_GAP','HEAD adds sequential teardown case; separate H2 witness needed'),
'pause_routed_after_teardown_release_cannot_wedge_the_join':(
'PBK-002 D14.7 teardown wake/routing; D6',
'真实teardown release之后的hostile pause不能重新park并阻塞output join',
'real activation -> real pause held TailProbe -> dispose release先于hostile pause；最后一条目前只sleep100ms',
'hostile command不route；held probe释放后render/worker退出且dispose quiet',
'dispose result/hostile join；无实际release witness；within不是该顺序证明',
'QianqianApp dispose -> K0 LIFO inverses -> worker edge stop/join -> release_pause_gate -> stream.stop_and_join',
'I06实际release后删除pause teardown guard；white-box局部test不可替代整个dispose DAG',
'PUBLIC_SEAM_PREMISE_DEBT','full integration release witness unavailable; no new production test API invented'),
'stop_from_an_established_pause_settles_stopped_and_late_commands_stay_inert':(
'PBK-002 D11/D14.7',
'未EOF且pause已established的episode stop为Stopped；late command不重标terminal',
'实际pause pair+quiescence；source不得在stop前EOF；HEAD Paced无限source固定此前提',
'Stopped、pause history保持、paused false、late commands不改Fact、dispose quiet',
'real Paused read-side证据 -> wait_terminal Fact -> dispose/join',
'real Session + TestDecode + TestOutput; request_pause -> gate -> request_stop -> edge stop -> worker/drain publish -> resolve',
'finite source可先EOF导致Completed；stop intent publication次序错误应被terminal oracle拒绝',
'PREMISE_CORRECTION_ACCEPTED','real-session on doubles; no acoustic/platform evidence'),
'a_paused_episode_can_seek_again_after_its_committed_cut':(
'PBK-002 D14.5/D14.7/D14.8',
'pause中两次cut均commit，第二landing可见；resume后没有pre-cut ring内容',
'第一rebase已见不等于slot-free；200ms settle；第二cut在同pause中',
'两次actual landing、pause连续；first post-resume sample属于最后landing及之后',
'Position及event derived read；complete content只查jump个数/landing，没关联commit后的消费边界',
'real worker Applied -> purge -> commit/release -> paused mock leg rebase -> next seek -> resume/content',
'I03漏purge；新first-post-commit-content oracle以保持pause固定消费边界',
'SLOT_PREMISE_AND_COMMIT_CONTENT_GAP','sleep slot debt persists; whole seek suite survives no-purge but existing separate worker oracle catches'),
'an_unknown_landing_withdraws_the_position_for_the_rest_of_the_episode':(
'PBK-002 D14.5/D14.8',
'unknown landing使Position永久withdraw；后续known landing不能恢复，内容仍依actual provider前进',
'初始sample真实存在；first unknown cut消费payload；第二request须slotfree（当前sleep200ms）',
'None到EOF；两个actual jumps；commit后不消费旧ring',
'Position None、terminal、whole content jumps；缺两个commit的消费边界marker',
'real worker+scripted provider -> mock gate rebase(None) -> subsequent known rebase -> consumption',
'restore publishing onknown；I03旧ring迟消费可保持整体两个jumps而过关',
'SLOT_PREMISE_AND_COMMIT_CONTENT_GAP','unknown permanence oracle valid; no slotfree acknowledgement; stale-PCM boundary not independently tagged'),
}
cards=[]
for i,r in enumerate(rows,1):
 name=r['TEST_ID'].split('::')[-1];v=D[name]
 card=dict(CARD_ID=f'C{i:02}',TEST_ID=r['TEST_ID'],TARGET=r['TARGET'],CRATE=r['CRATE'],SOURCE_PATH=r['TEST_FILE'],AUTHORITY=v[0],PROPERTY=v[1],PRECONDITION=v[2],LEGAL_OUTCOMES=v[3],OBSERVATION=v[4],REAL_CALL_CHAIN=v[5],FALSIFIER=v[6],AUDIT_DISPOSITION=v[7],LIMITS=v[8],PLATFORM_RUNTIME='Linux RUN_PASS; Windows local NOT_RUN; no device/FFI runtime claim')
 for which in ['base','head']:
  w=pathlib.Path('/home/hoo/Source/qianqian-h0-independent-'+which);s=subprocess.check_output(['git','show','HEAD:'+r['TEST_FILE']],cwd=w).decode();m=re.search(r'\bfn\s+'+re.escape(name)+r'\s*\(',s);assert m
  start=s.index('{',m.start());level=1;pos=start+1
  # Text extraction only: format strings in these specific bodies use
  # paired braces. Not advertised as a Rust parser or branch coverage tool.
  while level and pos<len(s):
   if s[pos]=='{':level+=1
   elif s[pos]=='}':level-=1
   pos+=1
  body=s[m.start():pos];d=root/'body-snapshots'/which;d.mkdir(parents=True,exist_ok=True);(d/f'C{i:02}.rs.txt').write_text(body+'\n')
  card[which.upper()+'_SOURCE_SHA']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip();card[which.upper()+'_LINE']=s[:m.start()].count('\n')+1;card[which.upper()+'_BODY_SHA256']=hashlib.sha256(body.encode()).hexdigest()
  matches=list((root/'runs').glob('*-'+which+f'-h0-{i:02}'));assert len(matches)==1
  meta=json.loads((matches[0]/'metadata.json').read_text());assert meta['rc']==0 and meta['test_results']==[['1','0']],meta
  card[which.upper()+'_RUN_ID']=meta['run_id']
 cards.append(card)
(root/'property-cards.json').write_text(json.dumps(cards,ensure_ascii=False,indent=2)+'\n')
with (root/'independent-before-after-ledger.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(cards[0]));w.writeheader();w.writerows(cards)
text=['# 18 条独立 property cards\n\n源码与authority推导；不继承PR disposition。完整before/after body与hash在body-snapshots/。\n']
for c in cards:
 text+=['\n## '+c['CARD_ID']+' — '+c['TEST_ID']+'\n']
 for k in ['SOURCE_PATH','AUTHORITY','PROPERTY','PRECONDITION','LEGAL_OUTCOMES','OBSERVATION','REAL_CALL_CHAIN','FALSIFIER','AUDIT_DISPOSITION','LIMITS','BASE_RUN_ID','HEAD_RUN_ID']:text.append('\n- **'+k+'**: '+str(c[k])+'\n')
(root/'property-cards.md').write_text(''.join(text))
print('Independent cards:',len(cards),'base/head executed:',36)
