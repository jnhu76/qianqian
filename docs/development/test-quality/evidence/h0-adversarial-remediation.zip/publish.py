from pathlib import Path
import csv,hashlib,json,re,shutil,subprocess,zipfile
r=Path(__file__).resolve().parent;repo=Path('/home/hoo/Source/qianqian');old=Path('/home/hoo/Source/qianqian-h0-independent-evidence');docs=repo/'docs/development/test-quality';ev=docs/'evidence';ev.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
# Exact old cards and before bodies remain immutable in the original bundle.
initial=list(csv.DictReader((old/'independent-before-after-ledger.csv').open()))
assert len(initial)==18
original=list(csv.DictReader((docs/'h0-before-after-ledger.csv').open()));groups={x['TEST_ID']:x['GROUP'] for x in original}
fixes={1:'9cb5041',2:'ebd81ab',3:'660871c',4:'660871c',5:'bbdf3f4',6:'bbdf3f4',7:'bbdf3f4',8:'bbdf3f4',9:'6dc8066',10:'bbdf3f4',11:'eda692e',12:'9259acb',13:'9259acb',14:'9259acb',15:'6fcf976',16:'9f117c7',17:'7bcd63f',18:'7bcd63f'}
extra={1:'finite reference rejects nonfinite; returned arena only, no scratch-copy exclusion',2:'guard before premise; actual control/probe collection on unwind; bounded progress oracle',3:'exact ordered whole cycle and 3 probes; all assertions own cleanup',4:'real Pending probe, negative through release/exit/join',5:'closed-before-arrival and close-while-parked; full abort sequence; actual join',6:'full delivery vector rather than last-wins Option; after join and next no-payload',7:'mid-pause receipt sequence; semantic assertion unwind releases both conditions and joins',8:'report then actual join; Failed, single abort, no invented quiescence',9:'pending before new hold and clear before next Aborted overwrites; real final consumer preserved',10:'ordered seek-only evidence plus single release vector and actual join',11:'actual Quiesced fence and precise one probe; rendezvous covers in-flight Pending/Quiesced',12:'unexpected park -> Failed exit -> close -> fixture rejection; duplicate callback not overwritten',13:'Disengaged before take then slot-free; fresh latches; M8 also rejected by this H0',14:'H1/Open/fence/teardown/H2 with all other predicates false; single H2 conjunct red',15:'actual Output.stop_and_join entry orders hostile pause; scoped child; rescue never PASS',16:'endless premise retained; test-owned root explicit disposal on assertion unwind',17:'real post-seek decoder read orders next request; on-leg offsets; settled first sample; controlled EOF',18:'real decoder read orders request2; live unknown remains withdrawn after known apply; per-cut first sample; EOF then dispose'}
limits={1:'synthetic composition flow; finite reference only; scratch copies outside address claim',2:'synthetic candidate publication mechanism; 10s watchdog is not fairness proof; cannot force-kill arbitrary hang',3:'one real RenderGate leg; ordered finite execution, not all schedules',4:'per-cycle Pending/Quiesced paths; not device evidence',5:'real port mechanism; no physical/backend runtime',6:'single-leg one routed seek premise; no provider/device runtime',7:'same-leg program order; no product apply-ack introduced',8:'failed device observation represented by TailProbe double; no real device',9:'defensive port case; production must not replace unconsumed committed release',10:'25ms diagnostic perturbation remains; actual publication provides premise',11:'finite deterministic interleavings; bound only diagnoses nonprogress',12:'whitebox manual evidence, not decoder/assembly/backend coverage',13:'whitebox per-cycle reset; actual worker purge covered separately',14:'existing per-instance fence; no new global scheduler or API',15:'existing provider lifecycle seam; bounded 5s progress detection; OQ-1 supersession proposed',16:'real session over doubles, no acoustic/platform claim',17:'source double/Output double; worker read proves slot-free not callback apply; OQ-6 supersession proposed',18:'source double/Output double; unknown target content from tagged source; OQ-6 supersession proposed'}
(r/'after-bodies').mkdir(exist_ok=True)
ledger=[]
for i,x in enumerate(initial,1):
 s=(repo/x['SOURCE_PATH']).read_text();name=x['TEST_ID'].split('::')[-1];m=re.search(r'\bfn\s+'+re.escape(name)+r'\s*\(',s);assert m
 start=s.index('{',m.start());level=1;pos=start+1
 while level and pos<len(s):
  level+=int(s[pos]=='{')-int(s[pos]=='}');pos+=1
 body=s[m.start():pos];(r/'after-bodies'/f'C{i:02}.rs.txt').write_text(body+'\n')
 runs=list((r/'runs').glob(f'*-settled-head-h0-{i:02}'));assert len(runs)==1
 meta=json.loads((runs[0]/'metadata.json').read_text());assert meta['rc']==0 and meta['test_results']==[['1','0']]
 assert sha((repo/x['SOURCE_PATH']).read_bytes())==meta['source_hashes'][x['SOURCE_PATH']]
 row={k:x[k] for k in ['CARD_ID','TEST_ID','CRATE','TARGET','SOURCE_PATH','AUTHORITY','PROPERTY','REAL_CALL_CHAIN']}
 row.update(GROUP=groups[x['TEST_ID']],BEFORE_SOURCE_SHA=x['HEAD_SOURCE_SHA'],BEFORE_LINE=x['HEAD_LINE'],BEFORE_BODY_SHA256=x['HEAD_BODY_SHA256'],BEFORE_RUN_ID=x['HEAD_RUN_ID'],AFTER_SOURCE_SHA=source_sha,AFTER_LINE=s[:m.start()].count('\n')+1,AFTER_BODY_SHA256=sha(body.encode()),AFTER_RUN_ID=meta['run_id'],AFTER_RUNTIME_SOURCE_SHA=meta['subject_sha'],FIX_COMMIT=subprocess.check_output(['git','rev-parse',fixes[i]],cwd=repo,text=True).strip(),DISPOSITION='FIXED_HYGIENE_VERIFIED' if i in [2,12,13,16] else 'FIXED_AND_FALSIFIED',AFTER_ORACLE_AND_CLEANUP=extra[i],LIMITS=limits[i],OWNER_DECISION='OQ_SUPERSESSION_PROPOSED; Ready pending' if i in [15,17,18] else 'Ready pending',PLATFORM='Linux RUN_PASS; Windows MSVC COMPILE_ONLY; other runtime/device NOT_RUN')
 ledger.append(row)
def writecsv(path,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
writecsv(docs/'h0-disposition-ledger.csv',ledger)
invalid={x['run_id']:x for x in json.loads((r/'invalid-attempts.json').read_text())}
index=[]
for p in sorted((r/'runs').glob('*/metadata.json')):
 m=json.loads(p.read_text());label=m['run_id'];log=(p.parent/'stdout-stderr.log').read_bytes();assert sha(log)==m['log_sha256'];assert sha((p.parent/'patch.diff').read_bytes())==m['patch_sha256']
 if label in invalid:cls='INVALID_BUILD_ARTIFACT_IDENTITY'
 elif 'survives' in label:cls='ORIGINAL_ORACLE_MUTANT_SURVIVES'
 elif 'windows' in label:cls='COMPILE_ONLY_PASS' if m['rc']==0 else 'COMPILE_FAILURE'
 elif m['rc']==0:cls='STRESS_RUN_PASS' if 'cpu-pressure' in label else 'GATE_PASS' if 'gate' in label or 'pre-push' in label else 'RUN_PASS'
 elif 'final-f5-implementation-gate' in label:cls='TOOLING_FAIL_MUTANT_APPLICATION'
 elif 'clippy-first' in label:cls='QUALITY_GATE_FAILURE'
 elif not m['test_results']:cls='COMPILE_FAILURE'
 elif 'destructor-lock-progress' in label or 'teardown-real-entry-negative' in label:cls='BOUNDED_PROGRESS_MUTANT_CAUGHT'
 elif 'session-root-unwind-negative' in label or 'completion-invalid-resume-negative' in label:cls='FIXTURE_FAULT_CAUGHT'
 else:cls='SEMANTIC_MUTANT_CAUGHT'
 mlink='runs/'+label+'/metadata.json';index.append(dict(RUN_ID=label,CLASSIFICATION=cls,SUBJECT_SHA=m['subject_sha'],ARGV=json.dumps(m['argv'],ensure_ascii=False),CWD=m['cwd'],COUNTS=json.dumps(m['test_results']),RC=m['rc'],EXTERNAL_TIMEOUT=m['external_timeout'],START_UTC=m['started_utc'],END_UTC=m['ended_utc'],SECONDS=round(m['seconds'],3),LOG_SHA256=m['log_sha256'],PATCH_SHA256=m['patch_sha256'],METADATA_IN_ARCHIVE=mlink,RAW_LOG_IN_ARCHIVE='runs/'+label+'/stdout-stderr.log',PATCH_IN_ARCHIVE='runs/'+label+'/patch.diff'))
writecsv(docs/'h0-adversarial-execution-index.csv',index)
matrix=[x for x in index if 'negative' in x['RUN_ID'] or 'survives' in x['RUN_ID'] or x['CLASSIFICATION'] not in ['RUN_PASS','GATE_PASS','STRESS_RUN_PASS','COMPILE_ONLY_PASS']]
writecsv(docs/'h0-adversarial-mutation-matrix.csv',matrix)
(r/'execution-index.csv').write_bytes((docs/'h0-adversarial-execution-index.csv').read_bytes());(r/'mutation-matrix.csv').write_bytes((docs/'h0-adversarial-mutation-matrix.csv').read_bytes());(r/'disposition-ledger.csv').write_bytes((docs/'h0-disposition-ledger.csv').read_bytes())
(r/'git-history.txt').write_bytes(subprocess.check_output(['git','log','--reverse','--format=fuller','b002a693..HEAD'],cwd=repo))
# Archive precisely the retained audit ZIP: do not rebuild its historical data.
shutil.copyfile(old/'audit-bundle.zip',ev/'h0-independent-audit.zip')
assert sha((ev/'h0-independent-audit.zip').read_bytes())=='b58886259b40147ea04736cdd6f448eead09b7066cb818719adde28591cd48a7'
selected=[p for p in r.rglob('*') if p.is_file() and 'target' not in p.relative_to(r).parts and p.name not in ['audit-bundle.zip','SHA256SUMS']]
manifest=''.join(sha(p.read_bytes())+'  '+str(p.relative_to(r))+'\n' for p in sorted(selected))
(r/'SHA256SUMS').write_text(manifest)
with zipfile.ZipFile(ev/'h0-adversarial-remediation.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in selected+[r/'SHA256SUMS']:z.write(p,p.relative_to(r))
with zipfile.ZipFile(ev/'h0-adversarial-remediation.zip') as z:
 assert z.testzip() is None
 for line in z.read('SHA256SUMS').decode().splitlines():
  digest,name=line.split('  ',1);assert sha(z.read(name))==digest,name
checks=''.join(sha((ev/name).read_bytes())+'  '+name+'\n' for name in ['h0-independent-audit.zip','h0-adversarial-remediation.zip'])
(ev/'SHA256SUMS').write_text(checks)
from collections import Counter
print(json.dumps({'runs':len(index),'classes':dict(Counter(x['CLASSIFICATION'] for x in index)),'dispositions':dict(Counter(x['DISPOSITION'] for x in ledger)),'archives':checks},indent=2))
