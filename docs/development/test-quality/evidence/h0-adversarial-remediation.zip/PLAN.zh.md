# H0 对抗性修复预登记

修复前 subject b002a69370fb623b210c019da096a1fb4a6507e7；基线 daad414582b2a31eddc4a5b3fdb85bcce4bd60b0。
18 张独立性质卡和修复前反例保留在 ../qianqian-h0-independent-evidence，身份逐项匹配，不重写旧结果。

1. C05-C11 release capture 改为完整交付序列；预抵达、park exit、mid-pause、失败出口重复 dispatch 都须被相关原测试拒绝。测试拥有线程的 guard 在首次 fallible 操作前建立；panic 时 close/release 再 actual join。
2. C03-C04 完整事件顺序，第三 cycle 用真实 Pending callback witness；release+join 后 negative 仍成立；late-tail mutant 必须在事件 Oracle RED。全出口异常释放，原 panic 保留。
3. C02 blocking destructor 在 entry wait 前拥有 release 与线程收集；lock-held drop mutant 应在 progress assertion RED，但清理必须回收 control/probe；entry 失败和 assert 失败分别验证。
4. C01 有限 reference Oracle 必须拒绝 NaN/±Inf；有限误差在容差内可接受，超界拒绝，Identity 原路径正控制保持；同 arena NaN mutant 应令原 honest-path RED。
5. C12-C14 独立 H2 teardown straddle 使用已有 FencedRequest；single-H2 删除应 RED。consume_release 对意外 park 观察 bounded callback 并释放/join，实际已到 park 不能被当作合法 consumption；计数避免覆盖。
6. C15-C18 测试作用域保有显式 disposer（不修改生产 Drop）；解锁 held TailProbe 后 dispose。真实 fixture panic 后不能留下 real legs。C15 通过测试 Output stop_and_join 入口建立 release witness，hostile pause 后实际 join；超时救援 close 仅作为清理，不能冒充进展 PASS。
7. C17-C18 slot-free 用实际 decoder post-seek read 的程序顺序证明（Applied clear slot→read）；不能把 Position/消失 payload 直接当 slot-free。每个 cut 建立消费边界，final dispose 后 first post-commit sample 应为实际 landing；no-purge mutant 在真实链 RED。OQ-1/OQ-6 作为提出新合法 witness 的显式 superseding proposal，非暗自撤销 owner 决定。

按性质组独立 commit；每次保存源码身份、命令、非空目标数量、日志和 hash。mutant 仅隔离工作树，串行跑完再切源码，并恢复 byte/hash 验证。
最终完整 pre-push gate，必要 Loom/Miri/Windows compile/CI/Formal 通道实跑或 NOT_RUN；无真实设备不标 platform runtime PASS。
不改生产语义、公开 API、ADR、依赖、门禁；未赚得的架构概念不实施。独立 fresh-context review 尚需单独执行，不能把自检冒充独立 review。

## 后续独立推导（先登记再执行对应新故障）
C18 的最终 terminal 状态本来就会隐藏 Position，因此只在 Completed 后检查 None 不能独立排除第二次 known rebase 在运行期重新发布。修复将真实 commit callback 应用后 marker 与 test-owned EOF permission 组合，先在未结束 episode 上查 None，再放行 EOF。新增 falsifier：mock render provider 在 known landing 时重新将 publishing 设 true（真实 Session / PositionEvidence 调用链，provider 仍为 double，不声称 WASAPI runtime）；必须在 live withdrawal 断言 RED。
原修复前证据没有执行此新 fault，需在冻结 b002 测试上另跑对照，不能用 no-purge 反例替代。

## C09 继续按路径复核（新增最小反例，先登记再执行）
旧 C09 在第二次 release(Aborted) 后才检查最终 payload，第二次写入可掩盖 new-hold 没有清掉 stale release。Falsifier 删除 set_seek_hold(true) 对 seek_release 的 reset；冻结 b002 原 C09 预期存活，修复须在真实 pending=true→new hold→pending=false 边界 RED，并保留实际 consumer 出口覆盖。使用已有 seek_release_pending 机制读，不创建新 slot/free API，scope 仍为 defensive port case，不声称生产合法 seek 会覆盖旧 committed payload。
