# H0 修复执行证据

这是本仓库案例的执行归档，不是可直接安装的通用测试框架。完整中文报告在 PR 的 docs/development/test-quality/h0-adversarial-remediation.zh.md；方法入口是 issue #262。

## 内容与复现

execution-index.csv / mutation-matrix.csv / disposition-ledger.csv 关联 RUN_ID；runs/<RUN_ID> 下保留 metadata.json、未截断 stdout-stderr.log 与 patch.diff。after-bodies 保留修复后 18 个函数体。工具脚本、预登记、事后新推导、无效与 setup 失败、提交历史、source restoration proof 都在包内。

复现一个单次 run：

1. 在可访问该 repo 提交的 checkout 里，取 metadata.subject_sha 建立独立 detached worktree。
2. 应用该 run 的 patch.diff；它可能包含当时尚未提交的修复或完整 mutant 差异，不要只挑名字里的一个 fault。
3. 根据元数据配置同一 toolchain / target / features / 环境键。每个 worktree 使用自己的 Cargo target；未来并行研究若有共享身份也应再细分。
4. 执行 metadata.argv；Cargo filter 必须真实非空。比较失败归因和目标数量，不要求 thread id/编译耗时等不稳定日志逐字相同。
5. 对 GateLeg / source 模型诊断压力，明确 bound、假设、实际资源清理，不能把 timeout 当 HB，也不能声称强制终止任意 hang。

脚本目前包含本机 worktree 路径，需按上述流程重定向。不能在 canonical 工作树上运行 mutate.py。聚合 gate 内部会隐藏或删除部分 child 日志；保留的是原 gate 的完整外部输出，不伪装成所有子进程 trace。kernel native/Miri 有补充完整目标输出。

## 失败和身份

invalid-attempts.json 排除共享构建目录污染的那个正控制，之后已隔离目录重跑。setup-failures.json 是事后整理的 setup 工具失败，不是执行时 stderr 镜像；对应完整 F5 gate 日志也保留。编译失败与 clippy failure 不计 semantic RED。F5 原 4 个 stale patches 已按原 fault 含义重定位并捕获，未修改 CI 规则。

SHA256SUMS 校验归档内文件；ZIP 自身 SHA256 在 repo evidence/SHA256SUMS 中。旧独立审计的 archive 不重建、不改标结果；本轮关键旧 green 在 b002 + 隔离 target 复现。Native/MSVC compile、Miri、Loom、TLC 各有自身 scope，不能被合并成真实设备、FFI 或全平台 runtime PASS。
