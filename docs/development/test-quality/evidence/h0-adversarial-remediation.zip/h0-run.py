import csv,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
which=sys.argv[1] if len(sys.argv)>1 else 'final'
w='/home/hoo/Source/qianqian'
inventory=pathlib.Path('/home/hoo/Source/qianqian-h0-independent-evidence/frozen-inventory.csv')
rows=[r for r in csv.DictReader(inventory.open()) if r['RISK']=='R-H' and r['RH_TAG']=='H0']
assert len(rows)==18
for i,r in enumerate(rows,1):
    name=r['TEST_ID'].split('::',1)[1]
    argv=['cargo','test','-p',r['CRATE']]
    if r['TARGET']=='qianqian_playback':argv+=['--lib']
    else:argv+=['--test',r['TARGET']]
    argv += [name,'--','--exact','--nocapture']
    subprocess.run(['python3',str(root/'run.py'),f'{which}-h0-{i:02}',w,*argv],check=True)
    candidates=sorted((root/'runs').glob('*-'+f'{which}-h0-{i:02}'))
    m=__import__('json').loads((candidates[-1]/'metadata.json').read_text())
    assert m['rc']==0 and m['test_results']==[['1','0']],m
