from pathlib import Path
p=Path('crates/qianqian-audio-api/tests/render_gate.rs');s=p.read_text()
s=s.replace('use std::sync::atomic::Ordering;', 'use std::sync::atomic::{AtomicBool, Ordering};')
a=s.index('/// Join a RELEASED leg');b=s.index('#[derive(Clone, Default)]',a)
other=Path('crates/qianqian-audio-api/tests/render_gate_seek.rs').read_text();x=other.index('/// Own the gate');y=other.index('/// A full seek park:',x)
s=s[:a]+other[x:y]+s[b:]
# First full park: own before waits, exact ordered sequence at actual join.
a=s.index('fn a_park_publishes');b=s.index('/// Each NEW engagement',a);part=s[a:b]
part=part.replace('    assert!(\n        wait_until', '    let leg = GateLeg::new(&gate, leg);\n    assert!(\n        wait_until',1)
part=part.replace('join_released_leg(leg, "the parked leg after its release")','leg.join("the parked leg after its release")')
x=part.index('    let seen = events.snapshot();')
part=part[:x]+'''    assert_eq!(events.snapshot(), vec![GateEvent::Engaged, GateEvent::TailQuiesced, GateEvent::Disengaged]);
    assert_eq!(tail_calls.load(Ordering::SeqCst), 3, "quiescence on probe 3 stops future probes");
}

'''
s=s[:a]+part+s[b:]
a=s.index('fn tail_quiescence_belongs');b=s.index('/// The open-abort lifetime',a)
s=s[:a]+'''fn tail_quiescence_belongs_to_each_engagement_separately() {
    let events = Events::default();
    let writer = events.clone();
    let gate = RenderGate::with_observer(move |event| writer.record(event));
    let mut expected = Vec::new();
    for cycle in 1..=2 {
        gate.set_paused(true);
        let leg_gate = gate.clone();
        let leg = GateLeg::new(&gate, std::thread::spawn(move || pause_only(&leg_gate, || true)));
        assert!(wait_until(Duration::from_secs(5), || events.snapshot().iter().filter(|e| **e == GateEvent::TailQuiesced).count() == cycle), "cycle {cycle} must earn its own quiescence");
        gate.set_paused(false);
        leg.join("quiesced pause cycle");
        expected.extend([GateEvent::Engaged, GateEvent::TailQuiesced, GateEvent::Disengaged]);
        assert_eq!(events.snapshot(), expected, "each settled cycle has its own ordered evidence");
    }

    // Real Pending callback, not a timed negative window. Observe the
    // entire cycle through release AND actual join, including exit events.
    gate.set_paused(true);
    let (tx, rx) = std::sync::mpsc::channel();
    let leg_gate = gate.clone();
    let leg = GateLeg::new(&gate, std::thread::spawn(move || pause_only(&leg_gate, || {
        let _ = tx.send(());
        false
    })));
    rx.recv_timeout(Duration::from_secs(5)).expect("third cycle reached its real Pending probe");
    let mut prefix = expected.clone();
    prefix.push(GateEvent::Engaged);
    assert_eq!(events.snapshot(), prefix, "prior quiescence cannot authorize the Pending cycle");
    gate.set_paused(false);
    leg.join("Pending pause cycle");
    expected.extend([GateEvent::Engaged, GateEvent::Disengaged]);
    assert_eq!(events.snapshot(), expected, "no quiescence, including at the release/exit outlet");
}

'''+s[b:]
# Other three tests discarded handles. Retain every spawned leg immediately.
for name in ['a_closed_gate_never_parks_or_engages_again', 'a_failed_tail_observation_exits_the_pause_park_without_quiescence','a_failed_pause_park_still_delivers_a_routed_committed_payload']:
 a=s.index('fn '+name);b=s.find('\n}\n',a);part=s[a:b]
 part=part.replace('    {\n        let gate = gate.clone();','    let leg = {\n        let gate = gate.clone();',1)
 part=part.replace('        });\n    }\n', '        })\n    };\n    let leg = GateLeg::new(&gate, leg);\n',1)
 if name.startswith('a_closed_gate'):
  part=part.replace('    assert_eq!(\n        tail_calls', '    leg.join("closed gate leg");\n    assert_eq!(\n        tail_calls',1)
 else:
  part=part.replace('    assert_eq!(outcome,', '    leg.join("failed pause probe leg");\n    assert_eq!(outcome,',1)
  part=part.replace('    assert_eq!(\n        outcome,', '    leg.join("failed pause probe leg");\n    assert_eq!(\n        outcome,',1)
 s=s[:a]+part+s[b:]
s=s.replace('Arc<Mutex<Option<SeekParkRelease>>>','Arc<Mutex<Vec<SeekParkRelease>>>').replace('Arc::new(Mutex::new(None))','Arc::new(Mutex::new(Vec::new()))').replace('*sink.lock().expect("release lock") = Some(release);','sink.lock().expect("release lock").push(release);')
s=s.replace('Some(SeekParkRelease::Committed { landing: Some(9) })','vec![SeekParkRelease::Committed { landing: Some(9) }]')
s=s.replace('    wait_until(Duration::from_secs(5), || {\n        captured.lock().expect("release lock").is_some()\n    });','    assert!(wait_until(Duration::from_secs(5), || {\n        !captured.lock().expect("release lock").is_empty()\n    }), "committed callback must arrive before forcing the failed-tail exit");')
# Explicit unwind coverage for pause fixture uses existing proven owner semantics.
s+='''
#[test]
fn a_pause_assertion_after_engagement_releases_and_joins() {
    let gate = RenderGate::new();
    gate.set_paused(true);
    let (tx, rx) = std::sync::mpsc::channel();
    let leg_gate = gate.clone();
    let leg = GateLeg::new(&gate, std::thread::spawn(move || pause_only(&leg_gate, || { let _ = tx.send(()); false })));
    let joined = leg.joined.clone();
    let panic = std::panic::catch_unwind(std::panic::AssertUnwindSafe(move || {
        let _owned = leg;
        rx.recv_timeout(Duration::from_secs(5)).expect("real Pending park");
        panic!("original pause assertion");
    })).expect_err("assertion must propagate");
    assert_eq!(panic.downcast_ref::<&str>(), Some(&"original pause assertion"));
    assert!(joined.load(Ordering::SeqCst));
}
'''
p.write_text(s)
