from pathlib import Path
p=Path('crates/qianqian-playback/tests/seek_seam.rs');s=p.read_text()
# Check settled content at real on-leg commit receipt boundaries. A paused
# cut superseded before any submission has an empty legal window.
pos=s.index('/// Indices where the position-tagged sequence')
s=s[:pos]+'''/// After disposal, each nonempty submission window starts at that cut's
/// actual source landing. Final jump counts cannot establish this boundary.
fn assert_committed_windows(witnesses: &Witnesses, expected: &[(Option<u64>, u64)]) {
    let cuts = witnesses.committed_offsets.lock().unwrap().clone();
    let values = content(witnesses);
    assert_eq!(cuts.len(), expected.len(), "every committed callback, not last wins");
    for (i, &(landing, actual)) in expected.iter().enumerate() {
        assert_eq!(cuts[i].0, landing, "cut {i} receipt");
        let first = cuts[i].1;
        let end = cuts.get(i + 1).map_or(values.len(), |c| c.1);
        assert!(first <= end && end <= values.len(), "submission indices must be ordered");
        if first < end {
            assert_eq!(values[first], actual as f32, "cut {i}: first submission after committed receipt must exclude old ring PCM");
        }
    }
}

'''+s[pos:]
for name in ['an_unknown_landing_withdraws_the_position_for_the_rest_of_the_episode','a_paused_episode_can_seek_again_after_its_committed_cut']:
 a=s.index('fn '+name);b=s.index('\n}\n',a);part=s[a:b]
 part=part.replace('= episode(vec![', '= episode_with_source_policy(vec![',1).replace('        ]);','        ], &ProducerFreezeWitness::default(), true);',1)
 if name.startswith('an_unknown'):
  x=part.index('        // A second committed cutover');y=part.index('        handle.request_seek(Duration::from_secs(6));',x)
  part=part[:x]+'''        // The real worker read comes AFTER payload take and slot-free;
        // Position None alone occurs earlier and cannot order request 2.
        wait_post_seek_read(&witnesses, 1);
'''+part[y:]
  x=part.index('        assert!(\n            wait_until',part.index('handle.request_seek(Duration::from_secs(6))'));y=part.index('        assert_eq!(handle.wait_terminal()',x)
  part=part[:x]+'''        wait_post_seek_read(&witnesses, 2);
'''+part[y:]
  x=part.index('        // Both cuts are in the content')
  part=part[:x]+'''        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        assert_committed_windows(&witnesses, &[(None, FIVE_SECONDS), (Some(later_landing), later_landing)]);
'''+part[x:]
  # Remove the original trailing dispose (after settled checks now redundant).
  x=part.rfind('        let snapshot = runtime.dispose().snapshot;')
  part=part[:x]+part[x:].replace('        let snapshot = runtime.dispose().snapshot;\n        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");\n','',1)
 else:
  x=part.index('        handle.request_seek(Duration::from_secs(5));')
  part=part[:x]+'''        let paused_prefix = content(&witnesses).len();
'''+part[x:]
  x=part.index('        // Linearization window before firing');y=part.index('        handle.request_seek(Duration::from_secs(6));',x)
  part=part[:x]+'''        // Real worker program order establishes slot-free, including on
        // Windows timer granularity; neither sleep nor repeated requests.
        wait_post_seek_read(&witnesses, 1);
'''+part[y:]
  x=part.index('        let still = handle.observe();')
  part=part[:x]+'''        wait_post_seek_read(&witnesses, 2);
'''+part[x:]
  x=part.index('        // Both mid-pause cuts purged')
  part=part[:x]+'''        let snapshot = runtime.dispose().snapshot;
        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");
        let cuts = witnesses.committed_offsets.lock().unwrap().clone();
        assert_eq!(cuts.iter().map(|c| c.1).collect::<Vec<_>>(), vec![paused_prefix, paused_prefix], "no submission during either paused cut");
        assert_committed_windows(&witnesses, &[(Some(FIVE_SECONDS), FIVE_SECONDS), (Some(second_landing), second_landing)]);
'''+part[x:]
  x=part.rfind('        let snapshot = runtime.dispose().snapshot;')
  part=part[:x]+part[x:].replace('        let snapshot = runtime.dispose().snapshot;\n        assert!(snapshot.quiet, "teardown must stay quiet: {snapshot:?}");\n','',1)
 s=s[:a]+part+s[b:]
p.write_text(s)
