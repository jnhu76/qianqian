from pathlib import Path
import difflib,hashlib,json
root=Path('/home/hoo/Source/qianqian');out=[]
def emit(name,path,change):
 p=root/path;old=p.read_text();new=change(old);assert old!=new
 patch='diff --git a/'+path+' b/'+path+'\n'+''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path,n=3))
 target=root/'specs/f5-seek-implementation/mutations'/name;target.write_text(patch)
 assert p.read_text()==old
 out.append({'patch':str(target.relative_to(root)),'source':path,'source_sha256':hashlib.sha256(old.encode()).hexdigest(),'fault_source_sha256':hashlib.sha256(new.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()})
def cut(s,old,new):assert s.count(old)==1;(None);return s.replace(old,new)
p='crates/qianqian-playback/src/completion.rs'
emit('M3ParkHoldUnrouted.patch',p,lambda s:cut(s,'            self.state.gate.set_seek_hold(true);\n',''))
emit('M8StaleCutEvidence.patch',p,lambda s:cut(s,'            guard.seek_landing = None;\n            guard.seek_refused = false;\n            guard.cut_committed = false;\n',''))
p='crates/qianqian-playback/src/session.rs'
def late_landing(s):
 s=cut(s,'                                completion.seek_landing_published(landing);\n','')
 return cut(s,'                                // The commit routed the rebase release;','                                completion.seek_landing_published(landing);\n                                // The commit routed the rebase release;')
emit('M5CommitBeforeLanding.patch',p,late_landing)
emit('M7ResumeAfterMutatedSeek.patch',p,lambda s:cut(s,'                                completion.decode_failed(&format!("seek failed: {diagnostic}"));\n                                edge.fail();\n                                return;\n','                                completion.decode_failed(&format!("seek failed: {diagnostic}"));\n'))
Path('/home/hoo/Source/qianqian-h0-remediation-evidence/refreshed-f5-patches.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
