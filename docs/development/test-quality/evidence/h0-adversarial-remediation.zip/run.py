import datetime, hashlib, json, os, pathlib, platform, re, signal, subprocess, sys, time

root=pathlib.Path(__file__).resolve().parent
label,cwd,*argv=sys.argv[1:]
run_id=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+label
d=root/'runs'/run_id;d.mkdir(parents=True,exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=cwd)
subject_start=git('rev-parse','HEAD').decode().strip()
patch=git('diff','--binary','HEAD');(d/'patch.diff').write_bytes(patch)
source={}
for f in git('ls-files','-z').decode().split('\0'):
 if f and (f.endswith('.rs') or f.endswith('Cargo.toml') or f.endswith('Cargo.lock')):source[f]=hashlib.sha256((pathlib.Path(cwd)/f).read_bytes()).hexdigest()
env=os.environ.copy();env['CARGO_TARGET_DIR']=str(root/'target'/pathlib.Path(cwd).name)
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic();timeout=False
with (d/'stdout-stderr.log').open('wb') as log:
 p=subprocess.Popen(argv,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:rc=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:rc=p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
raw=(d/'stdout-stderr.log').read_bytes();s=raw.decode(errors='replace');counts=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed',s)
end_source={f:hashlib.sha256((pathlib.Path(cwd)/f).read_bytes()).hexdigest() for f in source}
assert source == end_source, 'INVALID_SOURCE_IDENTITY_RACE: retain this directory and exclude the run'
meta=dict(run_id=run_id,subject_sha=subject_start,ended_subject_sha=git('rev-parse','HEAD').decode().strip(),argv=argv,cwd=cwd,started_utc=start,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-t,rc=rc,external_timeout=timeout,platform=platform.platform(),toolchain={x:subprocess.check_output([x,'--version']).decode().strip() for x in ['rustc','cargo']},environment={k:env[k] for k in ['CARGO_TARGET_DIR','RUSTFLAGS','QIANQIAN_NATIVE_DIR'] if k in env},source_hashes=source,log_sha256=hashlib.sha256(raw).hexdigest(),patch_sha256=hashlib.sha256(patch).hexdigest(),test_results=counts,test_targets_run=re.findall(r'Running (.*)',s))
binaries={}
for binary in re.findall(r'Running .*?\(([^()]+)\)',s):
 bp=pathlib.Path(binary)
 if bp.is_file():binaries[binary]=hashlib.sha256(bp.read_bytes()).hexdigest()
meta['target_artifact_sha256']=binaries
if '+nightly' in argv:
 meta['nightly_toolchain']={'rustc':subprocess.check_output(['rustc','+nightly','--version']).decode().strip(),'miri':subprocess.check_output(['cargo','+nightly','miri','--version']).decode().strip()}
(d/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({k:meta[k] for k in ['run_id','rc','external_timeout','seconds','test_results','log_sha256','patch_sha256']}),flush=True)
print(s[-2500:],flush=True)
