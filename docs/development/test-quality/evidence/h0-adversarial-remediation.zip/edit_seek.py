from pathlib import Path
p=Path('crates/qianqian-audio-api/tests/render_gate_seek.rs')
s=p.read_text()
s=s.replace('/// release payload captured into the returned slot (last wins; the\n/// session routes at most one per seek).','/// release appended to the returned delivery sequence. Checking the whole\n/// sequence distinguishes one delivery from duplicate callbacks of one payload.')
s=s.replace('Arc<Mutex<Option<SeekParkRelease>>>','Arc<Mutex<Vec<SeekParkRelease>>>').replace('Arc::new(Mutex::new(None))','Arc::new(Mutex::new(Vec::new()))')
s=s.replace('*sink.lock().expect("release lock") = Some(release);','sink.lock().expect("release lock").push(release);')
s=s.replace('*captured.lock().expect("release lock") = Some(release);','captured.lock().expect("release lock").push(release);')
s=s.replace('.is_none()', '.is_empty()')
s=s.replace('Some(SeekParkRelease::Aborted)', 'vec![SeekParkRelease::Aborted]')
s=s.replace('Some(SeekParkRelease::Committed { landing: Some(7) })','vec![SeekParkRelease::Committed { landing: Some(7) }]')
s=s.replace('Some(SeekParkRelease::Committed { landing: Some(5) })','vec![SeekParkRelease::Committed { landing: Some(5) }]')
s=s.replace('Some(SeekParkRelease::Committed {\n            landing: Some(44_100)\n        })','vec![SeekParkRelease::Committed {\n            landing: Some(44_100)\n        }]')
a=s.index('/// A failed premise must still COLLECT');b=s.index('/// A full seek park:',a)
s=s[:a]+'''/// Own the gate and its leg BEFORE any fallible wait/assert. Drop releases
/// both park conditions, then observes exit and actually joins. Normal join
/// does not release the gate: the test must drive its intended exit first.
/// The deadline is a failure bound, never an ordering premise; a genuinely
/// stuck thread cannot be force-terminated by this owner.
struct GateLeg<T> {
    gate: RenderGate,
    leg: Option<std::thread::JoinHandle<T>>,
}

impl<T> GateLeg<T> {
    fn new(gate: &RenderGate, leg: std::thread::JoinHandle<T>) -> Self {
        Self { gate: gate.clone(), leg: Some(leg) }
    }

    fn join(mut self, what: &str) -> T {
        assert!(
            wait_until(Duration::from_secs(5), || self.leg.as_ref().unwrap().is_finished()),
            "leg never exited within 5s: {what}"
        );
        match self.leg.take().unwrap().join() {
            Ok(value) => value,
            Err(panic) => std::panic::resume_unwind(panic),
        }
    }
}

impl<T> Drop for GateLeg<T> {
    fn drop(&mut self) {
        if let Some(leg) = self.leg.take() {
            self.gate.close_and_release();
            let exited = wait_until(Duration::from_secs(5), || leg.is_finished());
            let joined = exited && leg.join().is_ok();
            eprintln!("gate leg cleanup: exited_within_5s={exited}, joined={joined}");
            if !joined && !std::thread::panicking() {
                panic!("gate leg cleanup did not join cleanly");
            }
        }
    }
}

'''+s[b:]
# Bind every retained leg immediately after spawn; no waits/asserts in between.
s=s.replace('    let parked_ok = wait_until', '    let leg = GateLeg::new(&gate, leg);\n    let parked_ok = wait_until',1)
s=s.replace('    if !wait_until(Duration::from_secs(5), || parked.load(Ordering::SeqCst)) {','    let leg = GateLeg::new(&gate, leg);\n    if !wait_until(Duration::from_secs(5), || parked.load(Ordering::SeqCst)) {')
# close test has its own gate2.
start=s.index('fn a_closed_gate_never_seek_parks_again()');end=s.index('/// The tail observation',start)
part=s[start:end].replace('GateLeg::new(&gate, leg)','GateLeg::new(&gate2, leg)');s=s[:start]+part+s[end:]
# Convert premise helpers to direct assertions: owned Drop now covers ALL panic exits.
import re
s=re.sub(r'fail_premise_releasing_(?:pause_)?leg\(\s*&gate2?,\s*leg,\s*("[^"]*"),?\s*\);', r'panic!(\1);',s)
s=re.sub(r'join_released_leg\(leg, ("[^"]*")\)',r'leg.join(\1)',s)
# Success send is not exit: join before semantic assertions, retaining failure cleanup.
needle='    assert_eq!(\n        outcome,\n        ParkOutcome::TailProbeFailed,'
s=s.replace(needle,'    leg.join("failed-tail leg after its reported exit");\n'+needle)
# Mid-park snapshot is a prefix assertion; normal join checks whole ordered cycle.
a=s.index('    let snapshot = events.snapshot();',s.index('fn a_committed_release_rebases'))
b=s.index('\n}\n',a)
s=s[:a]+'''    assert_eq!(events.snapshot(), vec![
        GateEvent::Engaged, GateEvent::TailQuiesced, GateEvent::Disengaged,
    ], "one continuous ordered pause cycle, no seek evidence");'''+s[b:]
# Deterministic probe witness: wait for actual quiescence, then exact one call at join.
a=s.index('    let before = calls.load',s.index('fn the_seek_park_calls'));b=s.index('\n}\n',a)
s=s[:a]+'''    let captured = leg.join("the parked leg after its abort release");
    assert_eq!(calls.load(Ordering::SeqCst), 1, "no probe after the quiesced first slice or release");
    assert_eq!(*captured.lock().unwrap(), vec![SeekParkRelease::Aborted]);
    let again = gate_probe(&gate, || panic!("unheld gate must not probe"));
    assert!(again.lock().unwrap().is_empty());'''+s[b:]
# Need actual quiescence fence before releasing in this test (flag is earlier than return).
a=s.index('fn the_seek_park_calls');b=s.index('\n}\n',a)
part=s[a:b].replace('    let gate = RenderGate::new();','    let events = Events::default();\n    let writer = events.clone();\n    let gate = RenderGate::with_observer(move |event| writer.record(event));')
part=part.replace('    let captured = leg.join(','''    assert!(wait_until(Duration::from_secs(5), || events.snapshot().contains(&GateEvent::SeekTailQuiesced)), "first probe must publish quiescence");
    gate.release_seek_hold(SeekParkRelease::Aborted);
    let captured = leg.join(''')
s=s[:a]+part+s[b:]
p.write_text(s)
