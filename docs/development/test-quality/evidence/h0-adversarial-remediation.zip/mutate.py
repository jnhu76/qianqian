from pathlib import Path
import subprocess,sys
w=Path('/home/hoo/Source/qianqian-h0-remediation-mutants')
main=Path('/home/hoo/Source/qianqian')
case=sys.argv[1]
subprocess.run(['git','restore','--source=b002a69370fb623b210c019da096a1fb4a6507e7','--staged','--worktree','.'],cwd=w,check=True)
# This isolated worktree has no user changes. Copy only current Rust test changes.
for p in ([] if '--baseline' in sys.argv else subprocess.check_output(['git','diff','--name-only','b002a69370fb623b210c019da096a1fb4a6507e7','--','crates'],cwd=main,text=True).splitlines()):
 if p.endswith('.rs'):
  (w/p).parent.mkdir(parents=True,exist_ok=True);(w/p).write_bytes((main/p).read_bytes())
def replace(path,old,new):
 p=w/path;s=p.read_text();assert s.count(old)==1,(path,s.count(old),old[:80]);p.write_text(s.replace(old,new))
port='crates/qianqian-audio-api/src/ports.rs'
if case in ('duplicate-seek','duplicate-pause','duplicate-arrival','late-tail','extra-probe'):
 p=w/port;s=p.read_text()
 if case=='duplicate-seek':
  old='        slice(GateSlice::SeekRelease(release));\n        if probe_failed {'
  replace(port,old,'        slice(GateSlice::SeekRelease(release));\n        slice(GateSlice::SeekRelease(release)); // FAULT duplicate seek-exit delivery\n        if probe_failed {')
 if case=='duplicate-pause':
  old='                slice(GateSlice::SeekRelease(release));\n            }\n            if released {'
  replace(port,old,'                slice(GateSlice::SeekRelease(release));\n                slice(GateSlice::SeekRelease(release)); // FAULT duplicate mid-pause delivery\n            }\n            if released {')
 if case=='duplicate-arrival':
  a=s.index('    fn seek_park(');b=s.index('        self.emit(GateEvent::SeekEngaged);',a);part=s[a:b]
  old='                    slice(GateSlice::SeekRelease(release));'
  assert part.count(old)==1
  part=part.replace(old,old+'\n                slice(GateSlice::SeekRelease(release)); // FAULT duplicate pre-arrival delivery')
  p.write_text(s[:a]+part+s[b:])
 if case=='late-tail':
  a=s.index('    fn pause_park(');b=s.index('    fn seek_park(',a);part=s[a:b]
  old='            if released {\n                break;\n            }';assert part.count(old)==1
  part=part.replace(old,'            if released {\n                if !quiesced_published { self.emit(GateEvent::TailQuiesced); } // FAULT false exit evidence\n                break;\n            }');p.write_text(s[:a]+part+s[b:])
 if case=='extra-probe':
  replace(port,'        slice(GateSlice::SeekRelease(release));\n        if probe_failed {','        slice(GateSlice::SeekRelease(release));\n        slice(GateSlice::TailProbe); // FAULT probe after release\n        if probe_failed {')
elif case=='stale-hold-reset':
 p=w/port;s=p.read_text();a=s.index('    pub fn set_seek_hold(');b=s.index('    pub fn release_seek_hold(',a);part=s[a:b];old='guard.seek_release = None;';assert part.count(old)==1;p.write_text(s[:a]+part.replace(old,'// FAULT omitted new-hold debris reset')+s[b:])
elif case=='pause-event-order':
 p=w/port;s=p.read_text();a=s.index('    fn pause_park(');b=s.index('    fn seek_park(',a);part=s[a:b];assert part.count('self.emit(GateEvent::Engaged);')==1 and part.count('self.emit(GateEvent::TailQuiesced);')==1;part=part.replace('self.emit(GateEvent::Engaged);','/* ORDER_FAULT */').replace('self.emit(GateEvent::TailQuiesced);','self.emit(GateEvent::Engaged);').replace('/* ORDER_FAULT */','self.emit(GateEvent::TailQuiesced);');p.write_text(s[:a]+part+s[b:])
elif case=='duplicate-pause-failure-exit':
 replace(port,'            if let Some(release) = self.take_release_internal() {\n                slice(GateSlice::SeekRelease(release));\n            }','            if let Some(release) = self.take_release_internal() {\n                slice(GateSlice::SeekRelease(release));\n                slice(GateSlice::SeekRelease(release)); // FAULT duplicate failure-exit delivery\n            }')
elif case=='nan':
 replace('crates/qianqian-audio-api/tests/direct_pcm_flow/participants.rs',"fn process<'block>(&mut self, block: PcmViewMut<'block>) -> PcmView<'block> {\n        block.freeze()\n    }","fn process<'block>(&mut self, mut block: PcmViewMut<'block>) -> PcmView<'block> {\n        *block.sample_mut(0, 0).unwrap() = f32::NAN; // FAULT same-arena content corruption\n        block.freeze()\n    }")
elif case=='no-purge':
 replace('crates/qianqian-playback/src/session.rs','                                edge.invalidate();','                                // FAULT omit the actual worker-side ring purge')
elif case=='h2-teardown':
 p=w/'crates/qianqian-playback/src/completion.rs';s=p.read_text();a=s.index('// The atomic internal-record unit');part=s[a:];assert part.count('                || guard.teardown_released\n')==1;p.write_text(s[:a]+part.replace('                || guard.teardown_released\n','',1))
elif case=='hostile-pause':
 replace('crates/qianqian-playback/src/completion.rs','if guard.stop_requested || guard.teardown_released || guard.outcome.is_some() {','if guard.stop_requested || guard.outcome.is_some() {')
elif case in ('worker-gone-h2','worker-gone-both'):
 p=w/'crates/qianqian-playback/src/completion.rs';s=p.read_text();a=s.index('    pub(crate) fn request_seek(');b=s.index('    pub(crate) fn take_seek_command(',a);part=s[a:b];old='                || guard.worker_gone\n';assert part.count(old)==2
 if case=='worker-gone-both':part=part.replace(old,'')
 else:
  pos=part.rfind(old);part=part[:pos]+part[pos:].replace(old,'',1)
 p.write_text(s[:a]+part+s[b:])
elif case=='stale-cut-evidence':
 subprocess.run(['git','apply',str(main/'specs/f5-seek-implementation/mutations/M8StaleCutEvidence.patch')],cwd=w,check=True)
elif case=='missing-stop-intent':
 p=w/'crates/qianqian-playback/src/completion.rs';s=p.read_text();a=s.index('    pub(crate) fn request_stop(');b=s.index('    pub(crate) fn request_pause(',a);part=s[a:b];old='guard.stop_requested = true;';assert part.count(old)==1;p.write_text(s[:a]+part.replace(old,'// FAULT stop the edge without recording the stop intent')+s[b:])
elif case=='restore-known-publication':
 replace('crates/qianqian-playback/tests/common/mod.rs','                            if landing.is_none() {\n                                publishing = false;\n                            }','                            publishing = landing.is_some(); // FAULT restore after unknown')
elif case=='omit-fixture-dispose':
 replace('crates/qianqian-playback/tests/common/mod.rs','        if !self.disposed {','        if !self.disposed && false { // FAULT skip test-owned disposal')
elif case=='missing-fixture-resume':
 p=w/'crates/qianqian-playback/src/completion.rs';s=p.read_text();a=s.index('fn s0_a_paused_episodes_quiesced_park_commits_the_cut');part=s[a:];assert part.count('            completion.request_resume();')==1;p.write_text(s[:a]+part.replace('            completion.request_resume();','            // FAULT omitted fixture resume',1))
elif case=='locked-drop':
 p=w/'crates/qianqian-audio-api/tests/realtime_view_publication/publication.rs';s=p.read_text();a=s.index('    pub fn release_reclaimable(');b=s.index('\n}\n',a)
 s=s[:a]+'''    pub fn release_reclaimable(&self, identity: u64) -> bool {
        let mut inner = self.inner.lock().expect("publication lock");
        let Some(position) = inner.reclaimable.iter().position(|v| v.identity() == identity) else { return false; };
        let released = inner.reclaimable.remove(position);
        drop(released); // FAULT lock held across blocking destructor
        drop(inner);
        true
    }
'''+s[b:];p.write_text(s)
elif case not in ('control','restore'):raise ValueError(case)
print(case,flush=True)
